
  # Enterprise GRC Platform Design

  This is a code bundle for Enterprise GRC Platform Design. The original project is available at https://www.figma.com/design/khlJ08d6rNeC6EP68RG43E/Enterprise-GRC-Platform-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  