import { useMemo, useState } from "react";
import { ThemeProvider as MuiThemeProvider, CssBaseline } from "@mui/material";

function ThemeProvider({ theme, children, ...rest }: { theme: any; children: React.ReactNode; [k: string]: any }) {
  void rest; // absorb any data-fg* props Figma injects
  return <MuiThemeProvider theme={theme}>{children}</MuiThemeProvider>;
}
import { Shell } from "./components/grc/Shell";
import { Home, type App as GRCApp } from "./components/grc/Home";
import { AppWorkspace } from "./components/grc/AppWorkspace";
import { GroupOverview } from "./components/grc/GroupOverview";
import { RiskInventory } from "./components/grc/RiskInventory";
import {
  RiskMeasures, RiskEvents, RiskAssessments, ComplianceMatrix,
  Monitoring, ConfigHub, SettingsRBAC, GenericModule,
} from "./components/grc/OtherViews";
import { CreateGroupModal } from "./components/grc/CreateGroupModal";
import { grcTheme } from "./components/grc/theme";

function AppInner(_props: Record<string, unknown> = {}) {
  const [view, setView] = useState("home");
  const [dark, setDark] = useState(false);
  const [modal, setModal] = useState(false);
  const [openApp, setOpenApp] = useState<{ app: GRCApp; groupName: string } | null>(null);
  const theme = useMemo(() => grcTheme(dark ? "dark" : "light"), [dark]);

  if (openApp) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <AppWorkspace app={openApp.app} groupName={openApp.groupName} onBack={() => setOpenApp(null)} dark={dark} onToggleDark={() => setDark(d => !d)} />
      </ThemeProvider>
    );
  }

  if (view === "home") {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Home onOpenApp={(app, groupName) => setOpenApp({ app, groupName })} dark={dark} onToggleDark={() => setDark(d => !d)} />
      </ThemeProvider>
    );
  }

  const renderView = () => {
    switch (view) {
      case "group": return <GroupOverview onPickModule={(id) => setView(id)} />;
      case "risk-inv": return <RiskInventory />;
      case "risk-meas": return <RiskMeasures />;
      case "risk-events": return <RiskEvents />;
      case "risk-assess": return <RiskAssessments />;
      case "compliance": return <ComplianceMatrix />;
      case "monitoring": return <Monitoring />;
      case "config": return <ConfigHub />;
      case "settings": return <SettingsRBAC />;
      case "testing": return <GenericModule title="Testing & Validation" subtitle="Control testing campaigns, evidence, and certification" />;
      case "audit": return <GenericModule title="Internal Audit" subtitle="Audit universe, plan, fieldwork and issue tracking" />;
      case "capacity": return <GenericModule title="Capacity Planning" subtitle="Resource forecasting across risk and compliance teams" />;
      default: return <GroupOverview onPickModule={(id) => setView(id)} />;
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Shell view={view} setView={setView} dark={dark} setDark={setDark} onCreateGroup={() => setModal(true)}>
        {renderView()}
      </Shell>
      <CreateGroupModal open={modal} onClose={() => setModal(false)} />
    </ThemeProvider>
  );
}

export default function App(props: Record<string, unknown>) {
  const clean = Object.fromEntries(
    Object.entries(props).filter(([k]) => !k.startsWith("data-fg"))
  );
  return (
    <div style={{ display: "contents" }} {...clean}>
      <AppInner />
    </div>
  );
}
