import { useState, useMemo } from "react";
import {
  Box, Card, CardContent, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TableSortLabel, IconButton, TextField, InputBase, Chip, Menu, MenuItem,
  Checkbox, ListItemText, Button, Stack, Popover,
  Divider, Tooltip, Badge,
} from "@mui/material";
import {
  Search, Filter, SlidersHorizontal, Download, MoreVertical, ChevronDown, Eye, EyeOff,
  ArrowUpDown, Pin, X, Check,
} from "lucide-react";
import { BRAND } from "./theme";

export type Column<T = any> = {
  id: string;
  label: string;
  field: keyof T | ((row: T) => any);
  sortable?: boolean;
  filterable?: boolean;
  width?: number | string;
  minWidth?: number;
  sticky?: boolean;
  align?: "left" | "center" | "right";
  render?: (value: any, row: T) => React.ReactNode;
  filterType?: "text" | "select" | "date" | "number";
  filterOptions?: Array<{ label: string; value: any }>;
};

type AdvancedTableProps<T = any> = {
  columns: Column<T>[];
  data: T[];
  rowKey: keyof T | ((row: T) => string);
  defaultRowsPerPage?: number;
  color?: string;
  title?: string;
  subtitle?: string;
  onRowClick?: (row: T) => void;
  enableColumnManagement?: boolean;
  enableQuickFilters?: boolean;
  enableAdvancedFilters?: boolean;
  enableExport?: boolean;
  quickFilters?: Array<{ label: string; filter: (row: T) => boolean }>;
};

export function AdvancedTable<T extends Record<string, any>>({
  columns: initialColumns,
  data,
  rowKey,
  defaultRowsPerPage = 10,
  color = BRAND.primary,
  title,
  subtitle,
  onRowClick,
  enableColumnManagement = true,
  enableQuickFilters = true,
  enableAdvancedFilters = true,
  enableExport = true,
  quickFilters = [],
}: AdvancedTableProps<T>) {
  // Pagination
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(defaultRowsPerPage);

  // Sorting
  const [orderBy, setOrderBy] = useState<string | null>(null);
  const [order, setOrder] = useState<"asc" | "desc">("asc");

  // Search
  const [searchQuery, setSearchQuery] = useState("");

  // Column visibility
  const [visibleColumns, setVisibleColumns] = useState<string[]>(
    initialColumns.map(c => c.id)
  );

  // Sticky columns
  const [stickyColumns, setStickyColumns] = useState<string[]>(
    initialColumns.filter(c => c.sticky).map(c => c.id)
  );

  // Filters
  const [columnFilters, setColumnFilters] = useState<Record<string, any>>({});
  const [activeQuickFilter, setActiveQuickFilter] = useState<number | null>(null);

  // UI State
  const [columnMenuAnchor, setColumnMenuAnchor] = useState<null | HTMLElement>(null);
  const [filterMenuAnchor, setFilterMenuAnchor] = useState<null | HTMLElement>(null);
  const [quickFilterAnchor, setQuickFilterAnchor] = useState<null | HTMLElement>(null);

  const columns = useMemo(
    () => initialColumns.filter(c => visibleColumns.includes(c.id)),
    [initialColumns, visibleColumns]
  );

  const getValue = (row: T, field: Column<T>["field"]) => {
    if (typeof field === "function") return field(row);
    return row[field];
  };

  // Apply filters and search
  const filteredData = useMemo(() => {
    let result = [...data];

    // Quick filter
    if (activeQuickFilter !== null && quickFilters[activeQuickFilter]) {
      result = result.filter(quickFilters[activeQuickFilter].filter);
    }

    // Search
    if (searchQuery) {
      result = result.filter(row =>
        columns.some(col => {
          const value = getValue(row, col.field);
          return String(value).toLowerCase().includes(searchQuery.toLowerCase());
        })
      );
    }

    // Column filters
    Object.entries(columnFilters).forEach(([colId, filterValue]) => {
      if (filterValue !== "" && filterValue !== null && filterValue !== undefined) {
        const col = columns.find(c => c.id === colId);
        if (col) {
          result = result.filter(row => {
            const value = getValue(row, col.field);
            if (col.filterType === "select") {
              return value === filterValue;
            }
            return String(value).toLowerCase().includes(String(filterValue).toLowerCase());
          });
        }
      }
    });

    return result;
  }, [data, searchQuery, columnFilters, activeQuickFilter, quickFilters, columns]);

  // Apply sorting
  const sortedData = useMemo(() => {
    if (!orderBy) return filteredData;

    const col = columns.find(c => c.id === orderBy);
    if (!col) return filteredData;

    return [...filteredData].sort((a, b) => {
      const aVal = getValue(a, col.field);
      const bVal = getValue(b, col.field);

      if (aVal == null) return 1;
      if (bVal == null) return -1;

      let comparison = 0;
      if (typeof aVal === "number" && typeof bVal === "number") {
        comparison = aVal - bVal;
      } else {
        comparison = String(aVal).localeCompare(String(bVal));
      }

      return order === "asc" ? comparison : -comparison;
    });
  }, [filteredData, orderBy, order, columns]);

  // Paginate
  const paginatedData = useMemo(() => {
    const start = page * rowsPerPage;
    return sortedData.slice(start, start + rowsPerPage);
  }, [sortedData, page, rowsPerPage]);

  const handleSort = (columnId: string) => {
    const col = columns.find(c => c.id === columnId);
    if (!col?.sortable) return;

    const isAsc = orderBy === columnId && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(columnId);
  };

  const handleToggleColumn = (columnId: string) => {
    setVisibleColumns(prev =>
      prev.includes(columnId)
        ? prev.filter(id => id !== columnId)
        : [...prev, columnId]
    );
  };

  const handleToggleSticky = (columnId: string) => {
    setStickyColumns(prev =>
      prev.includes(columnId)
        ? prev.filter(id => id !== columnId)
        : [...prev, columnId]
    );
  };

  const handleExport = () => {
    // Simple CSV export
    const headers = columns.map(c => c.label).join(",");
    const rows = sortedData.map(row =>
      columns.map(col => {
        const value = getValue(row, col.field);
        return `"${String(value).replace(/"/g, '""')}"`;
      }).join(",")
    );
    const csv = [headers, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title || "export"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getRowId = (row: T) => {
    if (typeof rowKey === "function") return rowKey(row);
    return String(row[rowKey]);
  };

  const activeFiltersCount = Object.values(columnFilters).filter(v => v !== "" && v != null).length;

  return (
    <Card>
      <CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
        {/* Toolbar */}
        <Box sx={{ mb: 2 }}>
          {title && (
            <Box sx={{ mb: 1.5 }}>
              <Box sx={{ fontWeight: 700, fontSize: { xs: 14, md: 16 }, color: BRAND.navy }}>{title}</Box>
              {subtitle && <Box sx={{ fontSize: { xs: 11, md: 12 }, color: "text.secondary" }}>{subtitle}</Box>}
            </Box>
          )}

          <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap", gap: 1 }}>
            {/* Search */}
            <Box sx={{
              display: "flex", alignItems: "center", gap: 1,
              px: 1.25, py: 0.5, border: 1, borderColor: "divider", borderRadius: 2,
              flex: { xs: "1 1 100%", sm: "0 1 300px" },
            }}>
              <Search size={15} opacity={0.6}/>
              <InputBase
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                sx={{ flex: 1, fontSize: 13 }}
              />
              {searchQuery && (
                <IconButton size="small" onClick={() => setSearchQuery("")}>
                  <X size={14}/>
                </IconButton>
              )}
            </Box>

            <Box sx={{ flex: 1 }}/>

            {/* Quick Filters */}
            {enableQuickFilters && quickFilters.length > 0 && (
              <Button
                size="small"
                variant={activeQuickFilter !== null ? "contained" : "outlined"}
                startIcon={<Filter size={14}/>}
                onClick={(e) => setQuickFilterAnchor(e.currentTarget)}
                sx={{
                  borderColor: "divider",
                  ...(activeQuickFilter !== null && {
                    bgcolor: color,
                    "&:hover": { bgcolor: color, filter: "brightness(0.95)" },
                  }),
                }}
              >
                Quick Filter
                {activeQuickFilter !== null && (
                  <Chip
                    size="small"
                    label="1"
                    sx={{ ml: 0.5, height: 18, bgcolor: "rgba(255,255,255,0.25)", color: "#fff" }}
                  />
                )}
              </Button>
            )}

            {/* Advanced Filters */}
            {enableAdvancedFilters && (
              <Button
                size="small"
                variant="outlined"
                startIcon={<SlidersHorizontal size={14}/>}
                onClick={(e) => setFilterMenuAnchor(e.currentTarget)}
                sx={{ borderColor: "divider" }}
              >
                Filters
                {activeFiltersCount > 0 && (
                  <Badge badgeContent={activeFiltersCount} color="primary" sx={{ ml: 1 }} />
                )}
              </Button>
            )}

            {/* Column Management */}
            {enableColumnManagement && (
              <Button
                size="small"
                variant="outlined"
                startIcon={<Eye size={14}/>}
                onClick={(e) => setColumnMenuAnchor(e.currentTarget)}
                sx={{ borderColor: "divider" }}
              >
                Columns
              </Button>
            )}

            {/* Export */}
            {enableExport && (
              <Button
                size="small"
                variant="outlined"
                startIcon={<Download size={14}/>}
                onClick={handleExport}
                sx={{ borderColor: "divider" }}
              >
                <Box sx={{ display: { xs: "none", sm: "block" } }}>Export</Box>
              </Button>
            )}
          </Stack>

          {/* Active Filters Display */}
          {(activeQuickFilter !== null || activeFiltersCount > 0) && (
            <Box sx={{ mt: 1.5, display: "flex", gap: 0.75, flexWrap: "wrap" }}>
              {activeQuickFilter !== null && (
                <Chip
                  size="small"
                  label={quickFilters[activeQuickFilter].label}
                  onDelete={() => setActiveQuickFilter(null)}
                  sx={{ bgcolor: `${color}1A`, color }}
                />
              )}
              {Object.entries(columnFilters).map(([colId, value]) => {
                if (!value) return null;
                const col = columns.find(c => c.id === colId);
                if (!col) return null;
                return (
                  <Chip
                    key={colId}
                    size="small"
                    label={`${col.label}: ${value}`}
                    onDelete={() => setColumnFilters(prev => ({ ...prev, [colId]: "" }))}
                  />
                );
              })}
            </Box>
          )}
        </Box>

        {/* Table */}
        <TableContainer sx={{ maxHeight: { xs: 400, md: 600 }, overflowX: "auto" }}>
          <Table stickyHeader size="small">
            <TableHead>
              <TableRow>
                {columns.map((col, idx) => {
                  const isSticky = stickyColumns.includes(col.id);
                  const stickyLeft = isSticky
                    ? columns.slice(0, idx).filter(c => stickyColumns.includes(c.id))
                        .reduce((sum, c) => sum + (typeof c.width === "number" ? c.width : 150), 0)
                    : undefined;

                  return (
                    <TableCell
                      key={col.id}
                      align={col.align || "left"}
                      sx={{
                        fontWeight: 700,
                        fontSize: { xs: 11, md: 12 },
                        whiteSpace: "nowrap",
                        minWidth: col.minWidth,
                        width: col.width,
                        ...(isSticky && {
                          position: "sticky",
                          left: stickyLeft,
                          zIndex: 3,
                          bgcolor: "background.paper",
                          borderRight: "1px solid",
                          borderColor: "divider",
                        }),
                      }}
                    >
                      {col.sortable ? (
                        <TableSortLabel
                          active={orderBy === col.id}
                          direction={orderBy === col.id ? order : "asc"}
                          onClick={() => handleSort(col.id)}
                          sx={{ fontSize: "inherit" }}
                        >
                          {col.label}
                        </TableSortLabel>
                      ) : (
                        col.label
                      )}
                    </TableCell>
                  );
                })}
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row) => (
                <TableRow
                  key={getRowId(row)}
                  hover
                  onClick={() => onRowClick?.(row)}
                  sx={{
                    cursor: onRowClick ? "pointer" : "default",
                    "& td": { fontSize: { xs: 11.5, md: 13 } },
                  }}
                >
                  {columns.map((col, idx) => {
                    const isSticky = stickyColumns.includes(col.id);
                    const stickyLeft = isSticky
                      ? columns.slice(0, idx).filter(c => stickyColumns.includes(c.id))
                          .reduce((sum, c) => sum + (typeof c.width === "number" ? c.width : 150), 0)
                      : undefined;

                    const value = getValue(row, col.field);

                    return (
                      <TableCell
                        key={col.id}
                        align={col.align || "left"}
                        sx={{
                          ...(isSticky && {
                            position: "sticky",
                            left: stickyLeft,
                            zIndex: 1,
                            bgcolor: "background.paper",
                            borderRight: "1px solid",
                            borderColor: "divider",
                          }),
                        }}
                      >
                        {col.render ? col.render(value, row) : value}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Pagination */}
        <TablePagination
          component="div"
          count={sortedData.length}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(_, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          rowsPerPageOptions={[5, 10, 25, 50, 100]}
          sx={{ borderTop: 1, borderColor: "divider", mt: 1 }}
        />

        {/* Quick Filter Menu */}
        <Menu
          open={!!quickFilterAnchor}
          anchorEl={quickFilterAnchor}
          onClose={() => setQuickFilterAnchor(null)}
        >
          <MenuItem onClick={() => { setActiveQuickFilter(null); setQuickFilterAnchor(null); }}>
            <ListItemText>All</ListItemText>
            {activeQuickFilter === null && <Check size={16}/>}
          </MenuItem>
          <Divider/>
          {quickFilters.map((filter, idx) => (
            <MenuItem
              key={idx}
              onClick={() => { setActiveQuickFilter(idx); setQuickFilterAnchor(null); }}
            >
              <ListItemText>{filter.label}</ListItemText>
              {activeQuickFilter === idx && <Check size={16}/>}
            </MenuItem>
          ))}
        </Menu>

        {/* Advanced Filter Menu */}
        <Popover
          open={!!filterMenuAnchor}
          anchorEl={filterMenuAnchor}
          onClose={() => setFilterMenuAnchor(null)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
          transformOrigin={{ vertical: "top", horizontal: "right" }}
        >
          <Box sx={{ p: 2, minWidth: 300 }}>
            <Box sx={{ fontWeight: 700, mb: 1.5, fontSize: 14 }}>Advanced Filters</Box>
            <Stack spacing={1.5}>
              {columns.filter(c => c.filterable !== false).map(col => (
                <Box key={col.id}>
                  <Box sx={{ fontSize: 12, fontWeight: 600, mb: 0.5 }}>{col.label}</Box>
                  {col.filterType === "select" && col.filterOptions ? (
                    <TextField
                      select
                      fullWidth
                      size="small"
                      value={columnFilters[col.id] || ""}
                      onChange={(e) => setColumnFilters(prev => ({ ...prev, [col.id]: e.target.value }))}
                    >
                      <MenuItem value="">All</MenuItem>
                      {col.filterOptions.map(opt => (
                        <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
                      ))}
                    </TextField>
                  ) : (
                    <TextField
                      fullWidth
                      size="small"
                      placeholder={`Filter ${col.label.toLowerCase()}...`}
                      value={columnFilters[col.id] || ""}
                      onChange={(e) => setColumnFilters(prev => ({ ...prev, [col.id]: e.target.value }))}
                    />
                  )}
                </Box>
              ))}
            </Stack>
            <Box sx={{ mt: 2, display: "flex", gap: 1 }}>
              <Button
                size="small"
                onClick={() => { setColumnFilters({}); setFilterMenuAnchor(null); }}
              >
                Clear All
              </Button>
              <Box sx={{ flex: 1 }}/>
              <Button
                size="small"
                variant="contained"
                onClick={() => setFilterMenuAnchor(null)}
                sx={{ bgcolor: color, "&:hover": { bgcolor: color, filter: "brightness(0.95)" } }}
              >
                Apply
              </Button>
            </Box>
          </Box>
        </Popover>

        {/* Column Management Menu */}
        <Popover
          open={!!columnMenuAnchor}
          anchorEl={columnMenuAnchor}
          onClose={() => setColumnMenuAnchor(null)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
          transformOrigin={{ vertical: "top", horizontal: "right" }}
        >
          <Box sx={{ p: 2, minWidth: 280 }}>
            <Box sx={{ fontWeight: 700, mb: 1.5, fontSize: 14 }}>Manage Columns</Box>
            <Stack spacing={0.5} divider={<Divider/>}>
              {initialColumns.map(col => (
                <Box key={col.id} sx={{ display: "flex", alignItems: "center", gap: 1, py: 0.5 }}>
                  <Checkbox
                    size="small"
                    checked={visibleColumns.includes(col.id)}
                    onChange={() => handleToggleColumn(col.id)}
                  />
                  <Box sx={{ flex: 1, fontSize: 13 }}>{col.label}</Box>
                  <Tooltip title={stickyColumns.includes(col.id) ? "Unpin column" : "Pin column"}>
                    <IconButton
                      size="small"
                      onClick={() => handleToggleSticky(col.id)}
                      disabled={!visibleColumns.includes(col.id)}
                      sx={{
                        color: stickyColumns.includes(col.id) ? color : "text.secondary",
                      }}
                    >
                      <Pin size={14}/>
                    </IconButton>
                  </Tooltip>
                </Box>
              ))}
            </Stack>
            <Box sx={{ mt: 2, display: "flex", gap: 1 }}>
              <Button
                size="small"
                onClick={() => setVisibleColumns(initialColumns.map(c => c.id))}
              >
                Show All
              </Button>
              <Button
                size="small"
                onClick={() => setStickyColumns([])}
              >
                Unpin All
              </Button>
            </Box>
          </Box>
        </Popover>
      </CardContent>
    </Card>
  );
}
