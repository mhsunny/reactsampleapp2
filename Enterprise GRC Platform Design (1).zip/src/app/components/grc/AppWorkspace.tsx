import { useMemo, useState } from "react";
import {
  Box, AppBar, Toolbar, IconButton, InputBase, Chip, Avatar, Badge, Tooltip, Divider,
  Collapse, Menu, MenuItem, ListItemIcon, ListItemText, Button, Stack, Card, CardContent, Grid,
  LinearProgress,
} from "@mui/material";
import {
  ArrowLeft, LayoutDashboard, ChevronDown, ChevronRight, Bell, Search, Settings2,
  Star, Plus, Filter, Download, MoreHorizontal, Activity, ArrowUpRight, ArrowDownRight,
  Menu as MenuIcon, X, Sun, Moon, BarChart2,
} from "lucide-react";
import { BRAND } from "./theme";
import { FEATURE_LIBRARY, FEATURE_BY_ID, FEATURE_CATEGORIES, Feature } from "./features";
import { AdvancedTable, Column } from "./AdvancedTable";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer,
  XAxis, YAxis, Tooltip as RTooltip, CartesianGrid, ComposedChart, Line, RadarChart,
  PolarGrid, PolarAngleAxis, Radar,
} from "recharts";

type App = {
  id: string; name: string; color: string; records: number; status: string; features: string[];
};

export function AppWorkspace({
  app, groupName, onBack, dark, onToggleDark,
}: {
  app: App; groupName?: string; onBack: () => void; dark?: boolean; onToggleDark?: () => void;
}) {
  const enabledFeatures = useMemo(
    () => (app.features ?? []).map(id => FEATURE_BY_ID[id]).filter(Boolean) as Feature[],
    [app.features]
  );

  const hasDashboard = enabledFeatures.some(f => f.id === "dashboard");
  const [active, setActive] = useState<string>(hasDashboard ? "dashboard" : enabledFeatures[0]?.id ?? "");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Group non-dashboard features by category
  const byCategory = useMemo(() => {
    const map: Record<string, Feature[]> = {};
    enabledFeatures.filter(f => f.id !== "dashboard").forEach(f => {
      (map[f.category] ||= []).push(f);
    });
    return map;
  }, [enabledFeatures]);

  const [openCats, setOpenCats] = useState<Record<string, boolean>>(
    () => Object.fromEntries(FEATURE_CATEGORIES.map(c => [c, true]))
  );

  const activeFeature = enabledFeatures.find(f => f.id === active);
  const SIDEBAR_W = 268;
  const SIDEBAR_W_COLLAPSED = 70;

  const navH = { xs: 56, md: 60 };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "background.default" }}>
      {/* Mobile backdrop */}
      {sidebarOpen && (
        <Box onClick={() => setSidebarOpen(false)}
          sx={{ display: { xs: "block", md: "none" }, position: "fixed", inset: 0, bgcolor: "rgba(0,0,0,0.5)", zIndex: 998 }}
        />
      )}
      {/* Full-width top navbar */}
      <Box sx={{
        height: navH, bgcolor: BRAND.primary, color: "#fff",
        display: "flex", alignItems: "center", px: { xs: 2, md: 4 }, gap: { xs: 1.5, md: 3 },
        position: "sticky", top: 0, zIndex: 1100,
        boxShadow: "0 2px 0 rgba(0,0,0,0.04)", flexShrink: 0,
      }}>
        {/* Mobile menu */}
        <IconButton onClick={() => setSidebarOpen(true)} size="small"
          sx={{ display: { xs: "flex", md: "none" }, color: "#fff", "&:hover": { bgcolor: "rgba(255,255,255,0.12)" } }}>
          <MenuIcon size={18}/>
        </IconButton>

        {/* Logo */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.25 }}>
          <Box sx={{ width: { xs: 24, md: 28 }, height: { xs: 24, md: 28 }, borderRadius: 0.75,
            display: "grid", gridTemplateColumns: "1fr 1fr", gap: "3px" }}>
            {[0,1,2,3].map(i => <Box key={i} sx={{ bgcolor: "#fff", borderRadius: 0.5 }}/>)}
          </Box>
          <Box sx={{ fontSize: { xs: 16, md: 18 }, fontWeight: 700, letterSpacing: "-0.01em" }}>GRC Risk</Box>
        </Box>
        <Divider orientation="vertical" flexItem sx={{ borderColor: "rgba(255,255,255,0.25)", my: 1.5 }}/>

        {/* Back + app name */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <IconButton onClick={onBack} size="small"
            sx={{ color: "#fff", "&:hover": { bgcolor: "rgba(255,255,255,0.12)" } }}>
            <ArrowLeft size={18}/>
          </IconButton>
          <Box sx={{
            width: 28, height: 28, borderRadius: 1.25, flexShrink: 0,
            background: `linear-gradient(135deg, ${app.color}, ${app.color}80)`,
            display: "grid", placeItems: "center", fontWeight: 700, fontSize: 13, color: "#fff",
          }}>
            {app.name[0]}
          </Box>
          <Box sx={{ fontSize: { xs: 13, md: 14.5 }, fontWeight: 700, letterSpacing: "-0.01em" }}>
            {app.name}
          </Box>
        </Box>

        <Box sx={{ flex: 1 }}/>

        <Box sx={{ display: { xs: "none", md: "flex" }, alignItems: "center", gap: 1, mr: 1,
          px: 1.25, py: 0.5, borderRadius: 2, bgcolor: "rgba(255,255,255,0.13)",
          border: "1px solid rgba(255,255,255,0.18)", minWidth: 280 }}>
          <Search size={15} color="#fff" opacity={0.85}/>
          <InputBase placeholder={`Search in ${app.name}…`}
            sx={{ flex: 1, fontSize: 13, color: "#fff", "& input::placeholder": { color: "rgba(255,255,255,0.7)", opacity: 1 } }}/>
        </Box>

        <Tooltip title="Notifications">
          <IconButton sx={{ color: "#fff" }}>
            <Badge color="warning" variant="dot"><Bell size={18}/></Badge>
          </IconButton>
        </Tooltip>

        <Tooltip title={dark ? "Light mode" : "Dark mode"}>
          <IconButton sx={{ color: "#fff" }} onClick={onToggleDark}>
            {dark ? <Sun size={18}/> : <Moon size={18}/>}
          </IconButton>
        </Tooltip>

        <Divider orientation="vertical" flexItem sx={{ display: { xs: "none", lg: "block" }, borderColor: "rgba(255,255,255,0.25)", my: 1.5, mx: 0.5 }}/>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1, cursor: "pointer", py: 0.5, px: 1, borderRadius: 1.5,
          "&:hover": { bgcolor: "rgba(255,255,255,0.1)" } }}>
          <Avatar sx={{ width: 28, height: 28, bgcolor: "rgba(255,255,255,0.2)", fontSize: 11, fontWeight: 700 }}>EM</Avatar>
          <Box sx={{ display: { xs: "none", sm: "block" }, fontSize: 13.5, fontWeight: 600 }}>Elena M.</Box>
          <ChevronDown size={14} style={{ display: window.innerWidth < 600 ? "none" : "block" }}/>
        </Box>
      </Box>

      {/* Below navbar: sidebar + main content */}
      <Box sx={{ display: "flex", flex: 1, minHeight: 0 }}>

      {/* Sidebar */}
      <Box
        sx={{
          width: { xs: SIDEBAR_W, md: sidebarCollapsed ? SIDEBAR_W_COLLAPSED : SIDEBAR_W },
          flexShrink: 0,
          position: { xs: "fixed", md: "sticky" },
          top: { xs: 0, md: navH },
          left: 0,
          height: { xs: "100vh", md: `calc(100vh - 60px)` },
          overflowY: "auto", overflowX: "hidden", zIndex: 999,
          bgcolor: "background.paper",
          color: "text.primary", borderRight: "1px solid", borderColor: "divider",
          transform: { xs: sidebarOpen ? "translateX(0)" : "translateX(-100%)", md: "translateX(0)" },
          transition: "all 0.3s ease-in-out",
        }}
      >
        {/* App identity */}
        <Box sx={{ p: 2.25, display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box sx={{
            width: 40, height: 40, borderRadius: 2,
            background: `linear-gradient(135deg, ${app.color}, ${app.color}80)`,
            display: "grid", placeItems: "center", fontWeight: 700, fontSize: 16, color: "#fff",
            boxShadow: `0 10px 24px -12px ${app.color}aa`,
          }}>
            {app.name.slice(0, 1)}
          </Box>
          {!sidebarCollapsed && (
            <Box sx={{ minWidth: 0, flex: 1, display: "flex", flexDirection: "column" }}>
              <Box sx={{ fontSize: 14, fontWeight: 700, color: "text.primary",
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{app.name}</Box>
              <Box sx={{ fontSize: 11, color: "text.secondary" }}>
                {enabledFeatures.length} features
              </Box>
            </Box>
          )}

          {/* Collapse button - Desktop */}
          <Tooltip title={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"} placement="right">
            <IconButton
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              size="small"
              sx={{
                display: { xs: "none", md: "flex" },
                color: "text.secondary",
                "&:hover": { bgcolor: "action.hover" }
              }}
            >
              {sidebarCollapsed ? <ChevronRight size={18}/> : <ChevronDown size={18} style={{ transform: "rotate(-90deg)" }}/>}
            </IconButton>
          </Tooltip>

          {/* Close button - Mobile */}
          <IconButton
            onClick={() => setSidebarOpen(false)}
            size="small"
            sx={{ display: { xs: "flex", md: "none" }, color: "text.secondary" }}
          >
            <X size={18}/>
          </IconButton>
        </Box>
        <Divider/>

        {/* Dashboard first */}
        {hasDashboard && (
          <Box sx={{ px: 1, pt: 1.25 }}>
            <SidebarItem
              active={active === "dashboard"}
              accent={app.color}
              icon={<LayoutDashboard size={16}/>}
              label="Dashboard"
              collapsed={sidebarCollapsed}
              onClick={() => {
                setActive("dashboard");
                setSidebarOpen(false);
              }}
            />
          </Box>
        )}

        {/* Other features by category */}
        <Box sx={{ px: 1, pb: 2 }}>
          {FEATURE_CATEGORIES.map(cat => {
            const items = byCategory[cat] ?? [];
            if (items.length === 0) return null;
            const open = !!openCats[cat];
            return (
              <Box key={cat} sx={{ mt: 1.25 }}>
                {!sidebarCollapsed && (
                  <Box
                    onClick={() => setOpenCats(s => ({ ...s, [cat]: !s[cat] }))}
                    sx={{
                      display: "flex", alignItems: "center", gap: 1,
                      px: 1.25, py: 0.75, cursor: "pointer", borderRadius: 1.5,
                      color: "text.secondary",
                      "&:hover": { color: "text.primary", bgcolor: "action.hover" },
                    }}
                  >
                    {open ? <ChevronDown size={13}/> : <ChevronRight size={13}/>}
                    <Box sx={{ fontSize: 10.5, fontWeight: 700, letterSpacing: ".12em",
                      textTransform: "uppercase", flex: 1 }}>{cat}</Box>
                    <Box sx={{ fontSize: 10.5, color: "text.disabled" }}>{items.length}</Box>
                  </Box>
                )}
                {sidebarCollapsed && items.map(f => {
                  const Icon = f.icon;
                  return (
                    <SidebarItem
                      key={f.id}
                      active={active === f.id}
                      accent={app.color}
                      icon={<Icon size={15}/>}
                      label={f.name}
                      collapsed={sidebarCollapsed}
                      onClick={() => {
                        setActive(f.id);
                        setSidebarOpen(false);
                      }}
                    />
                  );
                })}
                <Collapse in={open && !sidebarCollapsed}>
                  {items.map(f => {
                    const Icon = f.icon;
                    return (
                      <SidebarItem
                        key={f.id}
                        active={active === f.id}
                        accent={app.color}
                        icon={<Icon size={15}/>}
                        label={f.name}
                        collapsed={sidebarCollapsed}
                        onClick={() => {
                          setActive(f.id);
                          setSidebarOpen(false);
                        }}
                      />
                    );
                  })}
                </Collapse>
              </Box>
            );
          })}
        </Box>

        <Divider/>
        <Box sx={{ p: 1.25, display: "flex", alignItems: "center", gap: 1, justifyContent: sidebarCollapsed ? "center" : "flex-start" }}>
          <Avatar sx={{ width: 28, height: 28, bgcolor: app.color, fontSize: 11 }}>EM</Avatar>
          {!sidebarCollapsed && (
            <>
              <Box sx={{ lineHeight: 1.1, flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
                <Box sx={{ fontSize: 12.5, fontWeight: 600 }}>Elena Marlowe</Box>
                <Box sx={{ fontSize: 10.5, color: "text.secondary" }}>App admin</Box>
              </Box>
              <IconButton size="small" sx={{ color: "text.secondary" }}>
                <Settings2 size={14}/>
              </IconButton>
            </>
          )}
        </Box>
      </Box>

      {/* Main */}
      <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        {/* Feature header */}
        <Box sx={{ px: { xs: 2, md: 3 }, pt: { xs: 1.5, md: 2 }, pb: 1,
          display: "flex", alignItems: "flex-end", gap: 2, flexWrap: "wrap" }}>
          <Box sx={{ flex: { xs: "1 1 100%", md: "1" }, display: "flex", flexDirection: "column" }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, fontSize: { xs: 11.5, md: 12.5 }, color: "text.secondary", mb: 0.5, flexWrap: "wrap" }}>
              <Box sx={{ cursor: "pointer", "&:hover": { color: BRAND.primary } }}>GRC Risk</Box>
              <Box sx={{ opacity: 0.5 }}>/</Box>
              <Box sx={{ cursor: "pointer", "&:hover": { color: BRAND.primary } }}>{app.name}</Box>
              <Box sx={{ opacity: 0.5 }}>/</Box>
              <Box sx={{ fontWeight: 600, color: "text.primary" }}>{activeFeature?.name ?? "Dashboard"}</Box>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, color: "text.secondary", fontSize: { xs: 11, md: 12 }, mb: 0.75, flexWrap: "wrap" }}>
              <Chip size="small" label={app.status} sx={{
                height: 18, fontSize: { xs: 10, md: 10.5 }, fontWeight: 700,
                bgcolor: `${app.color}1A`, color: app.color,
              }}/>
              <Box>·</Box>
              <Box>{enabledFeatures.length} features enabled</Box>
            </Box>
            <Box sx={{ fontSize: { xs: 20, md: 26 }, fontWeight: 700, color: "text.primary", letterSpacing: "-0.02em", mt: 0.5 }}>
              {activeFeature?.name ?? "Dashboard"}
            </Box>
            <Box sx={{ fontSize: { xs: 12, md: 13 }, color: "text.secondary", mt: 0.25 }}>
              {activeFeature?.description ?? "Overview of activity across this application."}
            </Box>
          </Box>
          {active !== "dashboard" && (
            <Stack direction="row" spacing={1} sx={{ width: { xs: "100%", md: "auto" } }}>
              <Button size="small" variant="outlined" startIcon={<Filter size={14}/>}
                sx={{ color: "text.primary", borderColor: "divider", flex: { xs: 1, sm: "initial" } }}>
                <Box sx={{ display: { xs: "none", sm: "block" } }}>Filter</Box>
              </Button>
              <Button size="small" variant="outlined" startIcon={<Download size={14}/>}
                sx={{ color: "text.primary", borderColor: "divider", flex: { xs: 1, sm: "initial" } }}>
                <Box sx={{ display: { xs: "none", sm: "block" } }}>Export</Box>
              </Button>
              <Button size="small" variant="contained" startIcon={<Plus size={14}/>}
                sx={{ bgcolor: app.color, "&:hover": { bgcolor: app.color, filter: "brightness(0.95)" }, flex: { xs: 1, sm: "initial" } }}>
                <Box component="span" sx={{ display: { xs: "none", sm: "inline" } }}>New {activeFeature?.name ?? "item"}</Box>
                <Box component="span" sx={{ display: { xs: "inline", sm: "none" } }}>New</Box>
              </Button>
            </Stack>
          )}
        </Box>

        {/* Content */}
        <Box sx={{ p: { xs: 1.5, md: 2.5 }, pt: 1.5 }}>
          <FeatureContent app={app} feature={activeFeature} />
        </Box>
      </Box>
      </Box>{/* end row */}
    </Box>
  );
}

function SidebarItem({
  active, accent, icon, label, onClick, collapsed,
}: { active: boolean; accent: string; icon: React.ReactNode; label: string; onClick: () => void; collapsed?: boolean }) {
  return (
    <Tooltip title={collapsed ? label : ""} placement="right">
      <Box
        onClick={onClick}
        sx={{
          mx: 0.5, my: 0.25, px: collapsed ? 0 : 1.25, py: 1,
          borderRadius: 1.75, cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: collapsed ? "center" : "flex-start", gap: 1.25,
          position: "relative",
          color: active ? accent : "text.secondary",
          background: active ? `${accent}14` : "transparent",
          "&:hover": { background: active ? `${accent}1e` : "action.hover" },
          transition: "all .15s",
        }}
      >
        {active && !collapsed && (
          <Box sx={{
            position: "absolute", left: 0, top: 8, bottom: 8, width: 3,
            borderRadius: 4, background: accent,
          }}/>
        )}
        <Box sx={{ display: "grid", placeItems: "center", color: active ? accent : "inherit" }}>{icon}</Box>
        {!collapsed && <Box sx={{ fontSize: 13.5, fontWeight: active ? 600 : 500 }}>{label}</Box>}
      </Box>
    </Tooltip>
  );
}

// =================== Feature Content ===================
function FeatureContent({ app, feature }: { app: App; feature?: Feature }) {
  if (!feature) return <GenericFeature app={app} title="Welcome" />;

  switch (feature.id) {
    case "dashboard": return <DashboardContent app={app} />;
    case "records": return <RecordsContent app={app} />;
    case "raus": return <RAUsContent app={app} />;
    case "risks": return <RisksContent app={app} />;
    case "controls": return <ControlsContent app={app} />;
    case "mcrs": return <MCRsContent app={app} />;
    case "heatmap": return <HeatmapContent app={app} />;
    case "kri": return <KRIContent app={app} />;
    case "incidents": return <IncidentsContent app={app} />;
    case "workflows": return <WorkflowsContent app={app} />;
    case "audit-log": return <AuditLogContent app={app} />;
    case "notifications": return <NotificationsContent app={app} />;
    case "compliance-map": return <ComplianceMapContent app={app} />;
    default: return <GenericFeature app={app} title={feature.name} description={feature.description} />;
  }
}

// =================== Dashboard Widgets ===================

type WidgetDef = {
  id: string;
  title: string;
  description: string;
  value: string;
  trend: string;
  trendUp: boolean;
  chartType: "area" | "bar" | "donut" | "composed";
  color: string;
  data: Array<{ v: number; b?: number }>;
  donutData?: Array<{ name: string; value: number; color: string }>;
};

function makeSparkData(seed: number, len = 14) {
  return Array.from({ length: len }, (_, i) => ({
    v: Math.max(5, Math.round(30 + Math.sin((i + seed) / 2.2) * 18 + i * 1.4 + (seed % 7))),
    b: Math.max(2, Math.round(8 + Math.abs(Math.cos((i + seed) / 1.8)) * 10)),
  }));
}

const WIDGET_CATALOG: WidgetDef[] = [
  { id: "open-items", title: "Open Items", description: "Total active records requiring attention", value: "318", trend: "+12", trendUp: true, chartType: "area", color: "#E6392D", data: makeSparkData(1) },
  { id: "avg-score", title: "Avg Risk Score", description: "Mean inherent risk score across all records", value: "72.4", trend: "-3.2", trendUp: false, chartType: "bar", color: "#F59E0B", data: makeSparkData(3) },
  { id: "sla", title: "SLA Adherence", description: "Percentage of items resolved within SLA", value: "97.8%", trend: "+0.4%", trendUp: true, chartType: "area", color: "#10B981", data: makeSparkData(5) },
  { id: "velocity", title: "Mitigation Velocity", description: "Average days to close a high-priority item", value: "9.2d", trend: "-0.6d", trendUp: false, chartType: "bar", color: "#3B82F6", data: makeSparkData(7) },
  { id: "distribution", title: "Risk Distribution", description: "Breakdown by category", value: "100", trend: "+5", trendUp: true, chartType: "donut", color: "#A855F7", data: [], donutData: [
    { name: "Cyber", value: 38, color: "#E6392D" },
    { name: "Operational", value: 24, color: "#F59E0B" },
    { name: "Compliance", value: 18, color: "#3B82F6" },
    { name: "Strategic", value: 12, color: "#10B981" },
    { name: "Financial", value: 8, color: "#A855F7" },
  ]},
  { id: "activity", title: "Monthly Activity", description: "Item volume vs. exceptions over 14 periods", value: "1,284", trend: "+8.2%", trendUp: true, chartType: "composed", color: "#6366F1", data: makeSparkData(2) },
  { id: "critical", title: "Critical Items", description: "High-severity records open right now", value: "41", trend: "+3", trendUp: true, chartType: "bar", color: "#E6392D", data: makeSparkData(9) },
  { id: "resolved", title: "Resolved This Month", description: "Items closed in the current calendar month", value: "127", trend: "+22%", trendUp: true, chartType: "area", color: "#10B981", data: makeSparkData(4) },
  { id: "overdue", title: "Overdue Items", description: "Past SLA or review deadline", value: "19", trend: "+4", trendUp: false, chartType: "bar", color: "#F59E0B", data: makeSparkData(6) },
  { id: "assessments", title: "Assessments Due", description: "Scheduled assessments in the next 30 days", value: "7", trend: "−2", trendUp: false, chartType: "area", color: "#06B6D4", data: makeSparkData(8) },
  { id: "controls", title: "Control Effectiveness", description: "Controls rated effective this quarter", value: "84%", trend: "+2%", trendUp: true, chartType: "area", color: "#8B5CF6", data: makeSparkData(10) },
  { id: "kri-breach", title: "KRI Breaches", description: "Key risk indicators currently in breach", value: "3", trend: "−1", trendUp: false, chartType: "bar", color: "#E6392D", data: makeSparkData(11) },
];

function WidgetCard({ widget, appColor, onRemove }: { widget: WidgetDef; appColor: string; onRemove: () => void }) {
  const color = widget.color;
  const gradId = `wg-${widget.id}`;

  return (
    <Card sx={{ height: "100%", display: "flex", flexDirection: "column", overflow: "hidden", position: "relative" }}>
      <CardContent sx={{ p: 2, pb: "8px !important", display: "flex", flexDirection: "column", flex: 1, gap: 0 }}>
        {/* Header */}
        <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", mb: 0.5 }}>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Box sx={{ fontSize: 12, fontWeight: 700, color: "text.secondary", letterSpacing: ".02em", textTransform: "uppercase", mb: 0.25 }}>
              {widget.title}
            </Box>
            <Box sx={{ fontSize: 11, color: "text.disabled", lineHeight: 1.4 }}>
              {widget.description}
            </Box>
          </Box>
          <Tooltip title="Remove widget">
            <IconButton size="small" onClick={onRemove}
              sx={{ ml: 0.5, mt: -0.5, color: "text.disabled", "&:hover": { color: "text.secondary" } }}>
              <X size={13}/>
            </IconButton>
          </Tooltip>
        </Box>

        {/* Value + trend */}
        <Box sx={{ display: "flex", alignItems: "baseline", gap: 1, mt: 0.5, mb: 1 }}>
          <Box sx={{ fontSize: { xs: 24, md: 28 }, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1 }}>
            {widget.value}
          </Box>
          <Chip size="small"
            icon={widget.trendUp ? <ArrowUpRight size={11}/> : <ArrowDownRight size={11}/>}
            label={widget.trend}
            sx={{ bgcolor: `${color}18`, color, fontWeight: 700, height: 18, fontSize: 10, "& .MuiChip-icon": { ml: "4px" } }}
          />
        </Box>

        {/* Chart */}
        <Box sx={{ flex: 1, minHeight: 70, mt: "auto" }}>
          {widget.chartType === "area" && (
            <ResponsiveContainer width="100%" height={80}>
              <AreaChart data={widget.data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor={color} stopOpacity={0.35}/>
                    <stop offset="100%" stopColor={color} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <RTooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid rgba(127,127,127,0.15)", padding: "4px 8px" }} itemStyle={{ color }} formatter={(v: any) => [v, ""]}/>
                <Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill={`url(#${gradId})`} dot={false} activeDot={{ r: 3, fill: color }}/>
              </AreaChart>
            </ResponsiveContainer>
          )}
          {widget.chartType === "bar" && (
            <ResponsiveContainer width="100%" height={80}>
              <BarChart data={widget.data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }} barSize={6}>
                <RTooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid rgba(127,127,127,0.15)", padding: "4px 8px" }} itemStyle={{ color }} formatter={(v: any) => [v, ""]}/>
                <Bar dataKey="v" fill={color} radius={[3, 3, 0, 0]} opacity={0.85}/>
              </BarChart>
            </ResponsiveContainer>
          )}
          {widget.chartType === "donut" && widget.donutData && (
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mt: 0.5 }}>
              <Box sx={{ position: "relative", flexShrink: 0 }}>
                <PieChart width={80} height={80}>
                  <Pie data={widget.donutData} dataKey="value" innerRadius={24} outerRadius={38} paddingAngle={2} stroke="none">
                    {widget.donutData.map((c, i) => <Cell key={i} fill={c.color}/>)}
                  </Pie>
                </PieChart>
                <Box sx={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none", fontSize: 11, fontWeight: 700 }}>
                  {widget.donutData.reduce((a, b) => a + b.value, 0)}
                </Box>
              </Box>
              <Stack spacing={0.4} sx={{ flex: 1, minWidth: 0 }}>
                {widget.donutData.map(c => (
                  <Box key={c.name} sx={{ display: "flex", alignItems: "center", gap: 0.75, fontSize: 11 }}>
                    <Box sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: c.color, flexShrink: 0 }}/>
                    <Box sx={{ flex: 1, color: "text.secondary", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.name}</Box>
                    <Box sx={{ fontWeight: 700, color: "text.primary" }}>{c.value}</Box>
                  </Box>
                ))}
              </Stack>
            </Box>
          )}
          {widget.chartType === "composed" && (
            <ResponsiveContainer width="100%" height={80}>
              <ComposedChart data={widget.data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor={color} stopOpacity={0.3}/>
                    <stop offset="100%" stopColor={color} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <RTooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: "1px solid rgba(127,127,127,0.15)", padding: "4px 8px" }} formatter={(v: any) => [v, ""]}/>
                <Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill={`url(#${gradId})`} dot={false}/>
                <Bar dataKey="b" fill="#F59E0B" radius={[2, 2, 0, 0]} barSize={4} opacity={0.7}/>
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </Box>
      </CardContent>
    </Card>
  );
}

function AddWidgetPanel({ open, onClose, onAdd, active }: { open: boolean; onClose: () => void; onAdd: (id: string) => void; active: Set<string> }) {
  if (!open) return null;
  return (
    <Box sx={{
      position: "fixed", inset: 0, zIndex: 1300, display: "flex", alignItems: "flex-start", justifyContent: "flex-end",
    }} onClick={onClose}>
      <Box sx={{
        mt: { xs: 8, md: 9 }, mr: { xs: 1, md: 3 }, width: 340, maxHeight: "70vh",
        bgcolor: "background.paper", borderRadius: "6px", boxShadow: "0 20px 60px -12px rgba(0,0,0,0.3)",
        border: "1px solid", borderColor: "divider", overflow: "hidden", display: "flex", flexDirection: "column",
      }} onClick={e => e.stopPropagation()}>
        <Box sx={{ px: 2, py: 1.5, borderBottom: "1px solid", borderColor: "divider", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Box sx={{ fontWeight: 700, fontSize: 14 }}>Add Widget</Box>
          <IconButton size="small" onClick={onClose}><X size={15}/></IconButton>
        </Box>
        <Box sx={{ overflowY: "auto", p: 1.5, display: "flex", flexDirection: "column", gap: 0.75 }}>
          {WIDGET_CATALOG.map(w => (
            <Box key={w.id} onClick={() => { onAdd(w.id); onClose(); }}
              sx={{
                display: "flex", alignItems: "center", gap: 1.5, p: 1.25, borderRadius: 2, cursor: "pointer",
                opacity: active.has(w.id) ? 0.4 : 1,
                pointerEvents: active.has(w.id) ? "none" : "auto",
                "&:hover": { bgcolor: "action.hover" },
              }}>
              <Box sx={{ width: 36, height: 36, borderRadius: 1, bgcolor: `${w.color}18`, color: w.color,
                display: "grid", placeItems: "center", flexShrink: 0 }}>
                {w.chartType === "area" || w.chartType === "composed" ? <Activity size={16}/> :
                 w.chartType === "bar" ? <BarChart2 size={16}/> : <Activity size={16}/>}
              </Box>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Box sx={{ fontSize: 13, fontWeight: 600 }}>{w.title}</Box>
                <Box sx={{ fontSize: 11, color: "text.secondary", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{w.description}</Box>
              </Box>
              {active.has(w.id) && <Box sx={{ fontSize: 10, color: "text.disabled", flexShrink: 0 }}>Added</Box>}
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
}

function DashboardContent({ app }: { app: App }) {
  const defaultIds = ["open-items", "avg-score", "sla", "velocity", "distribution", "activity"];
  const [widgetIds, setWidgetIds] = useState<string[]>(defaultIds);
  const [panelOpen, setPanelOpen] = useState(false);

  const widgets = widgetIds
    .map(id => WIDGET_CATALOG.find(w => w.id === id))
    .filter(Boolean) as WidgetDef[];

  const overrideFirst: WidgetDef[] = widgets.map((w, i) =>
    i === 0 ? { ...w, value: app.records.toLocaleString(), color: app.color } : w
  );

  return (
    <Box>
      {/* Dashboard toolbar */}
      <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 2 }}>
        <Button size="small" variant="contained" startIcon={<Plus size={14}/>}
          onClick={() => setPanelOpen(true)}
          sx={{ bgcolor: app.color, "&:hover": { bgcolor: app.color, filter: "brightness(0.92)" } }}>
          Add Widget
        </Button>
      </Box>

      <Grid container spacing={{ xs: 1.5, md: 2 }}>
        {overrideFirst.map(w => (
          <Grid key={w.id} size={{ xs: 12, sm: 6, lg: 4 }}>
            <WidgetCard
              widget={w}
              appColor={app.color}
              onRemove={() => setWidgetIds(prev => prev.filter(id => id !== w.id))}
            />
          </Grid>
        ))}
        {overrideFirst.length === 0 && (
          <Grid size={{ xs: 12 }}>
            <Card>
              <CardContent sx={{ py: 6, textAlign: "center" }}>
                <Box sx={{ fontSize: 14, color: "text.secondary", mb: 1.5 }}>No widgets yet</Box>
                <Button size="small" variant="outlined" startIcon={<Plus size={14}/>}
                  onClick={() => setPanelOpen(true)} sx={{ borderColor: app.color, color: app.color }}>
                  Add your first widget
                </Button>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>

      <AddWidgetPanel
        open={panelOpen}
        onClose={() => setPanelOpen(false)}
        onAdd={id => setWidgetIds(prev => prev.includes(id) ? prev : [...prev, id])}
        active={new Set(widgetIds)}
      />
    </Box>
  );
}

function RecordsContent({ app }: { app: App }) {
  type Record = {
    id: string;
    title: string;
    owner: string;
    sev: string;
    score: number;
    updated: string;
    status: string;
    category: string;
  };

  const rows: Record[] = Array.from({ length: 50 }).map((_, i) => ({
    id: `${app.name.slice(0,3).toUpperCase()}-${1000+i}`,
    title: ["Vendor concentration risk", "Sanctions screening gap", "Model drift detection", "Phishing simulation result",
      "Cloud key rotation delay", "Data exfil attempt", "Late control test", "Backup drill failure",
      "Privileged access anomaly", "Reporting delay issue", "AML alert backlog", "Insider trade flag",
      "Compliance gap identified", "Security patch missing", "Access review overdue", "Data retention breach"][i % 16],
    owner: ["M. Aldridge","S. Okafor","J. Chen","P. Volkov","L. Becker","T. Yamada","A. Kumar","R. Williams"][i % 8],
    sev: ["Critical","High","Medium","High","Low","Medium","Critical","High"][i % 8],
    score: 30 + ((i*13) % 70),
    updated: `2026-06-${(28 - (i % 28)).toString().padStart(2,"0")}`,
    status: ["Open","In Progress","Under Review","Resolved","Closed"][i % 5],
    category: ["Cyber Risk","Operational Risk","Compliance","Third Party","Financial Risk"][i % 5],
  }));

  const sev = (s: string) => s === "Critical" ? "#E6392D" : s === "High" ? "#F59E0B" : s === "Medium" ? "#3B82F6" : "#10B981";

  const columns: Column<Record>[] = [
    {
      id: "id",
      label: "ID",
      field: "id",
      sortable: true,
      sticky: true,
      width: 140,
      render: (value) => <Box sx={{ fontWeight: 700, color: app.color }}>{value}</Box>,
    },
    {
      id: "title",
      label: "Title",
      field: "title",
      sortable: true,
      sticky: true,
      minWidth: 200,
      render: (value) => <Box sx={{ fontWeight: 600 }}>{value}</Box>,
    },
    {
      id: "owner",
      label: "Owner",
      field: "owner",
      sortable: true,
      filterable: true,
    },
    {
      id: "severity",
      label: "Severity",
      field: "sev",
      sortable: true,
      filterType: "select",
      filterOptions: [
        { label: "Critical", value: "Critical" },
        { label: "High", value: "High" },
        { label: "Medium", value: "Medium" },
        { label: "Low", value: "Low" },
      ],
      render: (value) => (
        <Chip size="small" label={value}
          sx={{ bgcolor: `${sev(value)}1A`, color: sev(value), fontWeight: 700, height: 20 }}/>
      ),
    },
    {
      id: "category",
      label: "Category",
      field: "category",
      sortable: true,
      filterType: "select",
      filterOptions: [
        { label: "Cyber Risk", value: "Cyber Risk" },
        { label: "Operational Risk", value: "Operational Risk" },
        { label: "Compliance", value: "Compliance" },
        { label: "Third Party", value: "Third Party" },
        { label: "Financial Risk", value: "Financial Risk" },
      ],
    },
    {
      id: "status",
      label: "Status",
      field: "status",
      sortable: true,
      filterType: "select",
      filterOptions: [
        { label: "Open", value: "Open" },
        { label: "In Progress", value: "In Progress" },
        { label: "Under Review", value: "Under Review" },
        { label: "Resolved", value: "Resolved" },
        { label: "Closed", value: "Closed" },
      ],
    },
    {
      id: "score",
      label: "Risk Score",
      field: "score",
      sortable: true,
      align: "right",
      width: 120,
      render: (value, row) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <LinearProgress variant="determinate" value={value}
            sx={{ flex: 1, height: 5, borderRadius: 3,
              "& .MuiLinearProgress-bar": { backgroundColor: sev(row.sev) }}}/>
          <Box sx={{ fontWeight: 700, fontSize: 12, minWidth: 28 }}>{value}</Box>
        </Box>
      ),
    },
    {
      id: "updated",
      label: "Last Updated",
      field: "updated",
      sortable: true,
      width: 120,
    },
    {
      id: "actions",
      label: "Actions",
      field: "id",
      sortable: false,
      filterable: false,
      width: 60,
      align: "center",
      render: () => (
        <IconButton size="small"><MoreHorizontal size={14}/></IconButton>
      ),
    },
  ];

  return (
    <AdvancedTable
      columns={columns}
      data={rows}
      rowKey="id"
      color={app.color}
      title="Records & Inventory"
      subtitle={`${rows.length} total records`}
      defaultRowsPerPage={10}
      enableColumnManagement={true}
      enableQuickFilters={true}
      enableAdvancedFilters={true}
      enableExport={true}
      quickFilters={[
        { label: "Critical Only", filter: (row) => row.sev === "Critical" },
        { label: "High Priority", filter: (row) => row.sev === "Critical" || row.sev === "High" },
        { label: "Open Items", filter: (row) => row.status === "Open" || row.status === "In Progress" },
        { label: "My Items", filter: (row) => row.owner === "M. Aldridge" },
      ]}
    />
  );
}

function RAUsContent({ app }: { app: App }) {
  type RAU = { id: string; name: string; owner: string; unit: string; status: string; cycle: string; score: number; due: string; };
  const rows: RAU[] = Array.from({ length: 40 }).map((_, i) => ({
    id: `RAU-${2000 + i}`,
    name: ["Credit Risk RAU","Market Risk RAU","Operational Risk RAU","Liquidity Risk RAU","Compliance RAU",
           "Technology Risk RAU","Third-Party RAU","Reputational Risk RAU","Legal & Regulatory RAU","Fraud Risk RAU"][i % 10],
    owner: ["M. Aldridge","S. Okafor","J. Chen","P. Volkov","L. Becker","T. Yamada","A. Kumar","R. Williams"][i % 8],
    unit: ["Trading","Retail Banking","Operations","Treasury","Compliance","IT","Procurement","Legal","Finance","Risk"][i % 10],
    status: ["Active","Under Review","Draft","Approved","Archived"][i % 5],
    cycle: ["Quarterly","Semi-Annual","Annual","Monthly"][i % 4],
    score: 20 + ((i * 11) % 80),
    due: `2026-${String(((i % 12) + 1)).padStart(2,"0")}-${String(((i * 3 + 1) % 28) + 1).padStart(2,"0")}`,
  }));
  const sColor = (s: string) => s === "Active" ? "#10B981" : s === "Approved" ? "#3B82F6" : s === "Under Review" ? "#F59E0B" : s === "Draft" ? "#A855F7" : "#94A3B8";
  const columns: Column<RAU>[] = [
    { id: "id", label: "RAU ID", field: "id", sortable: true, sticky: true, width: 110, render: v => <Box sx={{ fontWeight: 700, color: app.color }}>{v}</Box> },
    { id: "name", label: "RAU Name", field: "name", sortable: true, sticky: true, minWidth: 200, render: v => <Box sx={{ fontWeight: 600 }}>{v}</Box> },
    { id: "unit", label: "Business Unit", field: "unit", sortable: true, filterable: true },
    { id: "owner", label: "Owner", field: "owner", sortable: true, filterable: true },
    { id: "cycle", label: "Review Cycle", field: "cycle", sortable: true, filterType: "select" as const,
      filterOptions: ["Quarterly","Semi-Annual","Annual","Monthly"].map(v => ({ label: v, value: v })) },
    { id: "status", label: "Status", field: "status", sortable: true, filterType: "select" as const,
      filterOptions: ["Active","Under Review","Draft","Approved","Archived"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${sColor(v)}1A`, color: sColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "score", label: "Risk Score", field: "score", sortable: true, align: "right" as const, width: 120,
      render: (v, row) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <LinearProgress variant="determinate" value={v} sx={{ flex: 1, height: 5, borderRadius: 3, "& .MuiLinearProgress-bar": { backgroundColor: v > 60 ? "#E6392D" : v > 35 ? "#F59E0B" : "#10B981" } }}/>
          <Box sx={{ fontWeight: 700, fontSize: 12, minWidth: 28 }}>{v}</Box>
        </Box>
      ) },
    { id: "due", label: "Next Review", field: "due", sortable: true, width: 120 },
    { id: "actions", label: "", field: "id", sortable: false, width: 50, align: "center" as const, render: () => <IconButton size="small"><MoreHorizontal size={14}/></IconButton> },
  ];
  return <AdvancedTable columns={columns} data={rows} rowKey="id" color={app.color} title="Risk Assessment Units" subtitle={`${rows.length} RAUs across all business units`} defaultRowsPerPage={10} enableColumnManagement enableQuickFilters enableAdvancedFilters enableExport quickFilters={[{ label: "Active", filter: (r) => r.status === "Active" }, { label: "Due Soon", filter: (r) => r.due < "2026-04-01" }, { label: "High Risk", filter: (r) => r.score > 60 }]}/>;
}

function RisksContent({ app }: { app: App }) {
  type Risk = { id: string; title: string; category: string; owner: string; likelihood: string; impact: string; inherent: number; residual: number; status: string; updated: string; };
  const rows: Risk[] = Array.from({ length: 50 }).map((_, i) => ({
    id: `RSK-${3000 + i}`,
    title: ["Vendor concentration risk","Sanctions screening gap","Model drift detection","Phishing simulation result",
            "Cloud key rotation delay","Data exfil attempt","Late control test","Backup drill failure",
            "Privileged access anomaly","AML alert backlog","Regulatory change impact","Counterparty default risk",
            "Liquidity stress scenario","Supply chain disruption","System availability SLA breach"][i % 15],
    category: ["Cyber Risk","Operational","Compliance","Third Party","Financial","Strategic","Reputational","Legal"][i % 8],
    owner: ["M. Aldridge","S. Okafor","J. Chen","P. Volkov","L. Becker","T. Yamada","A. Kumar","R. Williams"][i % 8],
    likelihood: ["Rare","Unlikely","Possible","Likely","Almost Certain"][i % 5],
    impact: ["Negligible","Minor","Moderate","Major","Catastrophic"][i % 5],
    inherent: 20 + ((i * 13) % 80),
    residual: 5 + ((i * 7) % 50),
    status: ["Open","Mitigating","Accepted","Closed","Escalated"][i % 5],
    updated: `2026-06-${String(28 - (i % 28)).padStart(2,"0")}`,
  }));
  const lColor = (l: string) => l === "Almost Certain" || l === "Likely" ? "#E6392D" : l === "Possible" ? "#F59E0B" : "#10B981";
  const sColor = (s: string) => s === "Open" ? "#E6392D" : s === "Mitigating" ? "#F59E0B" : s === "Accepted" ? "#3B82F6" : s === "Escalated" ? "#A855F7" : "#10B981";
  const columns: Column<Risk>[] = [
    { id: "id", label: "Risk ID", field: "id", sortable: true, sticky: true, width: 110, render: v => <Box sx={{ fontWeight: 700, color: app.color }}>{v}</Box> },
    { id: "title", label: "Risk Title", field: "title", sortable: true, sticky: true, minWidth: 200, render: v => <Box sx={{ fontWeight: 600 }}>{v}</Box> },
    { id: "category", label: "Category", field: "category", sortable: true, filterType: "select" as const,
      filterOptions: ["Cyber Risk","Operational","Compliance","Third Party","Financial","Strategic","Reputational","Legal"].map(v => ({ label: v, value: v })) },
    { id: "owner", label: "Owner", field: "owner", sortable: true, filterable: true },
    { id: "likelihood", label: "Likelihood", field: "likelihood", sortable: true, filterType: "select" as const,
      filterOptions: ["Rare","Unlikely","Possible","Likely","Almost Certain"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${lColor(v)}1A`, color: lColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "impact", label: "Impact", field: "impact", sortable: true, filterType: "select" as const,
      filterOptions: ["Negligible","Minor","Moderate","Major","Catastrophic"].map(v => ({ label: v, value: v })) },
    { id: "inherent", label: "Inherent", field: "inherent", sortable: true, align: "right" as const, width: 100,
      render: v => <Box sx={{ fontWeight: 700, color: v > 60 ? "#E6392D" : v > 35 ? "#F59E0B" : "#10B981" }}>{v}</Box> },
    { id: "residual", label: "Residual", field: "residual", sortable: true, align: "right" as const, width: 100,
      render: v => <Box sx={{ fontWeight: 700, color: v > 40 ? "#E6392D" : v > 20 ? "#F59E0B" : "#10B981" }}>{v}</Box> },
    { id: "status", label: "Status", field: "status", sortable: true, filterType: "select" as const,
      filterOptions: ["Open","Mitigating","Accepted","Closed","Escalated"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${sColor(v)}1A`, color: sColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "updated", label: "Updated", field: "updated", sortable: true, width: 110 },
    { id: "actions", label: "", field: "id", sortable: false, width: 50, align: "center" as const, render: () => <IconButton size="small"><MoreHorizontal size={14}/></IconButton> },
  ];
  return <AdvancedTable columns={columns} data={rows} rowKey="id" color={app.color} title="Risk Register" subtitle={`${rows.length} risks tracked`} defaultRowsPerPage={10} enableColumnManagement enableQuickFilters enableAdvancedFilters enableExport quickFilters={[{ label: "Open Risks", filter: r => r.status === "Open" }, { label: "Escalated", filter: r => r.status === "Escalated" }, { label: "High Inherent", filter: r => r.inherent > 60 }, { label: "My Risks", filter: r => r.owner === "M. Aldridge" }]}/>;
}

function ControlsContent({ app }: { app: App }) {
  type Control = { id: string; name: string; type: string; owner: string; frequency: string; effectiveness: string; design: string; lastTested: string; nextTest: string; linked: number; };
  const rows: Control[] = Array.from({ length: 45 }).map((_, i) => ({
    id: `CTL-${4000 + i}`,
    name: ["Access review — privileged accounts","Encryption at rest — S3 buckets","Patch management — OS critical",
           "Vendor due diligence — onboarding","Transaction monitoring — AML threshold","Segregation of duties — payments",
           "Change management — prod deployments","Business continuity — DR test","Data retention — PII purge",
           "Incident response — SIRT activation","Password policy enforcement","MFA — remote access",
           "Log aggregation — SIEM ingestion","Phishing simulation — awareness","Backup integrity verification"][i % 15],
    type: ["Preventive","Detective","Corrective","Directive"][i % 4],
    owner: ["M. Aldridge","S. Okafor","J. Chen","P. Volkov","L. Becker","T. Yamada","A. Kumar","R. Williams"][i % 8],
    frequency: ["Daily","Weekly","Monthly","Quarterly","Annual"][i % 5],
    effectiveness: ["Effective","Partially Effective","Ineffective","Not Tested"][i % 4],
    design: ["Adequate","Inadequate","Partially Adequate"][i % 3],
    lastTested: `2026-0${(i % 5) + 1}-${String((i % 20) + 1).padStart(2,"0")}`,
    nextTest: `2026-${String(((i + 4) % 12) + 1).padStart(2,"0")}-01`,
    linked: 1 + (i % 8),
  }));
  const eColor = (e: string) => e === "Effective" ? "#10B981" : e === "Partially Effective" ? "#F59E0B" : e === "Ineffective" ? "#E6392D" : "#94A3B8";
  const tColor = (t: string) => t === "Preventive" ? "#3B82F6" : t === "Detective" ? "#A855F7" : t === "Corrective" ? "#F59E0B" : "#64748B";
  const columns: Column<Control>[] = [
    { id: "id", label: "Control ID", field: "id", sortable: true, sticky: true, width: 110, render: v => <Box sx={{ fontWeight: 700, color: app.color }}>{v}</Box> },
    { id: "name", label: "Control Name", field: "name", sortable: true, sticky: true, minWidth: 220, render: v => <Box sx={{ fontWeight: 600 }}>{v}</Box> },
    { id: "type", label: "Type", field: "type", sortable: true, filterType: "select" as const,
      filterOptions: ["Preventive","Detective","Corrective","Directive"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${tColor(v)}1A`, color: tColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "owner", label: "Owner", field: "owner", sortable: true, filterable: true },
    { id: "frequency", label: "Frequency", field: "frequency", sortable: true, filterType: "select" as const,
      filterOptions: ["Daily","Weekly","Monthly","Quarterly","Annual"].map(v => ({ label: v, value: v })) },
    { id: "design", label: "Design", field: "design", sortable: true, filterType: "select" as const,
      filterOptions: ["Adequate","Inadequate","Partially Adequate"].map(v => ({ label: v, value: v })) },
    { id: "effectiveness", label: "Effectiveness", field: "effectiveness", sortable: true, filterType: "select" as const,
      filterOptions: ["Effective","Partially Effective","Ineffective","Not Tested"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${eColor(v)}1A`, color: eColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "lastTested", label: "Last Tested", field: "lastTested", sortable: true, width: 120 },
    { id: "nextTest", label: "Next Test", field: "nextTest", sortable: true, width: 120 },
    { id: "linked", label: "Linked Risks", field: "linked", sortable: true, align: "right" as const, width: 110, render: v => <Box sx={{ fontWeight: 700 }}>{v}</Box> },
    { id: "actions", label: "", field: "id", sortable: false, width: 50, align: "center" as const, render: () => <IconButton size="small"><MoreHorizontal size={14}/></IconButton> },
  ];
  return <AdvancedTable columns={columns} data={rows} rowKey="id" color={app.color} title="Controls Library" subtitle={`${rows.length} controls defined`} defaultRowsPerPage={10} enableColumnManagement enableQuickFilters enableAdvancedFilters enableExport quickFilters={[{ label: "Effective", filter: r => r.effectiveness === "Effective" }, { label: "Ineffective", filter: r => r.effectiveness === "Ineffective" }, { label: "Not Tested", filter: r => r.effectiveness === "Not Tested" }, { label: "Preventive", filter: r => r.type === "Preventive" }]}/>;
}

function MCRsContent({ app }: { app: App }) {
  type MCR = { id: string; title: string; requestor: string; impact: string; status: string; priority: string; submitted: string; decision: string; riskRating: number; };
  const rows: MCR[] = Array.from({ length: 35 }).map((_, i) => ({
    id: `MCR-${5000 + i}`,
    title: ["Core banking platform upgrade","AML engine parameter change","Data retention policy update",
            "New payment corridor — SEA","KYC vendor switch — Jumio","Cloud migration — batch jobs",
            "API gateway versioning change","Credit model recalibration","Customer onboarding redesign",
            "Sanctions list update — OFAC","Reporting framework migration","Access model restructure"][i % 12],
    requestor: ["M. Aldridge","S. Okafor","J. Chen","P. Volkov","L. Becker","T. Yamada","A. Kumar","R. Williams"][i % 8],
    impact: ["Technology","Compliance","Operations","Finance","Customer","Regulatory"][i % 6],
    status: ["Submitted","Under Review","Approved","Rejected","Implemented","Withdrawn"][i % 6],
    priority: ["Critical","High","Medium","Low"][i % 4],
    submitted: `2026-0${(i % 5) + 1}-${String((i % 20) + 1).padStart(2,"0")}`,
    decision: i % 6 <= 1 ? "—" : `2026-0${(i % 4) + 2}-${String((i % 15) + 1).padStart(2,"0")}`,
    riskRating: 10 + ((i * 9) % 90),
  }));
  const pColor = (p: string) => p === "Critical" ? "#E6392D" : p === "High" ? "#F59E0B" : p === "Medium" ? "#3B82F6" : "#10B981";
  const sColor = (s: string) => s === "Approved" || s === "Implemented" ? "#10B981" : s === "Rejected" || s === "Withdrawn" ? "#94A3B8" : s === "Under Review" ? "#F59E0B" : "#3B82F6";
  const columns: Column<MCR>[] = [
    { id: "id", label: "MCR ID", field: "id", sortable: true, sticky: true, width: 110, render: v => <Box sx={{ fontWeight: 700, color: app.color }}>{v}</Box> },
    { id: "title", label: "Change Title", field: "title", sortable: true, sticky: true, minWidth: 200, render: v => <Box sx={{ fontWeight: 600 }}>{v}</Box> },
    { id: "requestor", label: "Requestor", field: "requestor", sortable: true, filterable: true },
    { id: "impact", label: "Impact Area", field: "impact", sortable: true, filterType: "select" as const,
      filterOptions: ["Technology","Compliance","Operations","Finance","Customer","Regulatory"].map(v => ({ label: v, value: v })) },
    { id: "priority", label: "Priority", field: "priority", sortable: true, filterType: "select" as const,
      filterOptions: ["Critical","High","Medium","Low"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${pColor(v)}1A`, color: pColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "status", label: "Status", field: "status", sortable: true, filterType: "select" as const,
      filterOptions: ["Submitted","Under Review","Approved","Rejected","Implemented","Withdrawn"].map(v => ({ label: v, value: v })),
      render: v => <Chip size="small" label={v} sx={{ bgcolor: `${sColor(v)}1A`, color: sColor(v), fontWeight: 700, height: 20 }}/> },
    { id: "riskRating", label: "Risk Rating", field: "riskRating", sortable: true, align: "right" as const, width: 110,
      render: (v, row) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <LinearProgress variant="determinate" value={v} sx={{ flex: 1, height: 5, borderRadius: 3, "& .MuiLinearProgress-bar": { backgroundColor: pColor(row.priority) } }}/>
          <Box sx={{ fontWeight: 700, fontSize: 12, minWidth: 28 }}>{v}</Box>
        </Box>
      ) },
    { id: "submitted", label: "Submitted", field: "submitted", sortable: true, width: 110 },
    { id: "decision", label: "Decision Date", field: "decision", sortable: true, width: 120 },
    { id: "actions", label: "", field: "id", sortable: false, width: 50, align: "center" as const, render: () => <IconButton size="small"><MoreHorizontal size={14}/></IconButton> },
  ];
  return <AdvancedTable columns={columns} data={rows} rowKey="id" color={app.color} title="Material Change Requests" subtitle={`${rows.length} change requests`} defaultRowsPerPage={10} enableColumnManagement enableQuickFilters enableAdvancedFilters enableExport quickFilters={[{ label: "Under Review", filter: r => r.status === "Under Review" }, { label: "Critical Priority", filter: r => r.priority === "Critical" }, { label: "Approved", filter: r => r.status === "Approved" || r.status === "Implemented" }]}/>;
}

function HeatmapContent({ app }: { app: App }) {
  const grid = Array.from({ length: 25 }).map((_, i) => 1 + ((i*7) % 18));
  return (
    <Card><CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
      <Box sx={{ fontWeight: 700, fontSize: { xs: 14, md: 15 }, mb: 0.5 }}>Risk heat map</Box>
      <Box sx={{ fontSize: { xs: 11, md: 12 }, color: "text.secondary", mb: 2 }}>Likelihood × Impact</Box>
      <Box sx={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 1 }}>
        <Box sx={{ display: "grid", gridTemplateRows: "repeat(5, 1fr)", fontSize: 10.5, color: "text.secondary", textAlign: "right", pr: 1, alignItems: "center" }}>
          <Box>Severe</Box><Box>Major</Box><Box>Moderate</Box><Box>Minor</Box><Box>Trivial</Box>
        </Box>
        <Box sx={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 0.75 }}>
          {grid.map((v, i) => {
            const row = Math.floor(i / 5), col = i % 5;
            const heat = (4 - row) + col;
            const bg = heat <= 2 ? "#10B98122" : heat <= 4 ? "#F59E0B22" : heat <= 6 ? "#E6392D22" : "#E6392D44";
            const fg = heat <= 2 ? "#10B981" : heat <= 4 ? "#F59E0B" : "#E6392D";
            return (
              <Box key={i} sx={{
                aspectRatio: "1", borderRadius: 1.5, display: "grid", placeItems: "center",
                bgcolor: bg, color: fg, fontWeight: 700, fontSize: 14,
                border: "1px solid", borderColor: `${fg}33`,
                "&:hover": { transform: "scale(1.05)" }, transition: "transform .15s",
              }}>{v}</Box>
            );
          })}
        </Box>
      </Box>
    </CardContent></Card>
  );
}

function KRIContent({ app }: { app: App }) {
  const kris = [
    { name: "Failed transactions / 10k", value: 12.4, threshold: 15, ok: true },
    { name: "Phishing click-through %", value: 1.8, threshold: 2.0, ok: true },
    { name: "AML alert backlog", value: 142, threshold: 100, ok: false },
    { name: "Privileged access changes", value: 38, threshold: 50, ok: true },
  ];
  return (
    <Grid container spacing={{ xs: 1.5, md: 2.5 }}>
      {kris.map(k => (
        <Grid key={k.name} size={{ xs: 12, sm: 6 }}>
          <Card><CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
            <Box sx={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 0.5 }}>
              <Box sx={{ fontWeight: 700, fontSize: { xs: 13, md: 14 } }}>{k.name}</Box>
              <Chip size="small" label={k.ok ? "OK" : "Breach"}
                sx={{ bgcolor: k.ok ? "rgba(16,163,74,0.12)" : "rgba(230,57,45,0.12)",
                  color: k.ok ? "#16A34A" : "#E6392D", fontWeight: 700, height: { xs: 18, md: 20 }, fontSize: { xs: 10, md: 11 } }}/>
            </Box>
            <Box sx={{ display: "flex", alignItems: "baseline", gap: 1, mt: 1 }}>
              <Box sx={{ fontSize: { xs: 24, md: 30 }, fontWeight: 700 }}>{k.value}</Box>
              <Box sx={{ fontSize: { xs: 11, md: 12 }, color: "text.secondary" }}>/ {k.threshold}</Box>
            </Box>
            <LinearProgress variant="determinate" value={Math.min(100,(k.value/k.threshold)*100)}
              sx={{ mt: 1.5, height: { xs: 5, md: 6 }, borderRadius: 3, bgcolor: "action.hover",
                "& .MuiLinearProgress-bar": { backgroundColor: k.ok ? "#16A34A" : "#E6392D" }}}/>
          </CardContent></Card>
        </Grid>
      ))}
    </Grid>
  );
}

function IncidentsContent({ app }: { app: App }) {
  const events = [
    { id: "INC-0184", sev: "Critical", title: "Production outage — Payment Gateway", time: "2h" },
    { id: "INC-0183", sev: "High", title: "Data exfil attempt — flagged by DLP", time: "5h" },
    { id: "INC-0182", sev: "Medium", title: "Vendor SLA breach — KYC provider", time: "1d" },
    { id: "INC-0181", sev: "High", title: "Sanctions hit — wire transfer", time: "1d" },
    { id: "INC-0180", sev: "Low", title: "Phishing attempt — blocked", time: "2d" },
  ];
  const c = (s: string) => s === "Critical" ? "#E6392D" : s === "High" ? "#F59E0B" : s === "Medium" ? "#3B82F6" : "#10B981";
  return (
    <Card><CardContent sx={{ p: { xs: 1, md: 2 } }}>
      <Stack divider={<Divider/>} spacing={0}>
        {events.map(e => (
          <Box key={e.id} sx={{ py: { xs: 1.25, md: 1.5 }, display: "flex", alignItems: "center", gap: { xs: 1, md: 2 }, flexWrap: "wrap" }}>
            <Box sx={{ width: { xs: 32, md: 36 }, height: { xs: 32, md: 36 }, borderRadius: 2,
              bgcolor: `${c(e.sev)}1A`, color: c(e.sev), display: "grid", placeItems: "center", fontWeight: 700, fontSize: { xs: 13, md: 14 } }}>
              {e.sev[0]}
            </Box>
            <Box sx={{ display: { xs: "none", sm: "block" }, minWidth: 80, fontSize: { xs: 10, md: 11 }, color: "text.secondary" }}>{e.id}</Box>
            <Box sx={{ flex: 1, fontWeight: 600, fontSize: { xs: 12.5, md: 13.5 }, minWidth: 180 }}>{e.title}</Box>
            <Chip size="small" label={e.sev}
              sx={{ bgcolor: `${c(e.sev)}1A`, color: c(e.sev), fontWeight: 700, height: { xs: 18, md: 20 }, fontSize: { xs: 10, md: 11 } }}/>
            <Box sx={{ display: { xs: "none", md: "block" }, fontSize: 12, color: "text.secondary" }}>{e.time} ago</Box>
            <IconButton size="small"><MoreHorizontal size={14}/></IconButton>
          </Box>
        ))}
      </Stack>
    </CardContent></Card>
  );
}

function WorkflowsContent({ app }: { app: App }) {
  const stages = [
    { name: "Draft", count: 12, color: "#64748B" },
    { name: "Review", count: 7, color: "#3B82F6" },
    { name: "Approved", count: 4, color: "#A855F7" },
    { name: "Active", count: 18, color: "#10B981" },
    { name: "Closed", count: 26, color: "#94A3B8" },
  ];
  return (
    <Grid container spacing={{ xs: 1.5, md: 2 }}>
      {stages.map(s => (
        <Grid key={s.name} size={{ xs: 12, sm: 6, md: 4, lg: 2.4 }}>
          <Card sx={{ borderTop: `4px solid ${s.color}` }}>
            <CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <Box sx={{ fontWeight: 700 }}>{s.name}</Box>
                <Chip size="small" label={s.count}
                  sx={{ bgcolor: `${s.color}1A`, color: s.color, fontWeight: 700 }}/>
              </Box>
              <Stack spacing={1} sx={{ mt: 1.5 }}>
                {[1,2,3].map(i => (
                  <Box key={i} sx={{ p: 1.25, borderRadius: 1.5, bgcolor: "action.hover" }}>
                    <Box sx={{ fontSize: 12.5, fontWeight: 600 }}>Item #{(s.count - i + 1).toString().padStart(3,"0")}</Box>
                    <Box sx={{ fontSize: 11, color: "text.secondary", mt: 0.25 }}>Updated 1d ago</Box>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}

function AuditLogContent({ app }: { app: App }) {
  type AuditLog = {
    id: number;
    timestamp: string;
    user: string;
    action: string;
    target: string;
    details: string;
    ip: string;
    category: string;
  };

  const logs: AuditLog[] = Array.from({ length: 100 }).map((_, i) => ({
    id: 1000 + i,
    timestamp: new Date(Date.now() - i * 1000 * 60 * 15).toISOString().slice(0, 16).replace('T', ' '),
    user: ["M. Aldridge","S. Okafor","J. Chen","P. Volkov","L. Becker","T. Yamada","AI Copilot","System"][i % 8],
    action: ["Created","Updated","Deleted","Approved","Rejected","Exported","Imported","Commented","Uploaded","Downloaded"][i % 10],
    target: ["RCSA Q2-EMEA","INC-0182","CTL-4421","Risk Register","Compliance Matrix","Evidence File","Weekly Digest","Severity Field","User Profile","Policy Document"][i % 10],
    details: ["Modified 3 fields","Added new record","Removed attachment","Approved workflow step","Downloaded PDF report","Uploaded evidence","Changed status to Active","Added comment","Imported 45 records","Exported to CSV"][i % 10],
    ip: `192.168.1.${(i % 200) + 1}`,
    category: ["Records","Incidents","Controls","Assessments","Reports","Users","System","Integrations"][i % 8],
  }));

  const columns: Column<AuditLog>[] = [
    {
      id: "timestamp",
      label: "Timestamp",
      field: "timestamp",
      sortable: true,
      sticky: true,
      width: 150,
      render: (value) => <Box sx={{ fontFamily: "monospace", fontSize: 12 }}>{value}</Box>,
    },
    {
      id: "user",
      label: "User",
      field: "user",
      sortable: true,
      filterType: "select",
      width: 140,
      filterOptions: [
        { label: "M. Aldridge", value: "M. Aldridge" },
        { label: "S. Okafor", value: "S. Okafor" },
        { label: "J. Chen", value: "J. Chen" },
        { label: "P. Volkov", value: "P. Volkov" },
        { label: "AI Copilot", value: "AI Copilot" },
        { label: "System", value: "System" },
      ],
      render: (value) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Avatar sx={{ width: 24, height: 24, fontSize: 10, bgcolor: app.color }}>
            {value.slice(0, 2).toUpperCase()}
          </Avatar>
          <Box sx={{ fontWeight: 600 }}>{value}</Box>
        </Box>
      ),
    },
    {
      id: "action",
      label: "Action",
      field: "action",
      sortable: true,
      filterType: "select",
      width: 120,
      filterOptions: [
        { label: "Created", value: "Created" },
        { label: "Updated", value: "Updated" },
        { label: "Deleted", value: "Deleted" },
        { label: "Approved", value: "Approved" },
        { label: "Exported", value: "Exported" },
      ],
      render: (value) => {
        const color = value === "Created" ? "#10B981" :
                     value === "Deleted" ? "#E6392D" :
                     value === "Updated" ? "#3B82F6" :
                     value === "Approved" ? "#A855F7" : "#64748B";
        return (
          <Chip size="small" label={value}
            sx={{ bgcolor: `${color}1A`, color, fontWeight: 700, height: 20 }}/>
        );
      },
    },
    {
      id: "target",
      label: "Target",
      field: "target",
      sortable: true,
      minWidth: 160,
      render: (value) => <Box sx={{ fontWeight: 600 }}>{value}</Box>,
    },
    {
      id: "category",
      label: "Category",
      field: "category",
      sortable: true,
      filterType: "select",
      filterOptions: [
        { label: "Records", value: "Records" },
        { label: "Incidents", value: "Incidents" },
        { label: "Controls", value: "Controls" },
        { label: "Reports", value: "Reports" },
        { label: "System", value: "System" },
      ],
    },
    {
      id: "details",
      label: "Details",
      field: "details",
      sortable: false,
      minWidth: 200,
    },
    {
      id: "ip",
      label: "IP Address",
      field: "ip",
      sortable: true,
      width: 130,
      render: (value) => <Box sx={{ fontFamily: "monospace", fontSize: 11.5, color: "text.secondary" }}>{value}</Box>,
    },
  ];

  return (
    <AdvancedTable
      columns={columns}
      data={logs}
      rowKey="id"
      color={app.color}
      title="Audit Trail"
      subtitle="Immutable change history and activity log"
      defaultRowsPerPage={15}
      enableColumnManagement={true}
      enableQuickFilters={true}
      enableAdvancedFilters={true}
      enableExport={true}
      quickFilters={[
        { label: "My Activity", filter: (log) => log.user === "M. Aldridge" },
        { label: "System Events", filter: (log) => log.user === "System" || log.user === "AI Copilot" },
        { label: "Recent (Last Hour)", filter: (log) => new Date(log.timestamp) > new Date(Date.now() - 60 * 60 * 1000) },
        { label: "Critical Actions", filter: (log) => log.action === "Deleted" || log.action === "Approved" },
      ]}
    />
  );
}

function NotificationsContent({ app }: { app: App }) {
  const rules = [
    { name: "Critical incidents", channel: "Slack + Email", on: true },
    { name: "KRI threshold breach", channel: "Slack", on: true },
    { name: "Assessment due in 48h", channel: "Email", on: true },
    { name: "Policy attestation reminder", channel: "Email", on: false },
    { name: "Weekly digest", channel: "Email", on: true },
  ];
  return (
    <Card><CardContent sx={{ p: { xs: 1, md: 2 } }}>
      <Stack divider={<Divider/>} spacing={0}>
        {rules.map(r => (
          <Box key={r.name} sx={{ py: { xs: 1.25, md: 1.5 }, display: "flex", alignItems: "center", gap: { xs: 1.5, md: 2 } }}>
            <Bell size={16} color={r.on ? app.color : undefined} opacity={r.on ? 1 : 0.4}/>
            <Box sx={{ flex: 1 }}>
              <Box sx={{ fontWeight: 600, fontSize: { xs: 12.5, md: 13.5 } }}>{r.name}</Box>
              <Box sx={{ fontSize: { xs: 10.5, md: 11.5 }, color: "text.secondary" }}>{r.channel}</Box>
            </Box>
            <Chip size="small" label={r.on ? "Active" : "Off"} sx={{
              bgcolor: r.on ? `${app.color}1A` : "action.hover",
              color: r.on ? app.color : "text.secondary", fontWeight: 700,
              height: { xs: 18, md: 20 }, fontSize: { xs: 10, md: 11 },
            }}/>
          </Box>
        ))}
      </Stack>
    </CardContent></Card>
  );
}

function ComplianceMapContent({ app }: { app: App }) {
  const frameworks = [
    { name: "SOX", cov: 96 }, { name: "GDPR", cov: 92 }, { name: "DORA", cov: 84 },
    { name: "ISO 27001", cov: 95 }, { name: "Basel III", cov: 98 },
  ];
  return (
    <Card><CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
      <Stack spacing={{ xs: 1.5, md: 2 }}>
        {frameworks.map(f => (
          <Box key={f.name}>
            <Box sx={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, mb: 0.5 }}>
              <Box sx={{ fontWeight: 700 }}>{f.name}</Box>
              <Box sx={{ color: "text.secondary" }}>{f.cov}% coverage</Box>
            </Box>
            <LinearProgress variant="determinate" value={f.cov}
              sx={{ height: 8, borderRadius: 4, bgcolor: "action.hover",
                "& .MuiLinearProgress-bar": {
                  background: f.cov > 90 ? "linear-gradient(90deg,#10B981,#22D3EE)" :
                    `linear-gradient(90deg,#F59E0B,${app.color})` } }}/>
          </Box>
        ))}
      </Stack>
    </CardContent></Card>
  );
}

function GenericFeature({ app, title, description }: { app: App; title: string; description?: string }) {
  return (
    <Card><CardContent>
      <Box sx={{ p: 3, textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center" }}>
        <Box sx={{ mb: 2, width: 54, height: 54, borderRadius: 3,
          background: `${app.color}1A`, color: app.color, display: "grid", placeItems: "center" }}>
          <Star size={22}/>
        </Box>
        <Box sx={{ fontWeight: 700, fontSize: 16, color: "text.primary" }}>{title}</Box>
        {description && <Box sx={{ fontSize: 13, color: "text.secondary", mt: 0.5, maxWidth: 480, mx: "auto" }}>{description}</Box>}
        <Button variant="outlined" size="small" sx={{ mt: 2, borderColor: app.color, color: app.color }}>
          Configure feature
        </Button>
      </Box>
    </CardContent></Card>
  );
}

function WSNavLink({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Box sx={{
      display: { xs: "none", lg: "flex" }, alignItems: "center", gap: 0.75,
      px: 1.25, py: 0.75, borderRadius: 1.5, cursor: "pointer", fontSize: 13.5, fontWeight: 500,
      "&:hover": { bgcolor: "rgba(255,255,255,0.1)" },
    }}>
      {icon}
      {children}
    </Box>
  );
}
