import { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogActions, Button, Box, IconButton, TextField,
  Switch, FormControlLabel, Stack, Divider, MenuItem, Chip,
} from "@mui/material";
import { X, Check, Settings2 } from "lucide-react";
import { BRAND } from "./theme";

type GroupSettings = {
  tag: string;
  tagColor: string;
  allowAppCreation: boolean;
  requireApproval: boolean;
  autoArchive: boolean;
  archiveDays: number;
};

export function ConfigureGroupModal({
  open,
  onClose,
  groupName,
  groupId,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  groupName: string;
  groupId: string;
  onSave: (groupId: string, settings: GroupSettings) => void;
}) {
  const [tag, setTag] = useState("Tier 1");
  const [tagColor, setTagColor] = useState("#E6392D");
  const [allowAppCreation, setAllowAppCreation] = useState(true);
  const [requireApproval, setRequireApproval] = useState(false);
  const [autoArchive, setAutoArchive] = useState(false);
  const [archiveDays, setArchiveDays] = useState(90);

  const tagOptions = [
    { label: "Tier 1", color: "#E6392D" },
    { label: "Tier 2", color: "#F59E0B" },
    { label: "Tier 3", color: "#64748B" },
    { label: "Regulated", color: "#3B82F6" },
    { label: "Critical", color: "#E6392D" },
    { label: "Standard", color: "#10B981" },
  ];

  const handleSave = () => {
    onSave(groupId, {
      tag,
      tagColor,
      allowAppCreation,
      requireApproval,
      autoArchive,
      archiveDays,
    });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth
      PaperProps={{ sx: { borderRadius: "6px" } }}>
      <Box sx={{
        position: "relative",
        background: `linear-gradient(120deg, ${BRAND.primary} 0%, ${BRAND.primaryDeep} 100%)`,
        color: "#fff", p: 3,
      }}>
        <IconButton size="small" onClick={onClose}
          sx={{ position: "absolute", top: 12, right: 12, color: "#fff" }}>
          <X size={18}/>
        </IconButton>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box sx={{
            width: 48, height: 48, borderRadius: 2,
            bgcolor: "rgba(255,255,255,0.15)",
            display: "grid", placeItems: "center",
          }}>
            <Settings2 size={22}/>
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Box sx={{ fontSize: 20, fontWeight: 700 }}>Configure Domain</Box>
            <Box sx={{ fontSize: 13, opacity: 0.8 }}>{groupName}</Box>
          </Box>
        </Box>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        <Stack spacing={3}>
          {/* Classification */}
          <Box>
            <Box sx={{ fontSize: 14, fontWeight: 700, mb: 1.5, color: BRAND.navy }}>
              Classification
            </Box>
            <TextField
              select
              fullWidth
              label="Domain Tag"
              value={tag}
              onChange={(e) => {
                setTag(e.target.value);
                const option = tagOptions.find(t => t.label === e.target.value);
                if (option) setTagColor(option.color);
              }}
            >
              {tagOptions.map((opt) => (
                <MenuItem key={opt.label} value={opt.label}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Box sx={{ width: 12, height: 12, borderRadius: "50%", bgcolor: opt.color }}/>
                    {opt.label}
                  </Box>
                </MenuItem>
              ))}
            </TextField>
            <Box sx={{ mt: 1.5 }}>
              <Chip
                label={tag}
                sx={{ bgcolor: `${tagColor}1A`, color: tagColor, fontWeight: 700 }}
              />
            </Box>
          </Box>

          <Divider/>

          {/* Permissions */}
          <Box>
            <Box sx={{ fontSize: 14, fontWeight: 700, mb: 1.5, color: BRAND.navy }}>
              Permissions
            </Box>
            <Stack spacing={1.5}>
              <FormControlLabel
                control={
                  <Switch
                    checked={allowAppCreation}
                    onChange={(e) => setAllowAppCreation(e.target.checked)}
                  />
                }
                label={
                  <Box>
                    <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>Allow app creation</Box>
                    <Box sx={{ fontSize: 12, color: "text.secondary" }}>
                      Members can create new applications in this domain
                    </Box>
                  </Box>
                }
              />
              <FormControlLabel
                control={
                  <Switch
                    checked={requireApproval}
                    onChange={(e) => setRequireApproval(e.target.checked)}
                  />
                }
                label={
                  <Box>
                    <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>Require approval</Box>
                    <Box sx={{ fontSize: 12, color: "text.secondary" }}>
                      New apps require admin approval before activation
                    </Box>
                  </Box>
                }
              />
            </Stack>
          </Box>

          <Divider/>

          {/* Automation */}
          <Box>
            <Box sx={{ fontSize: 14, fontWeight: 700, mb: 1.5, color: BRAND.navy }}>
              Automation
            </Box>
            <FormControlLabel
              control={
                <Switch
                  checked={autoArchive}
                  onChange={(e) => setAutoArchive(e.target.checked)}
                />
              }
              label={
                <Box>
                  <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>Auto-archive inactive apps</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary" }}>
                    Automatically archive apps with no activity
                  </Box>
                </Box>
              }
            />
            {autoArchive && (
              <TextField
                type="number"
                label="Archive after (days)"
                value={archiveDays}
                onChange={(e) => setArchiveDays(parseInt(e.target.value) || 90)}
                size="small"
                sx={{ mt: 1.5, maxWidth: 200 }}
                inputProps={{ min: 30, max: 365 }}
              />
            )}
          </Box>
        </Stack>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: "divider" }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          variant="contained"
          startIcon={<Check size={14}/>}
          onClick={handleSave}
          sx={{ bgcolor: BRAND.primary, "&:hover": { bgcolor: BRAND.primaryDeep } }}
        >
          Save Configuration
        </Button>
      </DialogActions>
    </Dialog>
  );
}
