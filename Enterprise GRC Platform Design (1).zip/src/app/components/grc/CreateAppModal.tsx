import {
  Dialog, DialogContent, DialogActions, Button, Box, Stepper, Step, StepLabel, TextField, Grid,
  Chip, IconButton, Stack, Card, Switch, Divider, InputBase, Tabs, Tab, Tooltip,
} from "@mui/material";
import { useMemo, useState } from "react";
import {
  X, Check, Search, Sparkles, Star, ToggleLeft, ToggleRight, Crown,
} from "lucide-react";
import { BRAND } from "./theme";
import { FEATURE_LIBRARY, FEATURE_CATEGORIES, Feature } from "./features";

const colors = ["#E6392D", "#F59E0B", "#3B82F6", "#10B981", "#A855F7", "#06B6D4", "#EC4899", "#64748B"];

export function CreateAppModal({
  open, onClose, groupName,
}: { open: boolean; onClose: () => void; groupName?: string }) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState(colors[0]);
  const [enabled, setEnabled] = useState<Record<string, boolean>>(
    () => Object.fromEntries(FEATURE_LIBRARY.map(f => [f.id, !!f.defaultOn]))
  );
  const [category, setCategory] = useState<Feature["category"] | "All">("All");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return FEATURE_LIBRARY.filter(f =>
      (category === "All" || f.category === category) &&
      (query === "" || f.name.toLowerCase().includes(query.toLowerCase()) ||
        f.description.toLowerCase().includes(query.toLowerCase()))
    );
  }, [category, query]);

  const enabledList = FEATURE_LIBRARY.filter(f => enabled[f.id]);
  const counts = FEATURE_CATEGORIES.reduce<Record<string, number>>((acc, c) => {
    acc[c] = FEATURE_LIBRARY.filter(f => f.category === c && enabled[f.id]).length;
    return acc;
  }, {});

  const steps = ["Identity", "Features", "Review"];

  const toggle = (id: string) => setEnabled(s => ({ ...s, [id]: !s[id] }));
  const enableAll = () => setEnabled(Object.fromEntries(FEATURE_LIBRARY.map(f => [f.id, true])));
  const resetDefaults = () =>
    setEnabled(Object.fromEntries(FEATURE_LIBRARY.map(f => [f.id, !!f.defaultOn])));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth
      PaperProps={{ sx: { borderRadius: "6px", overflow: "hidden" } }}>
      <Box sx={{
        position: "relative",
        background: `linear-gradient(120deg, ${BRAND.primary} 0%, ${BRAND.primaryDeep} 100%)`,
        color: "#fff", p: 3,
      }}>
        <IconButton size="small" onClick={onClose} sx={{ position: "absolute", top: 12, right: 12, color: "#fff" }}>
          <X size={18}/>
        </IconButton>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box sx={{
            width: 52, height: 52, borderRadius: 3, bgcolor: "rgba(255,255,255,0.15)",
            border: "1px solid rgba(255,255,255,0.25)", display: "grid", placeItems: "center",
            fontWeight: 700, fontSize: 18,
          }}>{(name || "New").slice(0, 1).toUpperCase()}</Box>
          <Box>
            <Box sx={{ fontSize: 20, fontWeight: 700 }}>Create new application</Box>
            <Box sx={{ fontSize: 13, opacity: 0.8 }}>
              {groupName ? `In group · ${groupName}` : "Pick features to enable for this app"}
            </Box>
          </Box>
        </Box>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        <Stepper activeStep={step} sx={{ mb: 3 }}>
          {steps.map(l => <Step key={l}><StepLabel sx={{ "& .MuiStepLabel-label": { fontWeight: 600 } }}>{l}</StepLabel></Step>)}
        </Stepper>

        {step === 0 && (
          <Stack spacing={2.5}>
            <TextField label="Application name" fullWidth placeholder="e.g. Cyber Risk Register"
              value={name} onChange={(e) => setName(e.target.value)} />
            <TextField label="Description" multiline rows={3} fullWidth
              placeholder="Briefly describe the purpose of this application…"
              value={description} onChange={(e) => setDescription(e.target.value)} />
            <Box>
              <Box sx={{ fontSize: 13, fontWeight: 600, mb: 1 }}>Accent color</Box>
              <Stack direction="row" spacing={1}>
                {colors.map(c => (
                  <Box key={c} onClick={() => setColor(c)} sx={{
                    width: 32, height: 32, borderRadius: "50%", cursor: "pointer", bgcolor: c,
                    border: color === c ? "3px solid white" : "3px solid transparent",
                    boxShadow: color === c ? `0 0 0 2px ${c}` : "none",
                    display: "grid", placeItems: "center", color: "#fff",
                  }}>{color === c && <Check size={14}/>}</Box>
                ))}
              </Stack>
            </Box>
            <Box>
              <Box sx={{ fontSize: 13, fontWeight: 600, mb: 1 }}>Tags</Box>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                {["High priority", "Regulated", "Tier 1", "Cyber", "Privacy", "Vendor"].map(t => (
                  <Chip key={t} label={t} size="small" onClick={() => {}} variant="outlined"/>
                ))}
              </Stack>
            </Box>
          </Stack>
        )}

        {step === 1 && (
          <Box>
            {/* Toolbar */}
            <Box sx={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 1.5, mb: 2 }}>
              <Box sx={{
                display: "flex", alignItems: "center", gap: 1, px: 1.25, py: 0.5,
                border: 1, borderColor: "divider", borderRadius: 2, minWidth: 240,
              }}>
                <Search size={15} opacity={0.6}/>
                <InputBase placeholder="Search features…" value={query} onChange={(e) => setQuery(e.target.value)}
                  sx={{ fontSize: 13, flex: 1 }}/>
              </Box>
              <Box sx={{ flex: 1 }}/>
              <Chip size="small" icon={<Check size={11}/>} label={`${enabledList.length} enabled`}
                sx={{ bgcolor: `${color}1A`, color, fontWeight: 700 }}/>
              <Button size="small" startIcon={<ToggleRight size={14}/>} onClick={enableAll}>Enable all</Button>
              <Button size="small" startIcon={<Sparkles size={14}/>} onClick={resetDefaults}>Defaults</Button>
            </Box>

            <Tabs value={category} onChange={(_, v) => setCategory(v)}
              variant="scrollable" scrollButtons="auto"
              sx={{
                borderBottom: 1, borderColor: "divider", mb: 2,
                "& .MuiTabs-indicator": { backgroundColor: color },
                "& .Mui-selected": { color: `${color} !important` },
              }}>
              <Tab label={`All · ${enabledList.length}`} value="All" sx={{ textTransform: "none", fontWeight: 600 }}/>
              {FEATURE_CATEGORIES.map(c => (
                <Tab key={c} value={c}
                  label={`${c} · ${counts[c]}`}
                  sx={{ textTransform: "none", fontWeight: 600 }}/>
              ))}
            </Tabs>

            <Grid container spacing={1.5}>
              {filtered.map(f => {
                const on = !!enabled[f.id];
                const Icon = f.icon;
                return (
                  <Grid key={f.id} size={{ xs: 12, sm: 6 }}>
                    <Card onClick={() => toggle(f.id)} sx={{
                      p: 1.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 1.5,
                      border: on ? `2px solid ${color}` : "2px solid transparent",
                      bgcolor: on ? `${color}0C` : "background.paper",
                      transition: "all .15s",
                      "&:hover": { borderColor: on ? color : `${color}55` },
                    }}>
                      <Box sx={{
                        width: 38, height: 38, borderRadius: 2,
                        bgcolor: on ? color : "action.hover",
                        color: on ? "#fff" : "text.secondary",
                        display: "grid", placeItems: "center",
                      }}>
                        <Icon size={18}/>
                      </Box>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
                          <Box sx={{ fontWeight: 700, fontSize: 13.5 }}>{f.name}</Box>
                          {f.defaultOn && (
                            <Tooltip title="Default feature">
                              <Box sx={{ display: "inline-flex" }}><Star size={11} color="#F59E0B"/></Box>
                            </Tooltip>
                          )}
                          {f.premium && (
                            <Tooltip title="Premium feature">
                              <Box sx={{ display: "inline-flex" }}><Crown size={11} color="#A855F7"/></Box>
                            </Tooltip>
                          )}
                        </Box>
                        <Box sx={{ fontSize: 11.5, color: "text.secondary",
                          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {f.description}
                        </Box>
                      </Box>
                      <Switch
                        checked={on}
                        onClick={(e) => e.stopPropagation()}
                        onChange={() => toggle(f.id)}
                        size="small"
                        sx={{
                          "& .Mui-checked": { color },
                          "& .Mui-checked + .MuiSwitch-track": { backgroundColor: color },
                        }}
                      />
                    </Card>
                  </Grid>
                );
              })}
              {filtered.length === 0 && (
                <Grid size={12}>
                  <Box sx={{ textAlign: "center", py: 4, color: "text.secondary", fontSize: 13 }}>
                    No features match “{query}”.
                  </Box>
                </Grid>
              )}
            </Grid>
          </Box>
        )}

        {step === 2 && (
          <Box>
            <Card sx={{ p: 2.5, mb: 2.5, background: `linear-gradient(135deg,#0A2540,${color})`, color: "#fff" }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                <Box sx={{ width: 52, height: 52, borderRadius: 3, bgcolor: "rgba(255,255,255,0.15)",
                  display: "grid", placeItems: "center", fontWeight: 700, fontSize: 20 }}>
                  {(name || "N").slice(0, 1).toUpperCase()}
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Box sx={{ fontWeight: 700, fontSize: 18 }}>{name || "New application"}</Box>
                  <Box sx={{ fontSize: 12, opacity: 0.8 }}>
                    {groupName ? `Group · ${groupName} · ` : ""}{enabledList.length} features enabled
                  </Box>
                </Box>
                <Chip label={`${enabledList.length}/${FEATURE_LIBRARY.length}`}
                  sx={{ bgcolor: "rgba(255,255,255,0.18)", color: "#fff", fontWeight: 700 }}/>
              </Box>
            </Card>

            {description && (
              <Box sx={{ fontSize: 13.5, color: "text.secondary", mb: 2 }}>{description}</Box>
            )}

            {FEATURE_CATEGORIES.map(c => {
              const items = FEATURE_LIBRARY.filter(f => f.category === c && enabled[f.id]);
              if (items.length === 0) return null;
              return (
                <Box key={c} sx={{ mb: 2 }}>
                  <Box sx={{ fontSize: 11, fontWeight: 700, color: "text.secondary",
                    textTransform: "uppercase", letterSpacing: ".1em", mb: 1 }}>
                    {c} · {items.length}
                  </Box>
                  <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.75 }}>
                    {items.map(f => (
                      <Chip key={f.id} icon={<f.icon size={12}/>} label={f.name}
                        sx={{ bgcolor: `${color}14`, color, fontWeight: 600,
                          "& .MuiChip-icon": { color } }}/>
                    ))}
                  </Box>
                </Box>
              );
            })}
            {enabledList.length === 0 && (
              <Box sx={{ textAlign: "center", py: 3, color: "text.secondary", fontSize: 13 }}>
                No features selected. Go back and enable at least one.
              </Box>
            )}
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: "divider" }}>
        <Button onClick={onClose}>Cancel</Button>
        <Box sx={{ flex: 1 }}/>
        {step > 0 && <Button onClick={() => setStep(step - 1)}>Back</Button>}
        {step < steps.length - 1 ? (
          <Button variant="contained" onClick={() => setStep(step + 1)}
            sx={{ bgcolor: color, "&:hover": { bgcolor: color, filter: "brightness(0.95)" } }}>
            Continue
          </Button>
        ) : (
          <Button variant="contained" onClick={onClose} startIcon={<Check size={14}/>}
            disabled={enabledList.length === 0}
            sx={{ bgcolor: color, "&:hover": { bgcolor: color, filter: "brightness(0.95)" } }}>
            Create application
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
