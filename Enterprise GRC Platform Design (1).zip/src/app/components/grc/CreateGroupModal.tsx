import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Stepper, Step, StepLabel, Box,
  TextField, Grid, Chip, MenuItem, IconButton, Stack, Avatar, ToggleButton, ToggleButtonGroup, Card,
} from "@mui/material";
import { useState } from "react";
import { X, ShieldAlert, Globe2, Building2, Sparkles, Check } from "lucide-react";
import { BRAND } from "./theme";
import { modules } from "./data";

const colors = ["#E6392D", "#F59E0B", "#3B82F6", "#10B981", "#A855F7", "#06B6D4"];
const icons = [ShieldAlert, Globe2, Building2, Sparkles];

export function CreateGroupModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [step, setStep] = useState(0);
  const [color, setColor] = useState(colors[0]);
  const [iconIdx, setIconIdx] = useState(0);
  const [selected, setSelected] = useState(modules.slice(0, 6).map(m => m.id));
  const Icon = icons[iconIdx];

  const toggle = (id: string) =>
    setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth
      PaperProps={{ sx: { borderRadius: "6px", overflow: "hidden" } }}>
      <Box sx={{
        position: "relative",
        background: `linear-gradient(120deg, ${BRAND.primary} 0%, ${BRAND.primaryDeep} 100%)`,
        color: "#fff", p: 3,
      }}>
        <IconButton size="small" onClick={onClose}
          sx={{ position: "absolute", top: 12, right: 12, color: "#fff" }}>
          <X size={18} />
        </IconButton>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box sx={{
            width: 52, height: 52, borderRadius: 3,
            background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.25)",
            display: "grid", placeItems: "center",
          }}>
            <Icon size={24} />
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Box sx={{ fontSize: 20, fontWeight: 700 }}>Create new risk domain</Box>
            <Box sx={{ fontSize: 13, opacity: 0.75 }}>Configure a domain tailored to your program</Box>
          </Box>
        </Box>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        <Stepper activeStep={step} sx={{ mb: 3 }}>
          {["Details", "Identity", "Modules", "Review"].map(l => (
            <Step key={l}><StepLabel sx={{ "& .MuiStepLabel-label": { fontWeight: 600 } }}>{l}</StepLabel></Step>
          ))}
        </Stepper>

        {step === 0 && (
          <Stack spacing={2.5}>
            <TextField label="Domain name" placeholder="e.g. LATAM Banking" fullWidth defaultValue="LATAM Banking" />
            <TextField label="Description" multiline rows={3} fullWidth
              defaultValue="Risk and compliance programs for LATAM retail and commercial banking entities." />
            <Grid container spacing={2}>
              <Grid size={6}>
                <TextField select label="Region" fullWidth defaultValue="LATAM">
                  {["NAM", "LATAM", "EMEA", "APAC", "Global"].map(x => <MenuItem key={x} value={x}>{x}</MenuItem>)}
                </TextField>
              </Grid>
              <Grid size={6}>
                <TextField select label="Criticality" fullWidth defaultValue="Tier 1">
                  {["Tier 1 — Critical", "Tier 2 — High", "Tier 3 — Standard"].map(x => <MenuItem key={x} value={x}>{x}</MenuItem>)}
                </TextField>
              </Grid>
            </Grid>
          </Stack>
        )}

        {step === 1 && (
          <Box>
            <Box sx={{ fontWeight: 600, fontSize: 13, mb: 1 }}>Accent color</Box>
            <Stack direction="row" spacing={1} sx={{ mb: 3 }}>
              {colors.map(c => (
                <Box key={c} onClick={() => setColor(c)} sx={{
                  width: 36, height: 36, borderRadius: "50%", cursor: "pointer", bgcolor: c,
                  border: color === c ? "3px solid white" : "3px solid transparent",
                  boxShadow: color === c ? `0 0 0 2px ${c}` : "none",
                  display: "grid", placeItems: "center", color: "#fff",
                }}>{color === c && <Check size={16}/>}</Box>
              ))}
            </Stack>
            <Box sx={{ fontWeight: 600, fontSize: 13, mb: 1 }}>Icon</Box>
            <Stack direction="row" spacing={1.5}>
              {icons.map((I, i) => (
                <Card key={i} onClick={() => setIconIdx(i)} sx={{
                  width: 64, height: 64, cursor: "pointer", display: "grid", placeItems: "center",
                  border: iconIdx === i ? `2px solid ${color}` : "2px solid transparent",
                  bgcolor: iconIdx === i ? `${color}14` : "background.paper",
                }}>
                  <I size={22} color={iconIdx === i ? color : undefined}/>
                </Card>
              ))}
            </Stack>
            <Box sx={{ mt: 3, fontWeight: 600, fontSize: 13, mb: 1 }}>Preview</Box>
            <Card sx={{ overflow: "hidden" }}>
              <Box sx={{ height: 60,
                background: `linear-gradient(135deg,#0A2540,${color})` }}/>
              <Box sx={{ p: 2 }}>
                <Box sx={{ fontWeight: 700 }}>LATAM Banking</Box>
                <Box sx={{ fontSize: 12, color: "text.secondary" }}>Tier 1 · LATAM</Box>
              </Box>
            </Card>
          </Box>
        )}

        {step === 2 && (
          <Box>
            <Box sx={{ fontSize: 13, color: "text.secondary", mb: 1.5 }}>
              Select the modules to enable. You can add or remove modules later.
            </Box>
            <Grid container spacing={1.5}>
              {modules.map(m => {
                const on = selected.includes(m.id);
                return (
                  <Grid key={m.id} size={{ xs: 12, sm: 6 }}>
                    <Card onClick={() => toggle(m.id)} sx={{
                      p: 1.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 1.5,
                      border: on ? `2px solid ${color}` : "2px solid transparent",
                      bgcolor: on ? `${color}10` : "background.paper",
                    }}>
                      <Box sx={{ width: 36, height: 36, borderRadius: 2,
                        bgcolor: on ? color : "action.hover", color: on ? "#fff" : "text.secondary",
                        display: "grid", placeItems: "center", fontWeight: 700 }}>
                        {m.name[0]}
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>{m.name}</Box>
                        <Box sx={{ fontSize: 11.5, color: "text.secondary" }}>{m.desc}</Box>
                      </Box>
                      <Box sx={{
                        width: 22, height: 22, borderRadius: "50%",
                        border: "2px solid", borderColor: on ? color : "divider",
                        bgcolor: on ? color : "transparent",
                        display: "grid", placeItems: "center",
                      }}>
                        {on && <Check size={12} color="#fff" />}
                      </Box>
                    </Card>
                  </Grid>
                );
              })}
            </Grid>
          </Box>
        )}

        {step === 3 && (
          <Box>
            <Card sx={{ p: 2.5, mb: 2,
              background: `linear-gradient(135deg,#0A2540,${color})`, color: "#fff" }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                <Box sx={{ width: 52, height: 52, borderRadius: 3, bgcolor: "rgba(255,255,255,0.15)",
                  display: "grid", placeItems: "center" }}><Icon size={24}/></Box>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 18 }}>LATAM Banking</Box>
                  <Box sx={{ fontSize: 12, opacity: 0.75 }}>Tier 1 — Critical · LATAM region</Box>
                </Box>
              </Box>
            </Card>
            <Box sx={{ fontWeight: 600, mb: 1 }}>Modules enabled ({selected.length})</Box>
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.75 }}>
              {modules.filter(m => selected.includes(m.id)).map(m =>
                <Chip key={m.id} size="small" label={m.name} sx={{ bgcolor: `${color}1A`, color, fontWeight: 600 }}/>
              )}
            </Box>
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: "divider" }}>
        <Button onClick={onClose}>Cancel</Button>
        <Box sx={{ flex: 1 }}/>
        {step > 0 && <Button onClick={() => setStep(step - 1)}>Back</Button>}
        {step < 3 ? (
          <Button variant="contained" onClick={() => setStep(step + 1)}>Continue</Button>
        ) : (
          <Button variant="contained" onClick={onClose} startIcon={<Check size={14}/>}>Create domain</Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
