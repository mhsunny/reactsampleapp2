import {
  Dialog, DialogContent, DialogActions, Button, Box, TextField, IconButton,
} from "@mui/material";
import { useState } from "react";
import { X, AlertTriangle } from "lucide-react";
import { BRAND } from "./theme";

export function DeleteGroupDialog({
  open,
  onClose,
  groupName,
  onDelete,
}: {
  open: boolean;
  onClose: () => void;
  groupName: string;
  onDelete: () => void;
}) {
  const [confirmText, setConfirmText] = useState("");

  const handleDelete = () => {
    if (confirmText === groupName) {
      onDelete();
      onClose();
      setConfirmText("");
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth
      PaperProps={{ sx: { borderRadius: "6px" } }}>
      <Box sx={{
        position: "relative",
        background: `linear-gradient(120deg, ${BRAND.primary} 0%, ${BRAND.primaryDeep} 100%)`,
        color: "#fff", p: 3,
      }}>
        <IconButton size="small" onClick={onClose}
          sx={{ position: "absolute", top: 12, right: 12, color: "#fff" }}>
          <X size={18}/>
        </IconButton>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box sx={{
            width: 48, height: 48, borderRadius: "50%",
            bgcolor: "rgba(255,255,255,0.2)",
            display: "grid", placeItems: "center",
          }}>
            <AlertTriangle size={24}/>
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Box sx={{ fontSize: 20, fontWeight: 700 }}>Delete Domain</Box>
            <Box sx={{ fontSize: 13, opacity: 0.9 }}>This action cannot be undone</Box>
          </Box>
        </Box>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        <Box sx={{ mb: 2 }}>
          <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>
            You are about to delete "{groupName}"
          </Box>
          <Box sx={{ fontSize: 13, color: "text.secondary", mb: 2 }}>
            This will permanently delete the domain and all its applications. This action cannot be undone.
          </Box>
        </Box>

        <Box sx={{
          p: 2, borderRadius: 2,
          bgcolor: "rgba(230,57,45,0.08)",
          border: "1px solid rgba(230,57,45,0.2)",
          mb: 2,
        }}>
          <Box sx={{ fontSize: 12, fontWeight: 600, color: "#E6392D", mb: 0.5 }}>
            Warning
          </Box>
          <Box sx={{ fontSize: 12, color: "text.secondary" }}>
            All applications, records, and configurations within this domain will be permanently deleted.
          </Box>
        </Box>

        <Box sx={{ mb: 1 }}>
          <Box sx={{ fontSize: 13, fontWeight: 600, mb: 1 }}>
            Type <Box component="span" sx={{ fontFamily: "monospace", bgcolor: "action.hover", px: 0.5, borderRadius: 0.5 }}>{groupName}</Box> to confirm:
          </Box>
          <TextField
            fullWidth
            placeholder="Enter domain name"
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
            error={confirmText !== "" && confirmText !== groupName}
            helperText={confirmText !== "" && confirmText !== groupName ? "Domain name doesn't match" : ""}
          />
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: "divider" }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          variant="contained"
          color="error"
          onClick={handleDelete}
          disabled={confirmText !== groupName}
        >
          Delete Domain
        </Button>
      </DialogActions>
    </Dialog>
  );
}
