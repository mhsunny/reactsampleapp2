import {
  Box, Card, CardContent, Grid, Chip, Button, IconButton, Avatar, AvatarGroup, Tabs, Tab, Tooltip, Switch,
} from "@mui/material";
import * as Icons from "lucide-react";
import { useState } from "react";
import { BRAND } from "./theme";
import { modules } from "./data";

export function GroupOverview({ onPickModule }: { onPickModule: (id: string) => void }) {
  const [tab, setTab] = useState(0);
  return (
    <Box>
      {/* Header */}
      <Card sx={{
        mb: 3,
        background: "linear-gradient(120deg,#0A2540 0%,#1E3A8A 70%,#E6392D 160%)",
        color: "#fff", borderColor: "transparent",
      }}>
        <CardContent sx={{ p: { xs: 3, md: 4 }, position: "relative" }}>
          <Grid container spacing={3} alignItems="center">
            <Grid size={{ xs: 12, md: 8 }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
                <Box sx={{
                  width: 56, height: 56, borderRadius: 3,
                  background: "linear-gradient(135deg,#fff,#FCA5A5)",
                  display: "grid", placeItems: "center", fontWeight: 700, fontSize: 20, color: BRAND.navy,
                }}>NA</Box>
                <Box>
                  <Box sx={{ fontSize: 22, fontWeight: 700 }}>North America Banking</Box>
                  <Box sx={{ fontSize: 12.5, opacity: 0.7 }}>Workspace · Created Mar 2024 · 9 applications</Box>
                </Box>
              </Box>
              <Box sx={{ display: "flex", gap: 1.5, flexWrap: "wrap" }}>
                <Chip size="small" label="● Healthy" sx={{ bgcolor: "rgba(16,163,74,0.2)", color: "#86EFAC", fontWeight: 700 }} />
                <Chip size="small" label="SOX · GDPR · DORA" sx={{ bgcolor: "rgba(255,255,255,0.1)", color: "#fff" }} />
                <Chip size="small" label="Tier 1 — Critical" sx={{ bgcolor: "rgba(230,57,45,0.25)", color: "#FCA5A5" }} />
              </Box>
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <Box sx={{ display: "flex", gap: 2, justifyContent: { md: "flex-end" } }}>
                <Stat label="Risks" value="318" />
                <Stat label="Controls" value="1,842" />
                <Stat label="Members" value="142" />
              </Box>
              <Box sx={{ display: "flex", justifyContent: { md: "flex-end" }, mt: 2, gap: 1 }}>
                <Button variant="contained" size="small" startIcon={<Icons.Plus size={14} />}>Add application</Button>
                <Button variant="outlined" size="small"
                  sx={{ color: "#fff", borderColor: "rgba(255,255,255,0.3)" }}
                  startIcon={<Icons.Settings2 size={14} />}>Configure</Button>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2.5, borderBottom: 1, borderColor: "divider" }}>
        {["Applications", "Members", "Templates", "Workflows", "Settings"].map((t) => (
          <Tab key={t} label={t} sx={{ textTransform: "none", fontWeight: 600 }} />
        ))}
      </Tabs>

      <Grid container spacing={2.5}>
        {modules.map((m) => {
          const Icon = (Icons as any)[m.icon] ?? Icons.Box;
          return (
            <Grid key={m.id} size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
              <Card sx={{
                height: "100%", cursor: "pointer", position: "relative",
                transition: "all .2s",
                "&:hover": { transform: "translateY(-3px)", borderColor: BRAND.primary,
                  boxShadow: "0 20px 50px -24px rgba(230,57,45,0.4)" },
              }} onClick={() => onPickModule(m.id)}>
                <CardContent>
                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
                    <Box sx={{
                      width: 44, height: 44, borderRadius: 2.5,
                      background: `linear-gradient(135deg, ${BRAND.primaryLight}20, ${BRAND.primary}28)`,
                      color: BRAND.primary, display: "grid", placeItems: "center",
                    }}>
                      <Icon size={20} />
                    </Box>
                    <Tooltip title="Module enabled">
                      <Switch size="small" defaultChecked onClick={(e) => e.stopPropagation()} />
                    </Tooltip>
                  </Box>
                  <Box sx={{ fontWeight: 700, fontSize: 14.5 }}>{m.name}</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary", mt: 0.5, minHeight: 32 }}>{m.desc}</Box>
                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mt: 2 }}>
                    <Chip size="small" label={m.count > 0 ? `${m.count} items` : "Admin"}
                      sx={{ bgcolor: "action.hover", fontWeight: 600 }} />
                    <AvatarGroup max={3} sx={{ "& .MuiAvatar-root": { width: 20, height: 20, fontSize: 9, borderColor: "background.paper" } }}>
                      <Avatar key="m" sx={{ bgcolor: "#E6392D" }}>M</Avatar>
                      <Avatar key="s" sx={{ bgcolor: "#3B82F6" }}>S</Avatar>
                      <Avatar key="j" sx={{ bgcolor: "#10B981" }}>J</Avatar>
                    </AvatarGroup>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
        <Grid size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
          <Card sx={{
            height: "100%", minHeight: 200, cursor: "pointer", border: "2px dashed", borderColor: "divider",
            background: "transparent", boxShadow: "none", display: "flex", alignItems: "center", justifyContent: "center",
            "&:hover": { borderColor: BRAND.primary, background: "rgba(230,57,45,0.04)" },
          }}>
            <Box sx={{ textAlign: "center" }}>
              <Box sx={{ mx: "auto", mb: 1, width: 42, height: 42, borderRadius: "50%",
                background: `linear-gradient(135deg,${BRAND.primaryLight},${BRAND.primary})`, color: "#fff",
                display: "grid", placeItems: "center" }}>
                <Icons.Plus size={20} />
              </Box>
              <Box sx={{ fontWeight: 700 }}>Add application</Box>
              <Box sx={{ fontSize: 12, color: "text.secondary" }}>From catalog or template</Box>
            </Box>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ textAlign: "right" }}>
      <Box sx={{ fontSize: 11, opacity: 0.7, textTransform: "uppercase", letterSpacing: ".1em" }}>{label}</Box>
      <Box sx={{ fontSize: 22, fontWeight: 700 }}>{value}</Box>
    </Box>
  );
}
