import { useRef, useState, useMemo } from "react";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";
import {
  Box, Card, CardContent, Grid, Chip, Button, IconButton, Avatar, InputBase, Badge, Tooltip,
  Menu, MenuItem, ListItemIcon, ListItemText, Divider, AvatarGroup, Stack,
} from "@mui/material";
import {
  LayoutGrid, Search, Bell, Plus, MoreHorizontal,
  ShieldAlert, Scale, ClipboardCheck, FlaskConical, Activity, Search as SearchIcon, Users,
  Sparkles, Pin, Star, Settings2, ArrowUpRight, ChevronDown, Folder, Edit3, Trash2, UserPlus,
  GripVertical, Sun, Moon, Grid3x3, LayoutList, AlignJustify, LayoutDashboard,
} from "lucide-react";
import { BRAND } from "./theme";
import { CreateAppModal } from "./CreateAppModal";
import { CreateGroupModal } from "./CreateGroupModal";

import { FEATURE_LIBRARY, FEATURE_BY_ID } from "./features";
import { EditAppModal } from "./EditAppModal";
import { RenameGroupModal } from "./RenameGroupModal";
import { ManageMembersModal } from "./ManageMembersModal";
import { DeleteGroupDialog } from "./DeleteGroupDialog";
import { ConfigureGroupModal } from "./ConfigureGroupModal";

export type App = { id: string; name: string; color: string; records: number; status: string; features: string[]; favorite?: boolean };
type Group = { id: string; name: string; description: string; tag: string; tagColor: string; members: number; pinned?: boolean; apps: App[] };

const initialGroups: Group[] = [
  {
    id: "non-financial-risk", name: "Non-Financial Risk Management",
    description: "Manage FRCs, controls, RAUs, MREs, KRIs, risk appetite, and compliance obligations",
    tag: "Core", tagColor: "#E6392D", members: 142, pinned: true,
    apps: [
      { id: "a1", name: "Risk Inventory Management", color: "#E6392D", records: 318, status: "Active",
        features: ["dashboard","raus","risks","controls","mcrs","frcs","controls-legacy","mres","business-units","policies","workflows","notifications","audit-log","ai-copilot"] },
      { id: "a2", name: "Risk Measures Management", color: "#F59E0B", records: 184, status: "Active",
        features: ["dashboard","measurement-workbench","measure-definitions","kri","risk-appetite","committee-decisions","risk-register","control-library","reports","audit-log"] },
      { id: "a3", name: "Risk Events Management", color: "#A855F7", records: 96, status: "Active",
        features: ["dashboard","records","incidents","sla","notifications","workflows","audit-log"] },
      { id: "a4", name: "Risk Assessments Management", color: "#10B981", records: 203, status: "Active",
        features: ["dashboard","assessments","workflows","second-line","branching","comments","audit-log"] },
      { id: "a5", name: "Compliance Risk Management", color: "#3B82F6", records: 147, status: "Active",
        features: ["dashboard","records","compliance-map","custom-fields","workflows","notifications","audit-log","reports"] },
    ],
  },
  {
    id: "internal-audit", name: "Internal Audit Management",
    description: "Deliver annual planning, fieldwork, issue management, and reporting",
    tag: "Assurance", tagColor: "#06B6D4", members: 58,
    apps: [
      { id: "b1", name: "Internal Audit", color: "#06B6D4", records: 214, status: "Active",
        features: ["dashboard","records","evidence","workflows","sla","reports","audit-log","notifications"] },
    ],
  },
  {
    id: "testing-monitoring", name: "Testing and Monitoring",
    description: "Second-line testing lifecycle and QA/QC monitoring oversight routines",
    tag: "Oversight", tagColor: "#8B5CF6", members: 74,
    apps: [
      { id: "c1", name: "Independent Test and Validation", color: "#8B5CF6", records: 312, status: "Active",
        features: ["dashboard","records","control-testing","evidence","second-line","workflows","audit-log","reports"] },
      { id: "c2", name: "Risk Monitoring and Oversight", color: "#F59E0B", records: 88, status: "Active",
        features: ["dashboard","kri","incidents","scheduled-jobs","notifications","webhooks","audit-log"] },
    ],
  },
  {
    id: "common-capabilities", name: "Common Business Capabilities",
    description: "Shared services for capacity planning, time reporting, and AI prompt lifecycle",
    tag: "Platform", tagColor: "#10B981", members: 46,
    apps: [
      { id: "d1", name: "Capacity Planning and Time Reporting", color: "#10B981", records: 134, status: "Active",
        features: ["dashboard","records","reports","scheduled-jobs","audit-log"] },
      { id: "d2", name: "Prompt Lifecycle Management", color: "#E6392D", records: 29, status: "Active",
        features: ["dashboard","records","workflows","audit-log","ai-copilot","notifications"] },
    ],
  },
  {
    id: "configuration", name: "Configuration Capabilities",
    description: "Configure API connectors, workflow designer, user access, and platform controls",
    tag: "Admin", tagColor: "#64748B", members: 32,
    apps: [
      { id: "e1", name: "Workflow Designer", color: "#64748B", records: 78, status: "Active",
        features: ["dashboard","records","workflows","webhooks","integrations","audit-log"] },
      { id: "e2", name: "User and Access Management", color: "#3B82F6", records: 215, status: "Active",
        features: ["dashboard","records","custom-fields","audit-log","notifications"] },
      { id: "e3", name: "Platform Configurations", color: "#A855F7", records: 43, status: "Active",
        features: ["dashboard","integrations","webhooks","scheduled-jobs","audit-log","notifications"] },
    ],
  },
];

type ViewMode = "masonry" | "grid" | "tile" | "compact";

export function Home({ onOpenApp, dark, onToggleDark }: { onOpenApp: (app: App, groupName: string) => void; dark?: boolean; onToggleDark?: () => void }) {
  const [groups, setGroups] = useState<Group[]>(initialGroups);
  const [viewMode, setViewMode] = useState<ViewMode>("masonry");
  const [searchQuery, setSearchQuery] = useState("");

  // Sort groups: pinned first, then filter by search
  const sortedGroups = useMemo(() => {
    const sorted = [...groups].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
    if (!searchQuery.trim()) return sorted;
    const q = searchQuery.toLowerCase();
    return sorted.filter(g =>
      g.name.toLowerCase().includes(q) ||
      g.description.toLowerCase().includes(q) ||
      g.apps.some(a => a.name.toLowerCase().includes(q))
    );
  }, [groups, searchQuery]);

  const moveApp = (groupId: string, fromIdx: number, toIdx: number) => {
    if (fromIdx === toIdx) return;
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      const next = [...g.apps];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return { ...g, apps: next };
    }));
  };
  const [appModal, setAppModal] = useState<{ open: boolean; group?: string }>({ open: false });
  const [groupModal, setGroupModal] = useState(false);
  const [profileAnchor, setProfileAnchor] = useState<null | HTMLElement>(null);
  const [groupMenuAnchor, setGroupMenuAnchor] = useState<{ el: HTMLElement; id: string } | null>(null);
  const [editAppModal, setEditAppModal] = useState<{ open: boolean; app: App | null; groupId: string | null }>({
    open: false,
    app: null,
    groupId: null,
  });
  const [renameGroupModal, setRenameGroupModal] = useState<{ open: boolean; groupId: string | null }>({
    open: false,
    groupId: null,
  });
  const [manageMembersModal, setManageMembersModal] = useState<{ open: boolean; groupId: string | null }>({
    open: false,
    groupId: null,
  });
  const [deleteGroupDialog, setDeleteGroupDialog] = useState<{ open: boolean; groupId: string | null }>({
    open: false,
    groupId: null,
  });
  const [configureGroupModal, setConfigureGroupModal] = useState<{ open: boolean; groupId: string | null }>({
    open: false,
    groupId: null,
  });

  const handleSaveApp = (updatedApp: App) => {
    setGroups(prev => prev.map(g => {
      if (g.id !== editAppModal.groupId) return g;
      return {
        ...g,
        apps: g.apps.map(a => a.id === updatedApp.id ? updatedApp : a),
      };
    }));
  };

  const handleRenameGroup = (groupId: string, newName: string, newDescription: string) => {
    setGroups(prev => prev.map(g =>
      g.id === groupId ? { ...g, name: newName, description: newDescription || g.description } : g
    ));
  };

  const handleTogglePinGroup = (groupId: string) => {
    setGroups(prev => prev.map(g =>
      g.id === groupId ? { ...g, pinned: !g.pinned } : g
    ));
  };

  const handleDeleteGroup = (groupId: string) => {
    setGroups(prev => prev.filter(g => g.id !== groupId));
  };

  const handleMoveAppBetweenGroups = (fromGroupId: string, toGroupId: string, appId: string) => {
    if (fromGroupId === toGroupId) return;
    setGroups(prev => {
      const app = prev.find(g => g.id === fromGroupId)?.apps.find(a => a.id === appId);
      if (!app) return prev;
      return prev.map(g => {
        if (g.id === fromGroupId) return { ...g, apps: g.apps.filter(a => a.id !== appId) };
        if (g.id === toGroupId) return { ...g, apps: [...g.apps, app] };
        return g;
      });
    });
  };

  const handleReorderAppInGroup = (groupId: string, fromIdx: number, toIdx: number) => {
    if (fromIdx === toIdx) return;
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      const next = [...g.apps];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return { ...g, apps: next };
    }));
  };

  const handleConfigureGroup = (groupId: string, settings: any) => {
    setGroups(prev => prev.map(g =>
      g.id === groupId ? { ...g, tag: settings.tag, tagColor: settings.tagColor } : g
    ));
  };

  const handleToggleFavoriteApp = (groupId: string, appId: string) => {
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        apps: g.apps.map(a => a.id === appId ? { ...a, favorite: !a.favorite } : a),
      };
    }));
  };

  const handleRemoveApp = (groupId: string, appId: string) => {
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        apps: g.apps.filter(a => a.id !== appId),
      };
    }));
  };

  return (
    <DndProvider backend={HTML5Backend}>
    <Box sx={{ minHeight: "100vh", bgcolor: "background.default" }}>
      {/* Wells Fargo style red top navbar */}
      <Box sx={{
        height: { xs: 56, md: 60 }, bgcolor: BRAND.primary, color: "#fff",
        display: "flex", alignItems: "center", px: { xs: 2, md: 4 }, gap: { xs: 1.5, md: 3 },
        position: "sticky", top: 0, zIndex: 10,
        boxShadow: "0 2px 0 rgba(0,0,0,0.04)",
      }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.25 }}>
          <Box sx={{ width: { xs: 24, md: 28 }, height: { xs: 24, md: 28 }, borderRadius: 0.75,
            display: "grid", gridTemplateColumns: "1fr 1fr", gap: "3px" }}>
            {[0,1,2,3].map(i => <Box key={i} sx={{ bgcolor: "#fff", borderRadius: 0.5 }}/>)}
          </Box>
          <Box sx={{ fontSize: { xs: 16, md: 18 }, fontWeight: 700, letterSpacing: "-0.01em" }}>GRC Risk</Box>
        </Box>
        <Divider orientation="vertical" flexItem sx={{ display: { xs: "none", sm: "block" }, borderColor: "rgba(255,255,255,0.25)", my: 1.5 }}/>
        <Box sx={{ display: { xs: "none", sm: "block" }, fontSize: { sm: 13, md: 15 }, fontWeight: 500 }}>Governance, Risk & Compliance</Box>

        <Box sx={{ flex: 1 }}/>

        <Box sx={{ display: { xs: "none", md: "flex" }, alignItems: "center", gap: 1, mr: 1,
          px: 1.25, py: 0.5, borderRadius: 2, bgcolor: "rgba(255,255,255,0.13)",
          border: "1px solid rgba(255,255,255,0.18)", minWidth: 280 }}>
          <Search size={15} color="#fff" opacity={0.85}/>
          <InputBase placeholder="Search apps, domains, records…"
            sx={{ flex: 1, fontSize: 13, color: "#fff", "& input::placeholder": { color: "rgba(255,255,255,0.7)", opacity: 1 } }}/>
        </Box>

        <Tooltip title="Notifications">
          <IconButton sx={{ color: "#fff" }}>
            <Badge color="warning" variant="dot"><Bell size={18}/></Badge>
          </IconButton>
        </Tooltip>

        <Tooltip title={dark ? "Light mode" : "Dark mode"}>
          <IconButton sx={{ color: "#fff" }} onClick={onToggleDark}>
            {dark ? <Sun size={18}/> : <Moon size={18}/>}
          </IconButton>
        </Tooltip>

        <Divider orientation="vertical" flexItem sx={{ display: { xs: "none", lg: "block" }, borderColor: "rgba(255,255,255,0.25)", my: 1.5, mx: 0.5 }}/>

        <Box onClick={(e) => setProfileAnchor(e.currentTarget)}
          sx={{ display: "flex", alignItems: "center", gap: 1, cursor: "pointer", py: 0.5, px: 1, borderRadius: 1.5,
            "&:hover": { bgcolor: "rgba(255,255,255,0.1)" } }}>
          <Avatar sx={{ width: 28, height: 28, bgcolor: "rgba(255,255,255,0.2)", fontSize: 11, fontWeight: 700 }}>EM</Avatar>
          <Box sx={{ display: { xs: "none", sm: "block" }, fontSize: 13.5, fontWeight: 600 }}>Elena M.</Box>
          <ChevronDown size={14} style={{ display: window.innerWidth < 600 ? 'none' : 'block' }}/>
        </Box>
        <Menu open={!!profileAnchor} anchorEl={profileAnchor} onClose={() => setProfileAnchor(null)}
          anchorOrigin={{ horizontal: "right", vertical: "bottom" }} transformOrigin={{ horizontal: "right", vertical: "top" }}>
          <MenuItem><ListItemIcon><Users size={16}/></ListItemIcon><ListItemText>Profile</ListItemText></MenuItem>
          <MenuItem><ListItemIcon><Settings2 size={16}/></ListItemIcon><ListItemText>Preferences</ListItemText></MenuItem>
          <Divider/>
          <MenuItem>Sign out</MenuItem>
        </Menu>
      </Box>

      {/* Page content */}
      <Box sx={{ width: "100%", px: { xs: 2, md: 3 }, py: { xs: 1.5, md: 2 }, display: "flex", flexDirection: "column" }}>
        {/* Toolbar: search + view toggle + new domain */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2, flexWrap: "wrap" }}>
          {/* Search */}
          <Box sx={{
            display: "flex", alignItems: "center", gap: 1, flex: 1, minWidth: 200,
            px: 1.5, py: 0.75, borderRadius: 2, border: "1px solid", borderColor: "divider",
            bgcolor: "background.paper",
          }}>
            <Search size={15} opacity={0.5}/>
            <InputBase
              placeholder="Search domains, apps…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              sx={{ flex: 1, fontSize: 13.5 }}
            />
          </Box>

          {/* View mode toggles */}
          <Box sx={{ display: "flex", alignItems: "center", border: "1px solid", borderColor: "divider", borderRadius: 2, overflow: "hidden", bgcolor: "background.paper" }}>
            {([
              { mode: "masonry" as ViewMode, icon: <LayoutDashboard size={16}/>, label: "Masonry" },
              { mode: "grid" as ViewMode, icon: <Grid3x3 size={16}/>, label: "Grid" },
              { mode: "tile" as ViewMode, icon: <LayoutList size={16}/>, label: "Tile" },
              { mode: "compact" as ViewMode, icon: <AlignJustify size={16}/>, label: "Compact" },
            ]).map(({ mode, icon, label }) => (
              <Tooltip key={mode} title={label}>
                <IconButton
                  size="small"
                  onClick={() => setViewMode(mode)}
                  sx={{
                    borderRadius: 0, px: 1.25, py: 0.75,
                    color: viewMode === mode ? BRAND.primary : "text.secondary",
                    bgcolor: viewMode === mode ? `${BRAND.primary}12` : "transparent",
                    "&:hover": { bgcolor: viewMode === mode ? `${BRAND.primary}18` : "action.hover" },
                  }}
                >
                  {icon}
                </IconButton>
              </Tooltip>
            ))}
          </Box>

          {/* New domain */}
          <Button variant="contained" startIcon={<Plus size={16}/>} onClick={() => setGroupModal(true)}
            sx={{ bgcolor: BRAND.primary, "&:hover": { bgcolor: BRAND.primaryDeep }, whiteSpace: "nowrap" }}>
            New domain
          </Button>
        </Box>

        {/* Masonry view */}
        {viewMode === "masonry" && (
          <Box sx={{
            columnCount: { xs: 1, sm: 2, lg: 3 },
            columnGap: "14px",
            mx: { xs: -2, md: -3 },
            px: { xs: 2, md: 3 },
          }}>
            {sortedGroups.map(g => (
              <MasonryGroupCard
                key={g.id}
                group={g}
                onOpenApp={(a) => onOpenApp(a, g.name)}
                onAddApp={() => setAppModal({ open: true, group: g.name })}
                onMenu={(el) => setGroupMenuAnchor({ el, id: g.id })}
                onMoveIn={(fromGroupId, appId) => handleMoveAppBetweenGroups(fromGroupId, g.id, appId)}
                onReorder={(fromIdx, toIdx) => handleReorderAppInGroup(g.id, fromIdx, toIdx)}
                onEditApp={(a) => setEditAppModal({ open: true, app: a, groupId: g.id })}
              />
            ))}
          </Box>
        )}

        {/* All other views: scrollable stack */}
        {viewMode !== "masonry" && <Stack spacing={{ xs: 1.5, md: 2 }}>
          {sortedGroups.map(g => (
            <Card key={g.id} sx={{ overflow: "hidden" }}>
              {/* Group header */}
              <Box sx={{ p: { xs: 1.5, md: 2 }, display: "flex", alignItems: "center", gap: { xs: 1.5, md: 2 }, borderBottom: 1, borderColor: "divider",
                background: `linear-gradient(90deg, ${g.tagColor}06, transparent 60%)`, flexWrap: "wrap" }}>
                <Box sx={{
                  width: { xs: 40, md: 48 }, height: { xs: 40, md: 48 }, borderRadius: 2.5,
                  background: `linear-gradient(135deg, ${g.tagColor}, ${BRAND.navy})`,
                  color: "#fff", display: "grid", placeItems: "center", fontWeight: 700, fontSize: { xs: 12, md: 14 },
                  boxShadow: `0 10px 24px -12px ${g.tagColor}88`,
                }}>
                  {g.name.split(" ").map(w => w[0]).slice(0, 2).join("")}
                </Box>
                <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1, flexWrap: "wrap" }}>
                    <Box sx={{ fontSize: { xs: 15, md: 17 }, fontWeight: 700, color: "text.primary" }}>{g.name}</Box>
                    <Chip size="small" label={g.tag} sx={{ bgcolor: `${g.tagColor}1A`, color: g.tagColor, fontWeight: 700, height: 20 }}/>
                    {g.pinned && <Chip size="small" icon={<Pin size={10}/>} label="Pinned" sx={{ height: 20, fontWeight: 600 }}/>}
                  </Box>
                  <Box sx={{ fontSize: { xs: 11.5, md: 12.5 }, color: "text.secondary", mt: 0.25 }}>{g.description}</Box>
                </Box>
                <Box sx={{ display: { xs: "none", md: "flex" }, alignItems: "center", gap: 1 }}>
                  <AvatarGroup max={4} sx={{ "& .MuiAvatar-root": { width: 26, height: 26, fontSize: 11, borderColor: "background.paper" } }}>
                    <Avatar key="m" sx={{ bgcolor: "#E6392D" }}>M</Avatar>
                    <Avatar key="s" sx={{ bgcolor: "#3B82F6" }}>S</Avatar>
                    <Avatar key="j" sx={{ bgcolor: "#10B981" }}>J</Avatar>
                    <Avatar key="p" sx={{ bgcolor: "#A855F7" }}>P</Avatar>
                    <Avatar key="l" sx={{ bgcolor: "#F59E0B" }}>L</Avatar>
                  </AvatarGroup>
                  <Chip size="small" icon={<Users size={11}/>} label={g.members} sx={{ fontWeight: 600 }}/>
                </Box>
                <Button size="small" variant="outlined" startIcon={<Plus size={14}/>}
                  onClick={() => setAppModal({ open: true, group: g.name })}
                  sx={{ display: { xs: "none", sm: "inline-flex" }, color: g.tagColor, borderColor: `${g.tagColor}55`, "&:hover": { borderColor: g.tagColor, bgcolor: `${g.tagColor}0A` } }}>
                  Add app
                </Button>
                <IconButton size="small" onClick={(e) => setGroupMenuAnchor({ el: e.currentTarget, id: g.id })}>
                  <MoreHorizontal size={16}/>
                </IconButton>
              </Box>

              {/* Apps — view-mode aware */}
              <Box sx={{ p: { xs: 1.5, md: 2 }, display: "flex", flexDirection: "column" }}>
                {/* Grid view */}
                {viewMode === "grid" && (
                  <Grid container spacing={2}>
                    {g.apps.map((a, idx) => (
                      <Grid key={a.id} size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
                        <AppCard app={a} index={idx} groupId={g.id}
                          onOpen={() => onOpenApp(a, g.name)}
                          onEdit={() => setEditAppModal({ open: true, app: a, groupId: g.id })}
                          onToggleFavorite={() => handleToggleFavoriteApp(g.id, a.id)}
                          onRemove={() => handleRemoveApp(g.id, a.id)}
                          moveApp={moveApp}
                        />
                      </Grid>
                    ))}
                    <Grid size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
                      <Card onClick={() => setAppModal({ open: true, group: g.name })}
                        sx={{ height: "100%", minHeight: 150, cursor: "pointer", border: "2px dashed", borderColor: "divider",
                          boxShadow: "none", background: "transparent", display: "flex", alignItems: "center", justifyContent: "center",
                          transition: "all .15s", "&:hover": { borderColor: g.tagColor, bgcolor: `${g.tagColor}06` } }}>
                        <Box sx={{ textAlign: "center" }}>
                          <Box sx={{ mx: "auto", mb: 1, width: 40, height: 40, borderRadius: "50%",
                            background: `linear-gradient(135deg, ${g.tagColor}, ${BRAND.primary})`, color: "#fff", display: "grid", placeItems: "center" }}>
                            <Plus size={18}/>
                          </Box>
                          <Box sx={{ fontWeight: 700, fontSize: 13.5, color: "text.primary" }}>Add application</Box>
                          <Box sx={{ fontSize: 11.5, color: "text.secondary" }}>Configure a new app</Box>
                        </Box>
                      </Card>
                    </Grid>
                  </Grid>
                )}

                {/* Tile view — 2-col wider cards */}
                {viewMode === "tile" && (
                  <Grid container spacing={1.5}>
                    {g.apps.map((a) => (
                      <Grid key={a.id} size={{ xs: 12, sm: 6 }}>
                        <Card sx={{ display: "flex", alignItems: "center", gap: 2, p: 2, cursor: "pointer",
                          "&:hover": { boxShadow: 4 }, transition: "box-shadow .2s" }}
                          onClick={() => onOpenApp(a, g.name)}>
                          <Box sx={{ width: 44, height: 44, borderRadius: 2, background: `linear-gradient(135deg,${a.color},${a.color}80)`,
                            color: "#fff", display: "grid", placeItems: "center", fontWeight: 700, fontSize: 16, flexShrink: 0 }}>
                            {a.name[0]}
                          </Box>
                          <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
                            <Box sx={{ fontWeight: 700, fontSize: 14 }}>{a.name}</Box>
                            <Box sx={{ fontSize: 11.5, color: "text.secondary" }}>{a.records.toLocaleString()} records · {a.features.length} features</Box>
                          </Box>
                          <Chip size="small" label={a.status} sx={{ bgcolor: `${a.color}1A`, color: a.color, fontWeight: 700, height: 20 }}/>
                          <IconButton size="small" onClick={(e) => { e.stopPropagation(); setEditAppModal({ open: true, app: a, groupId: g.id }); }}>
                            <MoreHorizontal size={15}/>
                          </IconButton>
                        </Card>
                      </Grid>
                    ))}
                  </Grid>
                )}

                {/* Compact view — single-line rows */}
                {viewMode === "compact" && (
                  <Stack divider={<Box sx={{ borderBottom: "1px solid", borderColor: "divider" }}/>} spacing={0}>
                    {g.apps.map((a) => (
                      <Box key={a.id} sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1, px: 0.5, cursor: "pointer",
                        "&:hover": { bgcolor: "action.hover" }, borderRadius: 1 }}
                        onClick={() => onOpenApp(a, g.name)}>
                        <Box sx={{ width: 28, height: 28, borderRadius: 1.5, bgcolor: `${a.color}1A`, color: a.color,
                          display: "grid", placeItems: "center", fontWeight: 700, fontSize: 12, flexShrink: 0 }}>
                          {a.name[0]}
                        </Box>
                        <Box sx={{ fontWeight: 600, fontSize: 13, flex: 1 }}>{a.name}</Box>
                        <Box sx={{ fontSize: 11.5, color: "text.secondary", display: { xs: "none", sm: "block" } }}>{a.records.toLocaleString()} records</Box>
                        <Chip size="small" label={a.status} sx={{ bgcolor: `${a.color}1A`, color: a.color, fontWeight: 700, height: 18, fontSize: 10 }}/>
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setEditAppModal({ open: true, app: a, groupId: g.id }); }}>
                          <MoreHorizontal size={14}/>
                        </IconButton>
                      </Box>
                    ))}
                  </Stack>
                )}

              </Box>
            </Card>
          ))}

          {/* Create new group card */}
          <Card onClick={() => setGroupModal(true)}
            sx={{
              p: { xs: 2, md: 2.5 }, cursor: "pointer", border: "2px dashed", borderColor: "divider",
              background: "transparent", boxShadow: "none",
              display: "flex", flexDirection: { xs: "column", sm: "row" }, alignItems: "center", gap: 2, justifyContent: "center",
              "&:hover": { borderColor: BRAND.primary, bgcolor: "rgba(230,57,45,0.03)" },
            }}>
            <Box sx={{
              width: { xs: 44, md: 48 }, height: { xs: 44, md: 48 }, borderRadius: "50%",
              background: `linear-gradient(135deg, ${BRAND.primaryLight}, ${BRAND.primary})`,
              color: "#fff", display: "grid", placeItems: "center",
              boxShadow: "0 12px 30px -12px rgba(230,57,45,0.7)",
            }}>
              <Plus size={22}/>
            </Box>
            <Box sx={{ textAlign: { xs: "center", sm: "left" } }}>
              <Box sx={{ fontWeight: 700, color: "text.primary", fontSize: { xs: 15, md: 16 } }}>Create a new domain</Box>
              <Box sx={{ fontSize: { xs: 12, md: 12.5 }, color: "text.secondary" }}>Spin up a risk domain and assign applications</Box>
            </Box>
          </Card>
        </Stack>}
      </Box>

      <Menu open={!!groupMenuAnchor} anchorEl={groupMenuAnchor?.el} onClose={() => setGroupMenuAnchor(null)}>
        <MenuItem onClick={() => {
          setRenameGroupModal({ open: true, groupId: groupMenuAnchor?.id || null });
          setGroupMenuAnchor(null);
        }}>
          <ListItemIcon><Edit3 size={15}/></ListItemIcon>
          <ListItemText>Rename domain</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => {
          setManageMembersModal({ open: true, groupId: groupMenuAnchor?.id || null });
          setGroupMenuAnchor(null);
        }}>
          <ListItemIcon><UserPlus size={15}/></ListItemIcon>
          <ListItemText>Manage members</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => {
          setConfigureGroupModal({ open: true, groupId: groupMenuAnchor?.id || null });
          setGroupMenuAnchor(null);
        }}>
          <ListItemIcon><Settings2 size={15}/></ListItemIcon>
          <ListItemText>Configure</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => {
          if (groupMenuAnchor?.id) handleTogglePinGroup(groupMenuAnchor.id);
          setGroupMenuAnchor(null);
        }}>
          <ListItemIcon><Pin size={15}/></ListItemIcon>
          <ListItemText>
            {groups.find(g => g.id === groupMenuAnchor?.id)?.pinned ? "Unpin from top" : "Pin to top"}
          </ListItemText>
        </MenuItem>
        <Divider/>
        <MenuItem
          sx={{ color: "error.main" }}
          onClick={() => {
            setDeleteGroupDialog({ open: true, groupId: groupMenuAnchor?.id || null });
            setGroupMenuAnchor(null);
          }}
        >
          <ListItemIcon><Trash2 size={15} color="#E6392D"/></ListItemIcon>
          <ListItemText>Delete domain</ListItemText>
        </MenuItem>
      </Menu>

      <CreateAppModal open={appModal.open} onClose={() => setAppModal({ open: false })} groupName={appModal.group}/>
      <CreateGroupModal open={groupModal} onClose={() => setGroupModal(false)}/>
      <EditAppModal
        open={editAppModal.open}
        app={editAppModal.app}
        onClose={() => setEditAppModal({ open: false, app: null, groupId: null })}
        onSave={handleSaveApp}
      />
      <RenameGroupModal
        open={renameGroupModal.open}
        groupName={groups.find(g => g.id === renameGroupModal.groupId)?.name || ""}
        onClose={() => setRenameGroupModal({ open: false, groupId: null })}
        onRename={(newName, newDescription) => {
          if (renameGroupModal.groupId) {
            handleRenameGroup(renameGroupModal.groupId, newName, newDescription);
          }
        }}
      />
      <ManageMembersModal
        open={manageMembersModal.open}
        groupName={groups.find(g => g.id === manageMembersModal.groupId)?.name || ""}
        onClose={() => setManageMembersModal({ open: false, groupId: null })}
      />
      <DeleteGroupDialog
        open={deleteGroupDialog.open}
        groupName={groups.find(g => g.id === deleteGroupDialog.groupId)?.name || ""}
        onClose={() => setDeleteGroupDialog({ open: false, groupId: null })}
        onDelete={() => {
          if (deleteGroupDialog.groupId) {
            handleDeleteGroup(deleteGroupDialog.groupId);
          }
        }}
      />
      <ConfigureGroupModal
        open={configureGroupModal.open}
        groupName={groups.find(g => g.id === configureGroupModal.groupId)?.name || ""}
        groupId={configureGroupModal.groupId || ""}
        onClose={() => setConfigureGroupModal({ open: false, groupId: null })}
        onSave={handleConfigureGroup}
      />
    </Box>
    </DndProvider>
  );
}

function MasonryAppItem({ app, groupId, index, onOpen, onEdit }: {
  app: App; groupId: string; index: number; onOpen: () => void; onEdit: () => void;
}) {
  const [dragReady, setDragReady] = useState(false);
  const [dragging, setDragging] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const didDragRef = useRef(false);

  const clearTimer = () => { if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; } };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    didDragRef.current = false;
    timerRef.current = setTimeout(() => setDragReady(true), 500);
  };

  const handleMouseUp = () => {
    clearTimer();
    if (!didDragRef.current) onOpen();
    setDragReady(false);
  };

  const handleMouseLeave = () => { if (!dragReady) clearTimer(); };

  const handleDragStart = (e: React.DragEvent) => {
    didDragRef.current = true;
    setDragging(true);
    e.dataTransfer.setData("appId", app.id);
    e.dataTransfer.setData("fromGroupId", groupId);
    e.dataTransfer.setData("fromIndex", String(index));
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragEnd = () => { setDragReady(false); setDragging(false); didDragRef.current = false; };

  return (
    <Box
      draggable={dragReady}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      sx={{
        p: 1.5, borderRadius: 2,
        border: "1px solid", borderColor: dragReady ? app.color : "divider",
        bgcolor: dragging ? "transparent" : "background.default",
        display: "flex", flexDirection: "column", gap: 0.75,
        cursor: dragReady ? "grab" : "pointer",
        userSelect: "none",
        opacity: dragging ? 0.35 : 1,
        transform: dragReady && !dragging ? "scale(1.015)" : "scale(1)",
        boxShadow: dragReady && !dragging ? `0 6px 20px -8px ${app.color}66` : "none",
        transition: "all .15s",
        "&:hover": !dragReady ? { borderColor: app.color, bgcolor: "background.paper", boxShadow: `0 3px 14px -6px ${app.color}55` } : {},
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.25 }}>
        <Box sx={{
          width: 34, height: 34, borderRadius: 1.5, flexShrink: 0,
          background: `linear-gradient(135deg, ${app.color}28, ${app.color}0C)`,
          color: app.color, display: "grid", placeItems: "center",
          fontWeight: 700, fontSize: 14, border: `1px solid ${app.color}33`,
        }}>
          {app.name[0]}
        </Box>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Box sx={{ fontWeight: 700, fontSize: 13, color: "text.primary" }}>{app.name}</Box>
          <Box sx={{ fontSize: 11, color: "text.secondary" }}>
            {app.records.toLocaleString()} records · {app.features.length} features
          </Box>
        </Box>
        <Chip size="small" label={app.status}
          sx={{ bgcolor: `${app.color}1A`, color: app.color, fontWeight: 700, height: 18, fontSize: 10, flexShrink: 0 }}/>
        <IconButton size="small" sx={{ flexShrink: 0, p: 0.25 }}
          onMouseDown={(e) => e.stopPropagation()}
          onMouseUp={(e) => e.stopPropagation()}
          onClick={(e) => { e.stopPropagation(); onEdit(); }}>
          <MoreHorizontal size={14}/>
        </IconButton>
      </Box>
      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
        {app.features.slice(0, 5).map(f => (
          <Chip key={f} size="small" label={f.replace(/-/g, " ")}
            sx={{ height: 16, fontSize: 9.5, bgcolor: "action.hover", color: "text.secondary",
              textTransform: "capitalize", "& .MuiChip-label": { px: 0.75 } }}/>
        ))}
        {app.features.length > 5 && (
          <Chip size="small" label={`+${app.features.length - 5}`}
            sx={{ height: 16, fontSize: 9.5, bgcolor: `${app.color}14`, color: app.color, "& .MuiChip-label": { px: 0.75 } }}/>
        )}
      </Box>
      {dragReady && !dragging && (
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 0.5,
          fontSize: 10.5, color: app.color, fontWeight: 600, mt: 0.25 }}>
          <GripVertical size={12}/> drag to move
        </Box>
      )}
    </Box>
  );
}

function MasonryGroupCard({ group, onOpenApp, onAddApp, onMenu, onMoveIn, onReorder, onEditApp }: {
  group: { id: string; name: string; tagColor: string; apps: App[] };
  onOpenApp: (a: App) => void;
  onAddApp: () => void;
  onMenu: (el: HTMLElement) => void;
  onMoveIn: (fromGroupId: string, appId: string) => void;
  onReorder: (fromIdx: number, toIdx: number) => void;
  onEditApp: (a: App) => void;
}) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [dropIndex, setDropIndex] = useState<number | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    if (!e.currentTarget.contains(e.relatedTarget as Node)) {
      setIsDragOver(false);
      setDropIndex(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    setDropIndex(null);
    const appId = e.dataTransfer.getData("appId");
    const fromGroupId = e.dataTransfer.getData("fromGroupId");
    const fromIndex = parseInt(e.dataTransfer.getData("fromIndex") || "0");
    if (!appId) return;
    if (fromGroupId !== group.id) {
      onMoveIn(fromGroupId, appId);
    } else {
      if (dropIndex !== null && dropIndex !== fromIndex) onReorder(fromIndex, dropIndex);
    }
  };

  const handleItemDragOver = (e: React.DragEvent, idx: number) => {
    e.stopPropagation();
    e.preventDefault();
    setIsDragOver(true);
    setDropIndex(idx);
  };

  return (
    <Card sx={{ overflow: "hidden", breakInside: "avoid", mb: "14px", display: "inline-block", width: "100%",
      outline: isDragOver ? `2px solid ${group.tagColor}` : "2px solid transparent",
      outlineOffset: "2px", transition: "outline .15s" }}>
      <Box sx={{
        px: 1.5, py: 1.25, display: "flex", alignItems: "center", gap: 1.25,
        background: `linear-gradient(110deg, ${group.tagColor}12 0%, transparent 70%)`,
        borderBottom: "1px solid", borderColor: "divider",
      }}>
        <Box sx={{
          width: 36, height: 36, borderRadius: 1.5, flexShrink: 0,
          background: `linear-gradient(135deg, ${group.tagColor}, ${BRAND.navy})`,
          color: "#fff", display: "grid", placeItems: "center", fontWeight: 700, fontSize: 12,
        }}>
          {group.name.split(" ").map((w: string) => w[0]).slice(0, 2).join("")}
        </Box>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Box sx={{ fontWeight: 700, fontSize: 13.5, color: "text.primary", lineHeight: 1.3 }}>{group.name}</Box>
          <Box sx={{ fontSize: 11, color: "text.secondary", mt: 0.2 }}>
            {group.apps.length} {group.apps.length === 1 ? "app" : "apps"}
          </Box>
        </Box>
        <Tooltip title="Add application">
          <IconButton size="small" sx={{ flexShrink: 0, color: "text.secondary", "&:hover": { color: group.tagColor } }} onClick={onAddApp}>
            <Plus size={15}/>
          </IconButton>
        </Tooltip>
        <IconButton size="small" sx={{ flexShrink: 0 }} onClick={(e) => onMenu(e.currentTarget)}>
          <MoreHorizontal size={14}/>
        </IconButton>
      </Box>
      <Box sx={{ p: 1.5, display: "flex", flexDirection: "column", gap: 1 }}
        onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}>
        {group.apps.map((a, idx) => (
          <Box key={a.id} onDragOver={(e) => handleItemDragOver(e, idx)}
            sx={{ outline: dropIndex === idx && isDragOver ? `2px dashed ${group.tagColor}88` : "2px solid transparent",
              borderRadius: 2, transition: "outline .1s" }}>
            <MasonryAppItem app={a} groupId={group.id} index={idx} onOpen={() => onOpenApp(a)} onEdit={() => onEditApp(a)}/>
          </Box>
        ))}
      </Box>
    </Card>
  );
}

function NavLink({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Box sx={{
      display: { xs: "none", lg: "flex" }, alignItems: "center", gap: 0.75,
      px: 1.25, py: 0.75, borderRadius: 1.5, cursor: "pointer", fontSize: 13.5, fontWeight: 500,
      "&:hover": { bgcolor: "rgba(255,255,255,0.1)" },
    }}>
      {icon}
      {children}
    </Box>
  );
}

function AppCard({
  app, index, groupId, onOpen, onEdit, onToggleFavorite, onRemove, moveApp,
}: {
  app: App; index: number; groupId: string; onOpen: () => void; onEdit: () => void;
  onToggleFavorite: () => void; onRemove: () => void;
  moveApp: (groupId: string, from: number, to: number) => void;
}) {
  const [anchor, setAnchor] = useState<null | HTMLElement>(null);
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag, dragPreview] = useDrag(() => ({
    type: `APP:${groupId}`,
    item: { index, groupId, id: app.id },
    collect: (m) => ({ isDragging: m.isDragging() }),
  }), [index, groupId, app.id]);

  const [{ isOver }, drop] = useDrop(() => ({
    accept: `APP:${groupId}`,
    hover: (item: { index: number }) => {
      if (item.index === index) return;
      moveApp(groupId, item.index, index);
      item.index = index;
    },
    collect: (m) => ({ isOver: m.isOver() }),
  }), [groupId, index, moveApp]);

  drop(dragPreview(ref));

  const featureObjs = (app.features ?? []).map(id => FEATURE_BY_ID[id]).filter(Boolean);
  const visible = featureObjs.slice(0, 3);
  const overflow = featureObjs.length - visible.length;
  return (
    <Card ref={ref} onClick={onOpen} sx={{
      cursor: "pointer", height: "100%", position: "relative",
      transition: "transform .18s ease, box-shadow .18s ease, border-color .18s ease",
      opacity: isDragging ? 0.4 : 1,
      outline: isOver && !isDragging ? `2px dashed ${app.color}` : "none",
      outlineOffset: -2,
      "&:hover": { transform: "translateY(-3px)", borderColor: app.color,
        boxShadow: `0 20px 44px -22px ${app.color}66` },
      "&:hover .drag-handle": { opacity: 1 },
    }}>
      <Box
        ref={drag as any}
        className="drag-handle"
        onClick={(e) => e.stopPropagation()}
        sx={{
          position: "absolute", top: 8, left: 8, zIndex: 2,
          width: 22, height: 22, borderRadius: 1.25,
          display: "grid", placeItems: "center",
          cursor: "grab", opacity: 0, transition: "opacity .15s",
          color: "text.secondary",
          bgcolor: "background.paper", border: 1, borderColor: "divider",
          "&:active": { cursor: "grabbing" },
        }}
      >
        <GripVertical size={12}/>
      </Box>
      <Box sx={{ height: 4, background: `linear-gradient(90deg, ${app.color}, ${app.color}66)` }}/>
      <CardContent sx={{ p: { xs: 1.5, md: 2 } }}>
        <Box sx={{ display: "flex", alignItems: "flex-start", gap: 1.5 }}>
          <Box sx={{ width: { xs: 36, md: 40 }, height: { xs: 36, md: 40 }, borderRadius: 2,
            background: `linear-gradient(135deg, ${app.color}22, ${app.color}11)`,
            color: app.color, display: "grid", placeItems: "center",
            fontWeight: 700, fontSize: { xs: 14, md: 16 }, position: "relative" }}>
            {app.name.slice(0, 1)}
            {app.favorite && (
              <Box sx={{
                position: "absolute", top: -4, right: -4,
                width: 16, height: 16, borderRadius: "50%",
                bgcolor: "#F59E0B", display: "grid", placeItems: "center",
                border: "2px solid white",
              }}>
                <Star size={10} fill="#fff" color="#fff"/>
              </Box>
            )}
          </Box>
          <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
            <Box sx={{ fontWeight: 700, fontSize: { xs: 13, md: 14 }, lineHeight: 1.25 }}>{app.name}</Box>
            <Box sx={{ fontSize: { xs: 10.5, md: 11.5 }, color: "text.secondary", mt: 0.25 }}>
              {(app.features?.length ?? 0)} features · {app.records.toLocaleString()} records
            </Box>
          </Box>
          <IconButton size="small" onClick={(e) => { e.stopPropagation(); setAnchor(e.currentTarget); }}>
            <MoreHorizontal size={14}/>
          </IconButton>
        </Box>

        <Stack direction="row" spacing={0.5} sx={{ mt: 1.5, flexWrap: "wrap", gap: 0.5 }}>
          {visible.map(f => (
            <Tooltip key={f.id} title={f.description}>
              <Chip size="small" icon={<f.icon size={10}/>} label={f.name}
                sx={{
                  height: 20, fontSize: { xs: 9.5, md: 10.5 }, fontWeight: 600,
                  bgcolor: `${app.color}10`, color: app.color,
                  "& .MuiChip-icon": { color: app.color, ml: 0.5 },
                }}/>
            </Tooltip>
          ))}
          {overflow > 0 && (
            <Chip size="small" label={`+${overflow}`}
              sx={{ height: 20, fontSize: { xs: 9.5, md: 10.5 }, fontWeight: 700 }}/>
          )}
        </Stack>

        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mt: 1.5, flexWrap: "wrap", gap: 1 }}>
          <Chip size="small" label={app.status}
            sx={{ height: 20, fontSize: { xs: 10, md: 11 }, fontWeight: 700,
              bgcolor: app.status === "Live" ? "rgba(16,163,74,0.12)" :
                       app.status === "In Progress" ? "rgba(59,130,246,0.12)" :
                       app.status === "Scheduled" ? "rgba(245,158,11,0.12)" : "rgba(16,163,74,0.12)",
              color: app.status === "Live" ? "#16A34A" :
                     app.status === "In Progress" ? "#3B82F6" :
                     app.status === "Scheduled" ? "#F59E0B" : "#16A34A" }}/>
          <Box sx={{ fontSize: { xs: 10, md: 11 }, color: "text.secondary", fontWeight: 600 }}>Updated 2h ago</Box>
        </Box>
      </CardContent>
      <Menu open={!!anchor} anchorEl={anchor} onClose={() => setAnchor(null)}
        onClick={(e) => e.stopPropagation()}>
        <MenuItem onClick={(e) => { e.stopPropagation(); setAnchor(null); onOpen(); }}>
          <ListItemIcon><ArrowUpRight size={14}/></ListItemIcon>
          <ListItemText>Open</ListItemText>
        </MenuItem>
        <MenuItem onClick={(e) => { e.stopPropagation(); setAnchor(null); onEdit(); }}>
          <ListItemIcon><Settings2 size={14}/></ListItemIcon>
          <ListItemText>Configure</ListItemText>
        </MenuItem>
        <MenuItem onClick={(e) => { e.stopPropagation(); setAnchor(null); onToggleFavorite(); }}>
          <ListItemIcon>
            <Star size={14} fill={app.favorite ? "#F59E0B" : "none"} color={app.favorite ? "#F59E0B" : "currentColor"}/>
          </ListItemIcon>
          <ListItemText>{app.favorite ? "Unfavorite" : "Favorite"}</ListItemText>
        </MenuItem>
        <Divider/>
        <MenuItem
          sx={{ color: "error.main" }}
          onClick={(e) => {
            e.stopPropagation();
            if (window.confirm(`Are you sure you want to remove "${app.name}"?`)) {
              onRemove();
            }
            setAnchor(null);
          }}
        >
          <ListItemIcon><Trash2 size={14} color="#E6392D"/></ListItemIcon>
          <ListItemText>Remove</ListItemText>
        </MenuItem>
      </Menu>
    </Card>
  );
}
