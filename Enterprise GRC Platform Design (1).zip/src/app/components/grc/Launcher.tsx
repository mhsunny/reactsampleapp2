import {
  Box, Card, CardContent, Grid, Chip, Button, IconButton, Avatar, AvatarGroup, LinearProgress, Tooltip,
} from "@mui/material";
import {
  ShieldCheck, AlertTriangle, ListChecks, Activity, ArrowUpRight, ArrowDownRight, Plus, MoreHorizontal,
  Sparkles, Layers, Pin, Users,
} from "lucide-react";
import { BRAND } from "./theme";
import { groups, activity } from "./data";
import { AreaChart, Area, ResponsiveContainer } from "recharts";

const stats = [
  { label: "Total Risks", value: "1,108", delta: "+4.2%", up: true, icon: ShieldCheck, color: BRAND.primary,
    spark: [4,6,5,8,7,9,11,10,12,14,13,16] },
  { label: "Open Issues", value: "184", delta: "-12.8%", up: false, icon: AlertTriangle, color: "#F59E0B",
    spark: [18,17,15,16,13,12,10,11,9,8,7,6] },
  { label: "Compliance Score", value: "92.4", delta: "+1.6 pts", up: true, icon: ListChecks, color: "#10B981",
    spark: [86,87,88,87,89,90,91,90,92,91,92,92] },
  { label: "Live Monitors", value: "412", delta: "Healthy", up: true, icon: Activity, color: "#3B82F6",
    spark: [5,6,8,7,9,11,10,12,11,13,14,12] },
];

export function Launcher({ onOpenGroup, onCreateGroup }: { onOpenGroup: () => void; onCreateGroup: () => void; }) {
  return (
    <Box>
      {/* Hero */}
      <Card sx={{
        position: "relative", overflow: "hidden", mb: 2,
        background: "linear-gradient(120deg,#061629 0%,#0A2540 45%,#3C1413 100%)",
        color: "#fff", borderColor: "transparent",
      }}>
        <Box sx={{ position: "absolute", inset: 0, opacity: 0.5,
          background: "radial-gradient(circle at 12% 20%, rgba(240,93,64,0.35), transparent 40%), radial-gradient(circle at 90% 80%, rgba(59,130,246,0.25), transparent 45%)" }} />
        <Box sx={{ position: "absolute", inset: 0,
          backgroundImage: "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
          backgroundSize: "44px 44px", opacity: 0.6 }} />
        <CardContent sx={{ position: "relative", p: { xs: 2, md: 3 } }}>
          <Grid container spacing={3} alignItems="center">
            <Grid size={{ xs: 12, md: 7 }}>
              <Chip
                icon={<Sparkles size={13} color={BRAND.primaryLight} />}
                label="Welcome back, Elena"
                size="small"
                sx={{ color: "#fff", bgcolor: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", mb: 2 }}
              />
              <Box sx={{ fontSize: { xs: 24, md: 34 }, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1.1, mb: 1 }}>
                Unified Governance, Risk &<br />
                <Box component="span" sx={{
                  background: `linear-gradient(90deg, ${BRAND.primaryLight}, #FBBF24)`,
                  WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
                }}>Compliance Intelligence</Box>
              </Box>
              <Box sx={{ color: "rgba(255,255,255,0.7)", fontSize: 13.5, maxWidth: 520, mb: 2 }}>
                One platform for every risk discipline. Configure applications, orchestrate
                programs and surface signal across the enterprise — in real time.
              </Box>
              <Box sx={{ display: "flex", gap: 1.5, flexWrap: "wrap" }}>
                <Button variant="contained" size="large" startIcon={<Plus size={16} />} onClick={onCreateGroup}>
                  Create new application
                </Button>
                <Button variant="outlined" size="large"
                  sx={{ color: "#fff", borderColor: "rgba(255,255,255,0.25)", "&:hover": { borderColor: "#fff", bgcolor: "rgba(255,255,255,0.06)" } }}>
                  Explore templates
                </Button>
              </Box>
            </Grid>
            <Grid size={{ xs: 12, md: 5 }}>
              <Card sx={{
                background: "rgba(255,255,255,0.06)", backdropFilter: "blur(12px)",
                border: "1px solid rgba(255,255,255,0.12)", color: "#fff", borderRadius: 4,
              }}>
                <CardContent>
                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                    <Box sx={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>Enterprise Risk Pulse</Box>
                    <Chip size="small" label="Live" sx={{ bgcolor: "rgba(16,163,74,0.18)", color: "#86EFAC", fontWeight: 700 }} />
                  </Box>
                  <Box sx={{ display: "flex", alignItems: "flex-end", gap: 1.5, mb: 1 }}>
                    <Box sx={{ fontSize: 44, fontWeight: 700, lineHeight: 1 }}>92<Box component="span" sx={{ fontSize: 22, opacity: 0.6 }}>.4</Box></Box>
                    <Chip size="small" icon={<ArrowUpRight size={12} />} label="+1.6"
                      sx={{ bgcolor: "rgba(16,163,74,0.18)", color: "#86EFAC" }} />
                  </Box>
                  <LinearProgress variant="determinate" value={92.4}
                    sx={{ height: 8, borderRadius: 4, bgcolor: "rgba(255,255,255,0.1)",
                      "& .MuiLinearProgress-bar": { background: `linear-gradient(90deg, ${BRAND.primaryLight}, #FBBF24, #10B981)` } }} />
                  <Box sx={{ display: "flex", justifyContent: "space-between", mt: 1.5, fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
                    <Box sx={{ display: "flex", flexDirection: "column" }}>SLA Adherence<Box sx={{ color: "#fff", fontWeight: 600, fontSize: 16 }}>98.1%</Box></Box>
                    <Box sx={{ display: "flex", flexDirection: "column" }}>Open Incidents<Box sx={{ color: "#fff", fontWeight: 600, fontSize: 16 }}>26</Box></Box>
                    <Box sx={{ display: "flex", flexDirection: "column" }}>Avg. Mitigation<Box sx={{ color: "#fff", fontWeight: 600, fontSize: 16 }}>11.4d</Box></Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Stats */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        {stats.map((s) => (
          <Grid key={s.label} size={{ xs: 12, sm: 6, lg: 3 }}>
            <Card sx={{ height: "100%" }}>
              <CardContent>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <Box sx={{ display: "flex", flexDirection: "column" }}>
                    <Box sx={{ fontSize: 12.5, color: "text.secondary", fontWeight: 600 }}>{s.label}</Box>
                    <Box sx={{ fontSize: 30, fontWeight: 700, mt: 0.5, letterSpacing: "-0.02em" }}>{s.value}</Box>
                    <Chip size="small"
                      icon={s.up ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                      label={s.delta}
                      sx={{
                        mt: 1.25,
                        bgcolor: s.up ? "rgba(16,163,74,0.12)" : "rgba(230,57,45,0.12)",
                        color: s.up ? "#16A34A" : "#E6392D",
                      }} />
                  </Box>
                  <Box sx={{
                    width: 42, height: 42, borderRadius: 2.5, display: "grid", placeItems: "center",
                    background: `${s.color}1A`, color: s.color,
                  }}>
                    <s.icon size={20} />
                  </Box>
                </Box>
                <Box sx={{ height: 48, mt: 1.5, mx: -1 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={s.spark.map((v, i) => ({ i, v }))}>
                      <defs>
                        <linearGradient id={`spark-${s.label}`} x1="0" x2="0" y1="0" y2="1">
                          <stop offset="0%" stopColor={s.color} stopOpacity={0.5} />
                          <stop offset="100%" stopColor={s.color} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area type="monotone" dataKey="v" stroke={s.color} strokeWidth={2} fill={`url(#spark-${s.label})`} />
                    </AreaChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2}>
        {/* Featured groups */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Layers size={16} color={BRAND.primary} />
              <Box sx={{ fontSize: 15, fontWeight: 700 }}>Featured Domains</Box>
              <Chip size="small" label={`${groups.length} active`} sx={{ ml: 1 }} />
            </Box>
            <Button size="small" endIcon={<ArrowUpRight size={14} />}>View all</Button>
          </Box>

          <Grid container spacing={2.25}>
            {groups.map((g, i) => (
              <Grid key={g.id} size={{ xs: 12, sm: 6 }}>
                <Card sx={{
                  position: "relative", overflow: "hidden", cursor: "pointer",
                  transition: "transform .2s, box-shadow .2s",
                  "&:hover": { transform: "translateY(-3px)", boxShadow: "0 24px 60px -28px rgba(10,37,64,0.4)" },
                }} onClick={onOpenGroup}>
                  <Box sx={{ height: 96, background: g.cover, position: "relative" }}>
                    <Box sx={{ position: "absolute", inset: 0,
                      backgroundImage: "radial-gradient(circle at 80% 20%, rgba(255,255,255,0.25), transparent 50%)" }} />
                    <Box sx={{ position: "absolute", top: 10, left: 12, display: "flex", gap: 0.75 }}>
                      <Chip size="small" label={`${g.apps} apps`}
                        sx={{ bgcolor: "rgba(0,0,0,0.35)", color: "#fff", fontWeight: 600, backdropFilter: "blur(6px)" }} />
                      {i === 0 && <Chip size="small" icon={<Pin size={10} color="#fff" />} label="Pinned"
                        sx={{ bgcolor: "rgba(0,0,0,0.35)", color: "#fff", fontWeight: 600, backdropFilter: "blur(6px)" }} />}
                    </Box>
                    <Box sx={{ position: "absolute", top: 8, right: 8 }}>
                      <IconButton size="small" sx={{ color: "#fff", bgcolor: "rgba(0,0,0,0.25)", "&:hover": { bgcolor: "rgba(0,0,0,0.4)" } }}>
                        <MoreHorizontal size={14} />
                      </IconButton>
                    </Box>
                    <Box sx={{
                      position: "absolute", left: 16, bottom: -22,
                      width: 54, height: 54, borderRadius: 2.5,
                      background: `linear-gradient(135deg, ${g.color}, #0A2540)`,
                      border: "3px solid var(--mui-palette-background-paper)",
                      display: "grid", placeItems: "center", color: "#fff", fontWeight: 700,
                      boxShadow: "0 10px 24px -10px rgba(0,0,0,0.5)",
                    }}>
                      {g.name.split(" ").map(w=>w[0]).slice(0,2).join("")}
                    </Box>
                  </Box>
                  <CardContent sx={{ pt: 3.5 }}>
                    <Box sx={{ fontSize: 15.5, fontWeight: 700, mb: 0.5 }}>{g.name}</Box>
                    <Box sx={{ fontSize: 12.5, color: "text.secondary", mb: 2,
                      display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                      {g.description}
                    </Box>
                    <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <AvatarGroup max={4} sx={{ "& .MuiAvatar-root": { width: 24, height: 24, fontSize: 10, borderColor: "background.paper" } }}>
                        <Avatar key="m" sx={{ bgcolor: "#E6392D" }}>M</Avatar>
                        <Avatar key="s" sx={{ bgcolor: "#3B82F6" }}>S</Avatar>
                        <Avatar key="j" sx={{ bgcolor: "#10B981" }}>J</Avatar>
                        <Avatar key="p" sx={{ bgcolor: "#A855F7" }}>P</Avatar>
                        <Avatar key="l" sx={{ bgcolor: "#F59E0B" }}>L</Avatar>
                      </AvatarGroup>
                      <Box sx={{ display: "flex", gap: 1.5, fontSize: 11.5, color: "text.secondary" }}>
                        <Tooltip title="Risks"><Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}><ShieldCheck size={12} />{g.risks}</Box></Tooltip>
                        <Tooltip title="Members"><Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}><Users size={12} />{g.members}</Box></Tooltip>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, color: g.score > 90 ? "#16A34A" : g.score > 80 ? "#F59E0B" : "#E6392D" }}>
                          ● {g.score}
                        </Box>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
            {/* Create card */}
            <Grid size={{ xs: 12, sm: 6 }}>
              <Card onClick={onCreateGroup}
                sx={{
                  height: "100%", minHeight: 240, cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  border: "2px dashed", borderColor: "divider",
                  background: "transparent", boxShadow: "none",
                  transition: "all .2s",
                  "&:hover": {
                    borderColor: BRAND.primary,
                    background: "rgba(230,57,45,0.04)",
                  },
                }}>
                <Box sx={{ textAlign: "center", color: "text.secondary" }}>
                  <Box sx={{
                    mx: "auto", mb: 1.5, width: 52, height: 52, borderRadius: "50%",
                    background: `linear-gradient(135deg, ${BRAND.primaryLight}, ${BRAND.primary})`,
                    display: "grid", placeItems: "center", color: "#fff",
                    boxShadow: "0 12px 30px -12px rgba(230,57,45,0.7)",
                  }}>
                    <Plus size={22} />
                  </Box>
                  <Box sx={{ fontWeight: 700, color: "text.primary", fontSize: 14.5 }}>Create new domain</Box>
                  <Box sx={{ fontSize: 12.5, mt: 0.5 }}>Spin up a configurable GRC workspace</Box>
                </Box>
              </Card>
            </Grid>
          </Grid>
        </Grid>

        {/* Activity */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  <Activity size={16} color={BRAND.primary} />
                  <Box sx={{ fontSize: 15, fontWeight: 700 }}>Recent Activity</Box>
                </Box>
                <Chip size="small" label="Live" sx={{ bgcolor: "rgba(16,163,74,0.12)", color: "#16A34A", fontWeight: 700 }} />
              </Box>
              <Box sx={{ position: "relative", pl: 2 }}>
                <Box sx={{ position: "absolute", left: 7, top: 6, bottom: 6, width: 2, bgcolor: "divider" }} />
                {activity.map((a, i) => (
                  <Box key={i} sx={{ position: "relative", mb: 1.5, "&:last-of-type": { mb: 0 } }}>
                    <Box sx={{
                      position: "absolute", left: -16, top: 4, width: 14, height: 14,
                      borderRadius: "50%", border: "3px solid var(--mui-palette-background-paper)",
                      background: a.color,
                    }} />
                    <Box sx={{ fontSize: 13 }}>
                      <Box component="span" sx={{ fontWeight: 700 }}>{a.user}</Box>
                      <Box component="span" sx={{ color: "text.secondary" }}> {a.action} </Box>
                      <Chip size="small" label={a.target} sx={{ height: 18, fontSize: 10.5, fontWeight: 600 }} />
                    </Box>
                    <Box sx={{ fontSize: 11, color: "text.secondary", mt: 0.5 }}>{a.time}</Box>
                  </Box>
                ))}
              </Box>
              <Button fullWidth size="small" sx={{ mt: 1 }} endIcon={<ArrowUpRight size={14} />}>
                Open activity log
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
