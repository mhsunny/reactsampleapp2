import { useState } from "react";
import {
  Dialog, DialogContent, DialogActions, Button, Box, TextField, IconButton,
  List, ListItem, ListItemAvatar, ListItemText, Avatar, Chip, Stack, InputBase,
} from "@mui/material";
import { X, Search, UserPlus, Trash2, Crown, Shield } from "lucide-react";
import { BRAND } from "./theme";

type Member = {
  id: string;
  name: string;
  email: string;
  role: "Admin" | "Editor" | "Viewer";
  avatar: string;
};

export function ManageMembersModal({
  open,
  onClose,
  groupName,
}: {
  open: boolean;
  onClose: () => void;
  groupName: string;
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [members, setMembers] = useState<Member[]>([
    { id: "1", name: "Elena Marlowe", email: "elena.m@company.com", role: "Admin", avatar: "EM" },
    { id: "2", name: "Marcus Aldridge", email: "marcus.a@company.com", role: "Editor", avatar: "MA" },
    { id: "3", name: "Sophia Okafor", email: "sophia.o@company.com", role: "Editor", avatar: "SO" },
    { id: "4", name: "Jin Chen", email: "jin.c@company.com", role: "Viewer", avatar: "JC" },
    { id: "5", name: "Pavel Volkov", email: "pavel.v@company.com", role: "Viewer", avatar: "PV" },
  ]);

  const filteredMembers = members.filter(m =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleRemoveMember = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
  };

  const handleChangeRole = (id: string, role: Member["role"]) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, role } : m));
  };

  const getRoleColor = (role: Member["role"]) => {
    return role === "Admin" ? "#E6392D" : role === "Editor" ? "#3B82F6" : "#64748B";
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth
      PaperProps={{ sx: { borderRadius: "6px" } }}>
      <Box sx={{
        position: "relative",
        background: `linear-gradient(120deg, ${BRAND.primary} 0%, ${BRAND.primaryDeep} 100%)`,
        color: "#fff", p: 3,
      }}>
        <IconButton size="small" onClick={onClose}
          sx={{ position: "absolute", top: 12, right: 12, color: "#fff" }}>
          <X size={18}/>
        </IconButton>
        <Box sx={{ fontSize: 20, fontWeight: 700 }}>Manage Members</Box>
        <Box sx={{ fontSize: 13, opacity: 0.8, mt: 0.5 }}>
          {groupName} · {members.length} members
        </Box>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        {/* Search & Add */}
        <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
          <Box sx={{
            flex: 1, display: "flex", alignItems: "center", gap: 1,
            px: 1.25, py: 0.5, border: 1, borderColor: "divider", borderRadius: 2,
          }}>
            <Search size={15} opacity={0.6}/>
            <InputBase
              placeholder="Search members..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              sx={{ flex: 1, fontSize: 13 }}
            />
          </Box>
          <Button variant="outlined" startIcon={<UserPlus size={14}/>}>
            Add Member
          </Button>
        </Stack>

        {/* Members List */}
        <List sx={{ maxHeight: 400, overflow: "auto" }}>
          {filteredMembers.map((member) => (
            <ListItem
              key={member.id}
              sx={{
                borderRadius: 2,
                mb: 1,
                border: 1,
                borderColor: "divider",
                "&:hover": { bgcolor: "action.hover" },
              }}
              secondaryAction={
                <Stack direction="row" spacing={1} alignItems="center">
                  <TextField
                    select
                    size="small"
                    value={member.role}
                    onChange={(e) => handleChangeRole(member.id, e.target.value as Member["role"])}
                    SelectProps={{ native: true }}
                    sx={{ minWidth: 120 }}
                  >
                    <option value="Admin">Admin</option>
                    <option value="Editor">Editor</option>
                    <option value="Viewer">Viewer</option>
                  </TextField>
                  <IconButton
                    size="small"
                    onClick={() => handleRemoveMember(member.id)}
                    disabled={member.role === "Admin"}
                    sx={{ color: "error.main" }}
                  >
                    <Trash2 size={16}/>
                  </IconButton>
                </Stack>
              }
            >
              <ListItemAvatar>
                <Avatar sx={{ bgcolor: getRoleColor(member.role) }}>
                  {member.avatar}
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary={
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Box sx={{ fontWeight: 600 }}>{member.name}</Box>
                    {member.role === "Admin" && <Crown size={14} color="#E6392D"/>}
                  </Box>
                }
                secondary={member.email}
              />
            </ListItem>
          ))}
        </List>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: "divider" }}>
        <Box sx={{ fontSize: 12, color: "text.secondary", flex: 1 }}>
          {members.filter(m => m.role === "Admin").length} admin · {members.filter(m => m.role === "Editor").length} editor · {members.filter(m => m.role === "Viewer").length} viewer
        </Box>
        <Button onClick={onClose} variant="contained"
          sx={{ bgcolor: BRAND.primary, "&:hover": { bgcolor: BRAND.primaryDeep } }}>
          Done
        </Button>
      </DialogActions>
    </Dialog>
  );
}
