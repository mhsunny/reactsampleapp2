import {
  Box, Card, CardContent, Grid, Chip, Button, IconButton, Avatar, LinearProgress, Stack, Divider,
  Stepper, Step, StepLabel, StepContent, Switch, FormControlLabel, Tabs, Tab, Table, TableHead,
  TableRow, TableCell, TableBody, ToggleButton, ToggleButtonGroup, TextField, MenuItem, Slider, Tooltip,
} from "@mui/material";
import { useState } from "react";
import {
  Gauge, AlertOctagon, ClipboardCheck, Scale, Activity, Search as SearchIcon,
  TrendingUp, Settings2, Plus, MoreHorizontal, CheckCircle2, Circle, ArrowUpRight, Shield,
  FileText, Filter, Download, Eye, Edit3, GripVertical, Users, Lock, Bell, ArrowDownRight,
  Sparkles, FlaskConical, Zap,
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, AreaChart, Area, BarChart, Bar, RadarChart,
  PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, Tooltip as RTooltip,
  CartesianGrid, ComposedChart, Legend,
} from "recharts";
import { BRAND } from "./theme";
import { obligations, trendData } from "./data";

// ===================== Risk Measures =====================
export function RiskMeasures() {
  const scenarios = [
    { name: "Severe cyber incident — ransomware", impact: "$184M", likelihood: 12, color: BRAND.primary },
    { name: "Major vendor outage — Tier 1 cloud", impact: "$96M", likelihood: 22, color: "#F59E0B" },
    { name: "Sanctions enforcement action", impact: "$220M", likelihood: 7, color: "#A855F7" },
    { name: "Macro recession scenario", impact: "$412M", likelihood: 18, color: "#3B82F6" },
  ];
  const kris = [
    { name: "Failed transactions / 10k", value: 12.4, threshold: 15, ok: true, trend: [10,11,12,11,13,12,11,12] },
    { name: "Phishing click-through %", value: 1.8, threshold: 2.0, ok: true, trend: [1.2,1.4,1.6,1.5,1.7,1.9,1.8,1.8] },
    { name: "AML alert backlog", value: 142, threshold: 100, ok: false, trend: [60,72,84,98,112,128,138,142] },
    { name: "Privileged access changes / day", value: 38, threshold: 50, ok: true, trend: [22,28,30,32,28,34,36,38] },
  ];
  return (
    <Box>
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {kris.map((k) => (
          <Grid key={k.name} size={{ xs: 12, sm: 6, lg: 3 }}>
            <Card>
              <CardContent>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <Box sx={{ fontSize: 12, color: "text.secondary", fontWeight: 600 }}>{k.name}</Box>
                  <Chip size="small" label={k.ok ? "Within tolerance" : "Breach"}
                    sx={{ bgcolor: k.ok ? "rgba(16,163,74,0.12)" : "rgba(230,57,45,0.12)",
                      color: k.ok ? "#16A34A" : BRAND.primary, fontWeight: 700 }} />
                </Box>
                <Box sx={{ fontSize: 28, fontWeight: 700, mt: 0.5 }}>{k.value}</Box>
                <Box sx={{ fontSize: 11, color: "text.secondary" }}>Threshold {k.threshold}</Box>
                <Box sx={{ height: 44, mx: -1, mt: 0.5 }}>
                  <ResponsiveContainer>
                    <LineChart data={k.trend.map((v, i) => ({ i, v }))}>
                      <Line dataKey="v" stroke={k.ok ? "#16A34A" : BRAND.primary} strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2.5}>
        <Grid size={{ xs: 12, lg: 7 }}>
          <Card>
            <CardContent>
              <Box sx={{ fontWeight: 700, fontSize: 15, mb: 0.25 }}>Scenario Analysis</Box>
              <Box sx={{ fontSize: 12, color: "text.secondary", mb: 2 }}>Top-of-house quantified scenarios</Box>
              <Box sx={{ height: 280 }}>
                <ResponsiveContainer>
                  <ComposedChart data={trendData}>
                    <CartesianGrid stroke="rgba(127,127,127,0.1)" vertical={false} />
                    <XAxis dataKey="month" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis fontSize={11} tickLine={false} axisLine={false} />
                    <RTooltip />
                    <Bar dataKey="events" fill={BRAND.primary} radius={[6,6,0,0]} barSize={14} />
                    <Line dataKey="inherent" stroke="#3B82F6" strokeWidth={2.5} dot={false} />
                  </ComposedChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, lg: 5 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ fontWeight: 700, fontSize: 15, mb: 1.5 }}>Scenarios Catalog</Box>
              <Stack divider={<Divider />} spacing={0}>
                {scenarios.map((s) => (
                  <Box key={s.name} sx={{ py: 1.5, display: "flex", alignItems: "center", gap: 1.5 }}>
                    <Box sx={{ width: 8, height: 40, borderRadius: 1, bgcolor: s.color }} />
                    <Box sx={{ flex: 1 }}>
                      <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>{s.name}</Box>
                      <Box sx={{ fontSize: 11.5, color: "text.secondary" }}>
                        Likelihood {s.likelihood}% · Impact {s.impact}
                      </Box>
                    </Box>
                    <IconButton size="small"><MoreHorizontal size={14} /></IconButton>
                  </Box>
                ))}
              </Stack>
              <Button fullWidth size="small" sx={{ mt: 1 }} startIcon={<Plus size={14} />}>Add scenario</Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

// ===================== Risk Events =====================
export function RiskEvents() {
  const events = [
    { id: "INC-2026-0184", sev: "Critical", title: "Production outage — Payment Gateway", impact: "$1.2M", status: "Resolved", time: "2h" },
    { id: "INC-2026-0183", sev: "High", title: "Data exfil attempt — flagged by DLP", impact: "—", status: "Investigating", time: "5h" },
    { id: "INC-2026-0182", sev: "Medium", title: "Vendor SLA breach — KYC provider", impact: "$48K", status: "Mitigating", time: "1d" },
    { id: "INC-2026-0181", sev: "High", title: "Suspicious wire — sanctions hit", impact: "$2.4M", status: "Escalated", time: "1d" },
    { id: "INC-2026-0180", sev: "Low", title: "Phishing attempt — blocked", impact: "—", status: "Closed", time: "2d" },
  ];
  const sevColor = (s: string) => s === "Critical" ? BRAND.primary : s === "High" ? "#F59E0B" : s === "Medium" ? "#3B82F6" : "#10B981";
  return (
    <Box>
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {[
          { l: "Open Incidents", v: "26", d: "+4", up: true, c: BRAND.primary, i: AlertOctagon },
          { l: "Loss YTD", v: "$8.4M", d: "-12%", up: false, c: "#F59E0B", i: TrendingUp },
          { l: "MTTR", v: "4.2h", d: "-22m", up: false, c: "#10B981", i: Activity },
          { l: "Near-misses", v: "112", d: "+18", up: true, c: "#3B82F6", i: Shield },
        ].map((k) => (
          <Grid key={k.l} size={{ xs: 12, sm: 6, lg: 3 }}>
            <Card><CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Box sx={{ fontSize: 12, color: "text.secondary", fontWeight: 600 }}>{k.l}</Box>
                <Box sx={{ width: 32, height: 32, borderRadius: 2, bgcolor: `${k.c}1A`, color: k.c, display: "grid", placeItems: "center" }}>
                  <k.i size={16} />
                </Box>
              </Box>
              <Box sx={{ fontSize: 26, fontWeight: 700, mt: 0.5 }}>{k.v}</Box>
              <Chip size="small" icon={k.up ? <ArrowUpRight size={12}/> : <ArrowDownRight size={12}/>}
                label={k.d} sx={{ bgcolor: k.up ? "rgba(230,57,45,0.12)" : "rgba(16,163,74,0.12)",
                  color: k.up ? BRAND.primary : "#16A34A", fontWeight: 700 }} />
            </CardContent></Card>
          </Grid>
        ))}
      </Grid>

      <Card>
        <CardContent>
          <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
            <Box sx={{ fontWeight: 700, fontSize: 15 }}>Incident Stream</Box>
            <Box sx={{ flex: 1 }} />
            <Button size="small" startIcon={<Filter size={14} />}>Filter</Button>
            <Button size="small" variant="contained" startIcon={<Plus size={14} />} sx={{ ml: 1 }}>Log incident</Button>
          </Box>
          <Stack divider={<Divider />} spacing={0}>
            {events.map((e) => (
              <Box key={e.id} sx={{ py: 1.75, display: "flex", alignItems: "center", gap: 2 }}>
                <Box sx={{ width: 38, height: 38, borderRadius: 2,
                  bgcolor: `${sevColor(e.sev)}1A`, color: sevColor(e.sev), display: "grid", placeItems: "center" }}>
                  <AlertOctagon size={18} />
                </Box>
                <Box sx={{ minWidth: 110 }}>
                  <Box sx={{ fontSize: 11, color: "text.secondary" }}>{e.id}</Box>
                  <Chip size="small" label={e.sev}
                    sx={{ bgcolor: `${sevColor(e.sev)}1A`, color: sevColor(e.sev), height: 18, fontWeight: 700, fontSize: 10.5 }} />
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>{e.title}</Box>
                  <Box sx={{ fontSize: 11.5, color: "text.secondary", mt: 0.25 }}>Impact: {e.impact} · {e.time} ago</Box>
                </Box>
                <Chip size="small" label={e.status} variant="outlined" />
                <Button size="small" endIcon={<ArrowUpRight size={12}/>}>Open</Button>
              </Box>
            ))}
          </Stack>
        </CardContent>
      </Card>
    </Box>
  );
}

// ===================== Risk Assessments =====================
export function RiskAssessments() {
  const [active, setActive] = useState(1);
  const templates = [
    { name: "RCSA — Operational Risk", q: 64, dur: "45 min", color: BRAND.primary },
    { name: "Third-Party Risk", q: 38, dur: "25 min", color: "#3B82F6" },
    { name: "DPIA — GDPR", q: 22, dur: "20 min", color: "#A855F7" },
    { name: "Model Risk Validation", q: 56, dur: "60 min", color: "#10B981" },
  ];
  return (
    <Box>
      <Grid container spacing={2.5}>
        <Grid size={{ xs: 12, lg: 5 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
                <Box sx={{ fontWeight: 700, fontSize: 15 }}>Assessment Templates</Box>
                <Button size="small" startIcon={<Plus size={14}/>}>New template</Button>
              </Box>
              <Stack spacing={1.5}>
                {templates.map((t) => (
                  <Box key={t.name} sx={{
                    p: 2, borderRadius: 3, border: 1, borderColor: "divider",
                    display: "flex", alignItems: "center", gap: 2,
                    transition: "all .2s", cursor: "pointer",
                    "&:hover": { borderColor: t.color, transform: "translateX(2px)" },
                  }}>
                    <Box sx={{ width: 42, height: 42, borderRadius: 2,
                      background: `${t.color}1A`, color: t.color, display: "grid", placeItems: "center" }}>
                      <ClipboardCheck size={20} />
                    </Box>
                    <Box sx={{ flex: 1 }}>
                      <Box sx={{ fontWeight: 600, fontSize: 13.5 }}>{t.name}</Box>
                      <Box sx={{ fontSize: 11.5, color: "text.secondary" }}>{t.q} questions · ~{t.dur}</Box>
                    </Box>
                    <IconButton size="small"><MoreHorizontal size={14}/></IconButton>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 7 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 15 }}>RCSA Q2-EMEA · In Progress</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary" }}>Owner: J. Chen · Due 2026-06-20</Box>
                </Box>
                <Chip size="small" label="62% complete" sx={{ bgcolor: "rgba(59,130,246,0.12)", color: "#3B82F6", fontWeight: 700 }}/>
              </Box>
              <LinearProgress variant="determinate" value={62} sx={{ height: 8, borderRadius: 4, mb: 3,
                "& .MuiLinearProgress-bar": { background: `linear-gradient(90deg,${BRAND.primaryLight},${BRAND.primary})` } }} />

              <Stepper activeStep={active} orientation="vertical">
                {[
                  { l: "Scope & Context", d: "Business unit, processes, materiality" },
                  { l: "Risk Identification", d: "Catalog inherent risks for in-scope processes" },
                  { l: "Control Mapping", d: "Map existing controls and assess design effectiveness" },
                  { l: "Residual Scoring", d: "Likelihood × impact, with mitigation factors" },
                  { l: "Review & Sign-off", d: "Owner attestation and second-line review" },
                ].map((s, i) => (
                  <Step key={s.l} completed={i < active}>
                    <StepLabel
                      onClick={() => setActive(i)}
                      sx={{ cursor: "pointer", "& .MuiStepLabel-label": { fontWeight: 600 } }}>
                      {s.l}
                    </StepLabel>
                    <StepContent>
                      <Box sx={{ fontSize: 13, color: "text.secondary", mb: 1 }}>{s.d}</Box>
                      <Stack direction="row" spacing={1}>
                        <Button size="small" variant="contained" onClick={() => setActive(active + 1)}>Continue</Button>
                        <Button size="small">Save draft</Button>
                      </Stack>
                    </StepContent>
                  </Step>
                ))}
              </Stepper>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

// ===================== Compliance Matrix =====================
export function ComplianceMatrix() {
  const cells = ["Identify", "Protect", "Detect", "Respond", "Recover"];
  const frameworks = obligations;
  const stat = (n: number) =>
    n >= 95 ? { color: "#10B981", label: "Mature" } : n >= 85 ? { color: "#3B82F6", label: "Effective" } :
    n >= 70 ? { color: "#F59E0B", label: "Developing" } : { color: BRAND.primary, label: "Gap" };

  return (
    <Box>
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 15 }}>Compliance Strategy Matrix</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary" }}>Frameworks × NIST functions · live coverage</Box>
                </Box>
                <Stack direction="row" spacing={1}>
                  {[{c:"#10B981",l:"Mature"},{c:"#3B82F6",l:"Effective"},{c:"#F59E0B",l:"Developing"},{c:BRAND.primary,l:"Gap"}].map(x => (
                    <Chip key={x.l} size="small" label={x.l} sx={{ bgcolor: `${x.c}1A`, color: x.c, fontWeight: 700 }}/>
                  ))}
                </Stack>
              </Box>

              <Box sx={{ overflow: "auto" }}>
                <Box sx={{ display: "grid", gridTemplateColumns: `200px repeat(${cells.length}, 1fr)`, gap: 1, minWidth: 720 }}>
                  <Box />
                  {cells.map(c => (
                    <Box key={c} sx={{ fontSize: 11, fontWeight: 700, textAlign: "center", color: "text.secondary",
                      textTransform: "uppercase", letterSpacing: ".1em" }}>{c}</Box>
                  ))}
                  {frameworks.map((f) => (
                    <Box key={f.framework} sx={{ display: "contents" }}>
                      <Box sx={{ fontSize: 13, fontWeight: 700, py: 1.25, display: "flex", alignItems: "center", gap: 1 }}>
                        <Box sx={{ width: 28, height: 28, borderRadius: 1.5, bgcolor: "action.hover",
                          display: "grid", placeItems: "center", fontSize: 10, fontWeight: 700 }}>
                          {f.framework.slice(0,2)}
                        </Box>
                        <Box>
                          <Box>{f.framework}</Box>
                          <Box sx={{ fontSize: 10.5, color: "text.secondary", fontWeight: 500 }}>{f.owner}</Box>
                        </Box>
                      </Box>
                      {cells.map((_, ci) => {
                        const pct = Math.min(100, Math.max(40, f.coverage - ci * 4 + (ci % 2 ? 6 : -3)));
                        const s = stat(pct);
                        return (
                          <Tooltip key={ci} title={`${f.framework} · ${cells[ci]} · ${pct}%`}>
                            <Box sx={{
                              borderRadius: 2, p: 1.25, textAlign: "center", cursor: "pointer",
                              background: `${s.color}14`, border: `1px solid ${s.color}33`,
                              transition: "transform .15s", "&:hover": { transform: "scale(1.04)" },
                            }}>
                              <Box sx={{ fontSize: 16, fontWeight: 700, color: s.color }}>{pct}%</Box>
                              <Box sx={{ fontSize: 10, color: s.color, fontWeight: 700 }}>{s.label}</Box>
                            </Box>
                          </Tooltip>
                        );
                      })}
                    </Box>
                  ))}
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ fontWeight: 700, fontSize: 15, mb: 1.5 }}>Coverage by Framework</Box>
              <Stack spacing={2}>
                {frameworks.map((f) => (
                  <Box key={f.framework}>
                    <Box sx={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, mb: 0.5 }}>
                      <Box sx={{ fontWeight: 600 }}>{f.framework}</Box>
                      <Box sx={{ color: "text.secondary" }}>{f.controls} ctrls · <b style={{color: f.gaps > 10 ? BRAND.primary : "#F59E0B"}}>{f.gaps} gaps</b></Box>
                    </Box>
                    <LinearProgress variant="determinate" value={f.coverage}
                      sx={{ height: 8, borderRadius: 4, bgcolor: "action.hover",
                        "& .MuiLinearProgress-bar": {
                          background: f.coverage > 90 ? "linear-gradient(90deg,#10B981,#22D3EE)" :
                            f.coverage > 80 ? "linear-gradient(90deg,#3B82F6,#22D3EE)" :
                            `linear-gradient(90deg,#F59E0B,${BRAND.primary})`,
                        }}} />
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

// ===================== Monitoring =====================
export function Monitoring() {
  const monitors = [
    { name: "PCI-DSS — Network segmentation", status: "OK", score: 98 },
    { name: "Privileged access reviews", status: "OK", score: 95 },
    { name: "Cloud key rotation policy", status: "Warn", score: 78 },
    { name: "Vendor SOC2 freshness", status: "Critical", score: 54 },
    { name: "Backup restore drills", status: "OK", score: 92 },
    { name: "Anti-money laundering thresholds", status: "Warn", score: 81 },
  ];
  const c = (s: string) => s === "OK" ? "#16A34A" : s === "Warn" ? "#F59E0B" : BRAND.primary;
  return (
    <Box>
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, lg: 7 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                <Box sx={{ fontWeight: 700, fontSize: 15 }}>Control Health</Box>
                <Chip size="small" icon={<Sparkles size={12}/>} label="Continuous" sx={{ fontWeight: 700 }}/>
              </Box>
              <Box sx={{ height: 300 }}>
                <ResponsiveContainer>
                  <RadarChart data={[
                    { k: "Access", a: 96 }, { k: "Network", a: 88 }, { k: "Data", a: 82 },
                    { k: "Cloud", a: 76 }, { k: "Vendor", a: 64 }, { k: "Privacy", a: 91 },
                    { k: "Model", a: 78 }, { k: "Resilience", a: 86 },
                  ]}>
                    <PolarGrid stroke="rgba(127,127,127,0.18)" />
                    <PolarAngleAxis dataKey="k" tick={{ fontSize: 11 }} />
                    <PolarRadiusAxis tick={false} axisLine={false} />
                    <Radar name="Coverage" dataKey="a" stroke={BRAND.primary} fill={BRAND.primary} fillOpacity={0.25} strokeWidth={2}/>
                  </RadarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, lg: 5 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ fontWeight: 700, fontSize: 15, mb: 1.5 }}>Active Monitors</Box>
              <Stack spacing={1.25}>
                {monitors.map((m) => (
                  <Box key={m.name} sx={{ display: "flex", alignItems: "center", gap: 1.5,
                    p: 1.25, borderRadius: 2, bgcolor: "action.hover" }}>
                    <Box sx={{ width: 10, height: 10, borderRadius: "50%", bgcolor: c(m.status),
                      boxShadow: `0 0 0 4px ${c(m.status)}22` }}/>
                    <Box sx={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{m.name}</Box>
                    <Box sx={{ width: 90 }}>
                      <LinearProgress variant="determinate" value={m.score}
                        sx={{ height: 5, borderRadius: 3, bgcolor: "rgba(127,127,127,0.15)",
                          "& .MuiLinearProgress-bar": { backgroundColor: c(m.status) }}}/>
                    </Box>
                    <Box sx={{ fontWeight: 700, fontSize: 12.5, color: c(m.status), minWidth: 28, textAlign: "right" }}>{m.score}</Box>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Card>
        <CardContent>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
            <Box sx={{ fontWeight: 700, fontSize: 15 }}>Workflow Designer · Incident Response</Box>
            <Button size="small" startIcon={<Edit3 size={14}/>}>Edit workflow</Button>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, overflowX: "auto", pb: 1 }}>
            {[
              { l: "Trigger", d: "KRI breach", c: "#3B82F6", i: Zap },
              { l: "Classify", d: "Severity + scope", c: "#A855F7", i: SearchIcon },
              { l: "Notify", d: "On-call + CRO", c: "#F59E0B", i: Bell },
              { l: "Mitigate", d: "Playbook X-12", c: BRAND.primary, i: Shield },
              { l: "Verify", d: "Control test", c: "#10B981", i: CheckCircle2 },
              { l: "Close", d: "Lessons learned", c: "#06B6D4", i: FileText },
            ].map((n, i, arr) => (
              <Box key={n.l} sx={{ display: "flex", alignItems: "center" }}>
                <Box sx={{
                  minWidth: 150, p: 1.5, borderRadius: 3, border: 1, borderColor: "divider",
                  bgcolor: "background.paper", display: "flex", alignItems: "center", gap: 1.25,
                  position: "relative",
                }}>
                  <Box sx={{ width: 34, height: 34, borderRadius: 2, bgcolor: `${n.c}1A`, color: n.c, display: "grid", placeItems: "center" }}>
                    <n.i size={16} />
                  </Box>
                  <Box>
                    <Box sx={{ fontWeight: 700, fontSize: 13 }}>{n.l}</Box>
                    <Box sx={{ fontSize: 11, color: "text.secondary" }}>{n.d}</Box>
                  </Box>
                  <GripVertical size={12} style={{ position: "absolute", right: 6, top: 6, opacity: 0.3 }} />
                </Box>
                {i < arr.length - 1 && (
                  <Box sx={{ width: 32, height: 2, bgcolor: "divider", position: "relative",
                    "&::after": { content: '"›"', position: "absolute", right: -4, top: -10, color: "text.secondary" } }} />
                )}
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}

// ===================== Configuration Hub =====================
export function ConfigHub() {
  return (
    <Grid container spacing={2.5}>
      {[
        { t: "Taxonomy", d: "Risk categories, sub-types, severity ladders", i: Settings2 },
        { t: "Workflows", d: "Approval flows, escalations, SLAs", i: Activity },
        { t: "Templates", d: "Assessments, controls, policies", i: FileText },
        { t: "Integrations", d: "JIRA, ServiceNow, Splunk, AWS, GCP", i: Zap },
        { t: "AI Assistants", d: "Risk copilots and continuous monitors", i: Sparkles },
        { t: "Branding", d: "Themes, logos, white-label", i: Edit3 },
      ].map((x) => (
        <Grid key={x.t} size={{ xs: 12, sm: 6, lg: 4 }}>
          <Card sx={{ cursor: "pointer", "&:hover": { borderColor: BRAND.primary }, transition: "border-color .2s" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
                <Box sx={{ width: 42, height: 42, borderRadius: 2,
                  background: `linear-gradient(135deg,${BRAND.primaryLight}22,${BRAND.primary}30)`,
                  color: BRAND.primary, display: "grid", placeItems: "center" }}>
                  <x.i size={20}/>
                </Box>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 15 }}>{x.t}</Box>
                  <Box sx={{ fontSize: 12.5, color: "text.secondary", mt: 0.5 }}>{x.d}</Box>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <FormControlLabel control={<Switch size="small" defaultChecked />} label={<Box sx={{ fontSize: 12.5 }}>Enabled</Box>}/>
                <Button size="small" endIcon={<ArrowUpRight size={12}/>}>Open</Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}

// ===================== Settings & RBAC =====================
export function SettingsRBAC() {
  const roles = [
    { name: "Chief Risk Officer", users: 2, perms: ["All apps", "All modules", "Admin"], color: BRAND.primary },
    { name: "Compliance Officer", users: 8, perms: ["Compliance", "Audit", "View Risk"], color: "#3B82F6" },
    { name: "Risk Analyst", users: 32, perms: ["Risk Inv.", "Assessments", "Events"], color: "#F59E0B" },
    { name: "Auditor", users: 14, perms: ["Read-only", "Evidence", "Reports"], color: "#A855F7" },
    { name: "Business Owner", users: 86, perms: ["Assigned units", "Attestations"], color: "#10B981" },
  ];
  return (
    <Grid container spacing={2.5}>
      <Grid size={{ xs: 12, lg: 8 }}>
        <Card>
          <CardContent>
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
              <Box sx={{ fontWeight: 700, fontSize: 15 }}>Roles & Permissions</Box>
              <Button size="small" variant="contained" startIcon={<Plus size={14}/>}>New role</Button>
            </Box>
            <Stack spacing={1.25}>
              {roles.map((r) => (
                <Box key={r.name} sx={{
                  p: 2, borderRadius: 3, border: 1, borderColor: "divider",
                  display: "flex", alignItems: "center", gap: 2,
                }}>
                  <Box sx={{ width: 42, height: 42, borderRadius: 2,
                    bgcolor: `${r.color}1A`, color: r.color, display: "grid", placeItems: "center" }}>
                    <Lock size={18}/>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ fontWeight: 700, fontSize: 14 }}>{r.name}</Box>
                    <Box sx={{ display: "flex", gap: 0.75, mt: 0.75, flexWrap: "wrap" }}>
                      {r.perms.map(p => <Chip key={p} size="small" label={p} variant="outlined" sx={{ height: 20, fontSize: 10.5 }}/>)}
                    </Box>
                  </Box>
                  <Box sx={{ textAlign: "center" }}>
                    <Box sx={{ fontWeight: 700, fontSize: 18 }}>{r.users}</Box>
                    <Box sx={{ fontSize: 10.5, color: "text.secondary", textTransform: "uppercase", letterSpacing: ".1em" }}>Users</Box>
                  </Box>
                  <IconButton size="small"><MoreHorizontal size={14}/></IconButton>
                </Box>
              ))}
            </Stack>
          </CardContent>
        </Card>
      </Grid>

      <Grid size={{ xs: 12, lg: 4 }}>
        <Card sx={{ mb: 2.5 }}>
          <CardContent>
            <Box sx={{ fontWeight: 700, fontSize: 15, mb: 1.5 }}>Security</Box>
            <Stack spacing={1.5}>
              <FormControlLabel control={<Switch defaultChecked size="small"/>} label="Enforce SSO (Okta)" />
              <FormControlLabel control={<Switch defaultChecked size="small"/>} label="MFA required" />
              <FormControlLabel control={<Switch defaultChecked size="small"/>} label="IP allowlist" />
              <FormControlLabel control={<Switch size="small"/>} label="JIT access requests" />
              <Divider />
              <Box>
                <Box sx={{ fontSize: 12, color: "text.secondary", mb: 0.5 }}>Session timeout</Box>
                <Slider defaultValue={30} marks min={5} max={120}
                  valueLabelDisplay="auto" valueLabelFormat={(v) => `${v}m`}
                  sx={{ color: BRAND.primary }}/>
              </Box>
            </Stack>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <Box sx={{ fontWeight: 700, fontSize: 15, mb: 1.5 }}>Notifications</Box>
            <Stack spacing={1}>
              {["Critical incidents", "KRI threshold breaches", "Assessment due", "Policy attestations", "Audit findings"].map(l => (
                <FormControlLabel key={l} control={<Switch size="small" defaultChecked/>} label={<Box sx={{ fontSize: 13 }}>{l}</Box>} />
              ))}
            </Stack>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
}

// ===================== Generic placeholder for testing/audit/capacity =====================
export function GenericModule({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <Box>
      <Card sx={{ mb: 2.5 }}>
        <CardContent>
          <Box sx={{ fontWeight: 700, fontSize: 18 }}>{title}</Box>
          <Box sx={{ fontSize: 13, color: "text.secondary" }}>{subtitle}</Box>
        </CardContent>
      </Card>
      <Grid container spacing={2.5}>
        {[1,2,3,4].map(i => (
          <Grid key={i} size={{ xs: 12, sm: 6, lg: 3 }}>
            <Card><CardContent>
              <Box sx={{ fontSize: 12, color: "text.secondary", fontWeight: 600 }}>Metric {i}</Box>
              <Box sx={{ fontSize: 28, fontWeight: 700, mt: 0.5 }}>{(Math.random()*100).toFixed(1)}</Box>
              <Box sx={{ height: 48, mx: -1, mt: 1 }}>
                <ResponsiveContainer>
                  <AreaChart data={Array.from({length: 12}).map((_,i)=>({i, v: 20 + Math.random()*60}))}>
                    <defs>
                      <linearGradient id={`gen-${i}`} x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor={BRAND.primary} stopOpacity={0.4}/>
                        <stop offset="100%" stopColor={BRAND.primary} stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area dataKey="v" stroke={BRAND.primary} strokeWidth={2} fill={`url(#gen-${i})`}/>
                  </AreaChart>
                </ResponsiveContainer>
              </Box>
            </CardContent></Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
