import { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogActions, Button, Box, TextField, IconButton,
} from "@mui/material";
import { X, Check } from "lucide-react";
import { BRAND } from "./theme";

export function RenameGroupModal({
  open,
  onClose,
  groupName,
  onRename,
}: {
  open: boolean;
  onClose: () => void;
  groupName: string;
  onRename: (newName: string, newDescription: string) => void;
}) {
  const [name, setName] = useState(groupName);
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (open) {
      setName(groupName);
    }
  }, [open, groupName]);

  const handleSave = () => {
    if (name.trim()) {
      onRename(name.trim(), description.trim());
      onClose();
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth
      PaperProps={{ sx: { borderRadius: "6px" } }}>
      <Box sx={{
        position: "relative",
        background: `linear-gradient(120deg, ${BRAND.primary} 0%, ${BRAND.primaryDeep} 100%)`,
        color: "#fff", p: 3,
      }}>
        <IconButton size="small" onClick={onClose}
          sx={{ position: "absolute", top: 12, right: 12, color: "#fff" }}>
          <X size={18}/>
        </IconButton>
        <Box sx={{ fontSize: 20, fontWeight: 700 }}>Rename Domain</Box>
        <Box sx={{ fontSize: 13, opacity: 0.8, mt: 0.5 }}>
          Update the domain name and description
        </Box>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        <TextField
          label="Domain Name"
          fullWidth
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. North America Banking"
          sx={{ mb: 2 }}
        />
        <TextField
          label="Description"
          fullWidth
          multiline
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of this domain..."
        />
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, borderTop: 1, borderColor: "divider" }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          variant="contained"
          startIcon={<Check size={14}/>}
          onClick={handleSave}
          disabled={!name.trim()}
          sx={{ bgcolor: BRAND.primary, "&:hover": { bgcolor: BRAND.primaryDeep } }}
        >
          Save Changes
        </Button>
      </DialogActions>
    </Dialog>
  );
}
