import { useState } from "react";
import {
  Box, Card, CardContent, Grid, Chip, Button, IconButton, InputBase, Menu, MenuItem,
  Table, TableHead, TableRow, TableCell, TableBody, Checkbox, Avatar, ToggleButton, ToggleButtonGroup,
  TablePagination, Tooltip, Stack, Divider, LinearProgress,
} from "@mui/material";
import {
  Filter, Search, Download, Plus, MoreHorizontal, Columns3, Pin, ArrowUpDown,
  LayoutGrid, List as ListIcon, ArrowUpRight, ArrowDownRight, Sparkles, ShieldAlert,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer,
  XAxis, YAxis, Tooltip as RTooltip, CartesianGrid, Legend, ComposedChart,
} from "recharts";
import { BRAND } from "./theme";
import { risks, trendData, donutData, heatmap } from "./data";

const kpis = [
  { label: "Critical Risks", value: "47", delta: "+6", up: true, color: BRAND.primary },
  { label: "Avg. Residual Score", value: "62.4", delta: "-3.1", up: false, color: "#F59E0B" },
  { label: "Mitigation Velocity", value: "11.4d", delta: "-0.8d", up: false, color: "#10B981" },
  { label: "Control Coverage", value: "94%", delta: "+1.2%", up: true, color: "#3B82F6" },
];

const sevColor = (s: string) =>
  s === "Critical" ? "#E6392D" : s === "High" ? "#F59E0B" : s === "Medium" ? "#3B82F6" : "#10B981";
const statColor = (s: string) =>
  s === "Open" ? "#E6392D" : s === "Mitigating" ? "#F59E0B" : s === "Monitoring" ? "#3B82F6" : "#10B981";

export function RiskInventory() {
  const [view, setView] = useState<"table" | "grid">("table");
  const [page, setPage] = useState(0);
  const [rpp, setRpp] = useState(5);
  const [filterAnchor, setFilterAnchor] = useState<null | HTMLElement>(null);
  const [colAnchor, setColAnchor] = useState<null | HTMLElement>(null);
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (id: string) =>
    setSelected((s) => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);

  return (
    <Box>
      {/* KPIs */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {kpis.map((k) => (
          <Grid key={k.label} size={{ xs: 12, sm: 6, lg: 3 }}>
            <Card>
              <CardContent>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <Box sx={{ fontSize: 12.5, color: "text.secondary", fontWeight: 600 }}>{k.label}</Box>
                  <Chip size="small"
                    icon={k.up ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    label={k.delta}
                    sx={{ bgcolor: `${k.color}1A`, color: k.color, fontWeight: 700 }} />
                </Box>
                <Box sx={{ fontSize: 30, fontWeight: 700, mt: 0.5, letterSpacing: "-0.02em" }}>{k.value}</Box>
                <LinearProgress variant="determinate" value={Math.min(100, parseFloat(k.value) || 70)}
                  sx={{ mt: 1.5, height: 6, borderRadius: 3, bgcolor: "action.hover",
                    "& .MuiLinearProgress-bar": { backgroundColor: k.color } }} />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Charts row */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 15 }}>Inherent vs. Residual Risk Trend</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary" }}>Trailing 12 months · all categories</Box>
                </Box>
                <Stack direction="row" spacing={1}>
                  <Chip size="small" label="Inherent" sx={{ bgcolor: "rgba(230,57,45,0.12)", color: BRAND.primary, fontWeight: 700 }} />
                  <Chip size="small" label="Residual" sx={{ bgcolor: "rgba(59,130,246,0.12)", color: "#3B82F6", fontWeight: 700 }} />
                  <Chip size="small" label="Events" sx={{ bgcolor: "rgba(245,158,11,0.12)", color: "#F59E0B", fontWeight: 700 }} />
                </Stack>
              </Box>
              <Box sx={{ height: 280 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={trendData}>
                    <defs>
                      <linearGradient id="gInh" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor={BRAND.primary} stopOpacity={0.5} />
                        <stop offset="100%" stopColor={BRAND.primary} stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="gRes" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor="#3B82F6" stopOpacity={0.5} />
                        <stop offset="100%" stopColor="#3B82F6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="rgba(127,127,127,0.12)" vertical={false} />
                    <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={11} />
                    <YAxis tickLine={false} axisLine={false} fontSize={11} />
                    <RTooltip contentStyle={{ borderRadius: 12, border: "1px solid rgba(127,127,127,0.2)" }} />
                    <Area type="monotone" dataKey="inherent" stroke={BRAND.primary} strokeWidth={2.5} fill="url(#gInh)" />
                    <Area type="monotone" dataKey="residual" stroke="#3B82F6" strokeWidth={2.5} fill="url(#gRes)" />
                    <Bar dataKey="events" fill="#F59E0B" radius={[4,4,0,0]} barSize={10} />
                  </ComposedChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ fontWeight: 700, fontSize: 15 }}>Risk Distribution</Box>
              <Box sx={{ fontSize: 12, color: "text.secondary", mb: 1 }}>By category</Box>
              <Box sx={{ height: 200, position: "relative" }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={donutData} dataKey="value" innerRadius={55} outerRadius={82} paddingAngle={3} stroke="none">
                      {donutData.map((d, i) => <Cell key={i} fill={d.color} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{
                  position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none",
                }}>
                  <Box sx={{ textAlign: "center" }}>
                    <Box sx={{ fontSize: 11, color: "text.secondary" }}>Total</Box>
                    <Box sx={{ fontSize: 24, fontWeight: 700 }}>749</Box>
                  </Box>
                </Box>
              </Box>
              <Stack spacing={0.75} sx={{ mt: 1 }}>
                {donutData.map((d) => (
                  <Box key={d.name} sx={{ display: "flex", alignItems: "center", gap: 1, fontSize: 12.5 }}>
                    <Box sx={{ width: 9, height: 9, borderRadius: "50%", bgcolor: d.color }} />
                    <Box sx={{ flex: 1 }}>{d.name}</Box>
                    <Box sx={{ fontWeight: 700 }}>{d.value}</Box>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Heatmap */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, lg: 5 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 15 }}>Risk Heat Map</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary" }}>Likelihood × Impact</Box>
                </Box>
                <Chip size="small" icon={<Sparkles size={12} />} label="AI-scored" sx={{ fontWeight: 600 }} />
              </Box>
              <Box sx={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 1, mt: 1.5 }}>
                <Box sx={{ display: "grid", gridTemplateRows: "repeat(5, 1fr)", fontSize: 10.5, color: "text.secondary", textAlign: "right", pr: 1, alignItems: "center" }}>
                  <Box>Severe</Box><Box>Major</Box><Box>Moderate</Box><Box>Minor</Box><Box>Trivial</Box>
                </Box>
                <Box sx={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 0.75 }}>
                  {heatmap.flat().map((v, i) => {
                    const row = Math.floor(i / 5), col = i % 5;
                    const heat = (4 - row) + col; // 0..8
                    const bg = heat <= 2 ? "#10B98122" : heat <= 4 ? "#F59E0B22" : heat <= 6 ? "#E6392D22" : "#E6392D44";
                    const fg = heat <= 2 ? "#10B981" : heat <= 4 ? "#F59E0B" : "#E6392D";
                    return (
                      <Box key={i} sx={{
                        aspectRatio: "1", borderRadius: 1.5, display: "grid", placeItems: "center",
                        bgcolor: bg, color: fg, fontWeight: 700, fontSize: 13,
                        border: "1px solid", borderColor: `${fg}33`,
                        transition: "transform .15s", "&:hover": { transform: "scale(1.06)" },
                      }}>{v}</Box>
                    );
                  })}
                </Box>
              </Box>
              <Box sx={{ display: "grid", gridTemplateColumns: "auto 1fr", mt: 1 }}>
                <Box />
                <Box sx={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 0.75, fontSize: 10.5, color: "text.secondary", textAlign: "center" }}>
                  <Box>Rare</Box><Box>Unlikely</Box><Box>Possible</Box><Box>Likely</Box><Box>Certain</Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 7 }}>
          <Card sx={{ height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                <Box>
                  <Box sx={{ fontWeight: 700, fontSize: 15 }}>Real-time Alerts</Box>
                  <Box sx={{ fontSize: 12, color: "text.secondary" }}>Triggered by KRI thresholds & continuous monitors</Box>
                </Box>
                <Chip size="small" label="6 active" sx={{ bgcolor: "rgba(230,57,45,0.12)", color: BRAND.primary, fontWeight: 700 }} />
              </Box>
              <Stack divider={<Divider />} spacing={0}>
                {[
                  { sev: "Critical", title: "Sanctions screening hit-rate anomaly", desc: "OFAC bucket showing 3.2σ deviation in last 4h", time: "8 min ago" },
                  { sev: "High", title: "Vendor concentration breach — Tier 1", desc: "Cloud spend on AWS exceeded 62% policy threshold", time: "27 min ago" },
                  { sev: "High", title: "Model performance drift — credit_v4", desc: "AUC dropped from 0.82 → 0.74 over 14-day window", time: "1 hr ago" },
                  { sev: "Medium", title: "Late control test — CTL-4421", desc: "Owner: M. Aldridge · Due yesterday", time: "3 hr ago" },
                ].map((a, i) => (
                  <Box key={i} sx={{ py: 1.5, display: "flex", alignItems: "center", gap: 2 }}>
                    <Box sx={{
                      width: 36, height: 36, borderRadius: 2,
                      bgcolor: `${sevColor(a.sev)}1A`, color: sevColor(a.sev),
                      display: "grid", placeItems: "center",
                    }}>
                      <ShieldAlert size={18} />
                    </Box>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <Chip size="small" label={a.sev} sx={{ height: 18, fontSize: 10.5,
                          bgcolor: `${sevColor(a.sev)}1A`, color: sevColor(a.sev), fontWeight: 700 }} />
                        <Box sx={{ fontSize: 13.5, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.title}</Box>
                      </Box>
                      <Box sx={{ fontSize: 12, color: "text.secondary", mt: 0.25 }}>{a.desc}</Box>
                    </Box>
                    <Box sx={{ fontSize: 11, color: "text.secondary", whiteSpace: "nowrap" }}>{a.time}</Box>
                    <IconButton size="small"><MoreHorizontal size={14} /></IconButton>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Table */}
      <Card>
        <CardContent>
          {/* Toolbar */}
          <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.5, alignItems: "center", mb: 2 }}>
            <Box sx={{ fontWeight: 700, fontSize: 15 }}>Risk Inventory</Box>
            <Chip size="small" label="318 risks" />
            <Box sx={{ flex: 1 }} />
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, px: 1.25, py: 0.5,
              border: 1, borderColor: "divider", borderRadius: 2, minWidth: 240 }}>
              <Search size={15} opacity={0.6} />
              <InputBase placeholder="Quick search…" sx={{ fontSize: 13, flex: 1 }} />
            </Box>
            <Button size="small" startIcon={<Filter size={14} />}
              onClick={(e) => setFilterAnchor(e.currentTarget)}>Filters · 3</Button>
            <Menu open={!!filterAnchor} anchorEl={filterAnchor} onClose={() => setFilterAnchor(null)}>
              <MenuItem>Category: Cyber, Operational</MenuItem>
              <MenuItem>Severity: Critical, High</MenuItem>
              <MenuItem>Owner: 4 selected</MenuItem>
              <MenuItem>+ Add advanced filter</MenuItem>
            </Menu>
            <Button size="small" startIcon={<Columns3 size={14} />}
              onClick={(e) => setColAnchor(e.currentTarget)}>Columns</Button>
            <Menu open={!!colAnchor} anchorEl={colAnchor} onClose={() => setColAnchor(null)}>
              {["ID", "Title", "Owner", "Category", "Inherent", "Residual", "Status", "Score", "Updated"].map((c) => (
                <MenuItem key={c}><Checkbox defaultChecked size="small" />{c}</MenuItem>
              ))}
            </Menu>
            <Button size="small" startIcon={<Download size={14} />}>Export</Button>
            <ToggleButtonGroup size="small" exclusive value={view} onChange={(_, v) => v && setView(v)}>
              <ToggleButton value="table"><ListIcon size={14} /></ToggleButton>
              <ToggleButton value="grid"><LayoutGrid size={14} /></ToggleButton>
            </ToggleButtonGroup>
            <Button size="small" variant="contained" startIcon={<Plus size={14} />}>New Risk</Button>
          </Box>

          {selected.length > 0 && (
            <Box sx={{ mb: 1.5, p: 1.25, borderRadius: 2, bgcolor: "rgba(230,57,45,0.06)",
              display: "flex", alignItems: "center", gap: 1.5 }}>
              <Box sx={{ fontSize: 13, fontWeight: 600 }}>{selected.length} selected</Box>
              <Button size="small">Reassign</Button>
              <Button size="small">Change status</Button>
              <Button size="small" color="error">Archive</Button>
            </Box>
          )}

          {view === "table" ? (
            <Box sx={{ overflow: "auto" }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox">
                      <Checkbox size="small"
                        checked={selected.length === risks.length}
                        indeterminate={selected.length > 0 && selected.length < risks.length}
                        onChange={(e) => setSelected(e.target.checked ? risks.map(r => r.id) : [])} />
                    </TableCell>
                    {[
                      { l: "ID", pin: true }, { l: "Risk Title" }, { l: "Owner" }, { l: "Category" },
                      { l: "Inherent" }, { l: "Residual" }, { l: "Status" }, { l: "Score" }, { l: "Updated" }, { l: "" },
                    ].map((h, i) => (
                      <TableCell key={i}>
                        <Box sx={{ display: "inline-flex", alignItems: "center", gap: 0.5 }}>
                          {h.pin && <Pin size={10} />}
                          {h.l}
                          {h.l && h.l !== "" && <ArrowUpDown size={10} opacity={0.4} />}
                        </Box>
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {risks.slice(page * rpp, page * rpp + rpp).map((r) => (
                    <TableRow key={r.id} hover sx={{ "& td": { fontSize: 13 } }}>
                      <TableCell padding="checkbox">
                        <Checkbox size="small" checked={selected.includes(r.id)} onChange={() => toggle(r.id)} />
                      </TableCell>
                      <TableCell><Box sx={{ fontWeight: 700, color: BRAND.primary }}>{r.id}</Box></TableCell>
                      <TableCell><Box sx={{ fontWeight: 600 }}>{r.title}</Box></TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <Avatar sx={{ width: 22, height: 22, fontSize: 10, bgcolor: BRAND.navy }}>
                            {r.owner.split(" ").map(w => w[0]).join("")}
                          </Avatar>
                          {r.owner}
                        </Box>
                      </TableCell>
                      <TableCell><Chip size="small" label={r.category} variant="outlined" /></TableCell>
                      <TableCell>
                        <Chip size="small" label={r.inherent}
                          sx={{ bgcolor: `${sevColor(r.inherent)}1A`, color: sevColor(r.inherent), fontWeight: 700 }} />
                      </TableCell>
                      <TableCell>
                        <Chip size="small" label={r.residual}
                          sx={{ bgcolor: `${sevColor(r.residual)}1A`, color: sevColor(r.residual), fontWeight: 700 }} />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: "inline-flex", alignItems: "center", gap: 0.75 }}>
                          <Box sx={{ width: 6, height: 6, borderRadius: "50%", bgcolor: statColor(r.status) }} />
                          {r.status}
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1, minWidth: 90 }}>
                          <LinearProgress variant="determinate" value={r.score}
                            sx={{ flex: 1, height: 6, borderRadius: 3, bgcolor: "action.hover",
                              "& .MuiLinearProgress-bar": { backgroundColor: r.score > 80 ? BRAND.primary : r.score > 60 ? "#F59E0B" : "#10B981" } }} />
                          <Box sx={{ fontWeight: 700, fontSize: 12 }}>{r.score}</Box>
                        </Box>
                      </TableCell>
                      <TableCell sx={{ color: "text.secondary" }}>{r.updated}</TableCell>
                      <TableCell><IconButton size="small"><MoreHorizontal size={14} /></IconButton></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <TablePagination component="div" count={risks.length} page={page} rowsPerPage={rpp}
                onPageChange={(_, p) => setPage(p)} onRowsPerPageChange={(e) => setRpp(+e.target.value)}
                rowsPerPageOptions={[5, 10, 25]} />
            </Box>
          ) : (
            <Grid container spacing={2}>
              {risks.map((r) => (
                <Grid key={r.id} size={{ xs: 12, sm: 6, md: 4 }}>
                  <Card variant="outlined">
                    <CardContent>
                      <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                        <Box sx={{ fontSize: 11, fontWeight: 700, color: BRAND.primary }}>{r.id}</Box>
                        <Chip size="small" label={r.residual} sx={{
                          bgcolor: `${sevColor(r.residual)}1A`, color: sevColor(r.residual), fontWeight: 700 }} />
                      </Box>
                      <Box sx={{ fontWeight: 600, mt: 0.5, fontSize: 13.5 }}>{r.title}</Box>
                      <Box sx={{ fontSize: 11.5, color: "text.secondary", mt: 0.5 }}>{r.category} · {r.owner}</Box>
                      <LinearProgress variant="determinate" value={r.score}
                        sx={{ mt: 1.5, height: 6, borderRadius: 3,
                          "& .MuiLinearProgress-bar": { backgroundColor: sevColor(r.residual) } }} />
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
