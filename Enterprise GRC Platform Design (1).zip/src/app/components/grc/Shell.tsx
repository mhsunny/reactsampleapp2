import { useState } from "react";
import {
  Box, Drawer, AppBar, Toolbar, IconButton, InputBase, Avatar, Badge,
  Tooltip, Divider, Chip, Switch, FormControlLabel, Menu, MenuItem, ListItemIcon, ListItemText,
} from "@mui/material";
import {
  LayoutGrid, ShieldAlert, Gauge, Siren, ClipboardCheck, Scale, FlaskConical,
  Activity, Search as SearchIcon, TrendingUp, Settings2, Bell, ChevronLeft,
  ChevronRight, Plus, Command, Sun, Moon, HelpCircle, LogOut, User, ChevronDown,
  Home, Users, Sparkles,
} from "lucide-react";
import { BRAND } from "./theme";

const navGroups = [
  {
    label: "Workspace",
    items: [
      { id: "home", label: "App Launcher", icon: Home },
      { id: "group", label: "Domain Overview", icon: LayoutGrid },
    ],
  },
  {
    label: "Risk",
    items: [
      { id: "risk-inv", label: "Risk Inventory", icon: ShieldAlert },
      { id: "risk-meas", label: "Risk Measures", icon: Gauge },
      { id: "risk-events", label: "Risk Events", icon: Siren },
      { id: "risk-assess", label: "Assessments", icon: ClipboardCheck },
    ],
  },
  {
    label: "Compliance & Assurance",
    items: [
      { id: "compliance", label: "Compliance Matrix", icon: Scale },
      { id: "testing", label: "Testing & Validation", icon: FlaskConical },
      { id: "monitoring", label: "Monitoring", icon: Activity },
      { id: "audit", label: "Internal Audit", icon: SearchIcon },
      { id: "capacity", label: "Capacity Planning", icon: TrendingUp },
    ],
  },
  {
    label: "Platform",
    items: [
      { id: "config", label: "Configuration Hub", icon: Settings2 },
      { id: "settings", label: "Settings & RBAC", icon: Users },
    ],
  },
];

export function Shell({
  view, setView, dark, setDark, children, onCreateGroup,
}: {
  view: string;
  setView: (v: string) => void;
  dark: boolean;
  setDark: (b: boolean) => void;
  children: React.ReactNode;
  onCreateGroup: () => void;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [anchor, setAnchor] = useState<null | HTMLElement>(null);
  const width = collapsed ? 76 : 264;

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "background.default" }}>
      {/* Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          width,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width,
            boxSizing: "border-box",
            background: dark
              ? `linear-gradient(180deg, #06101F 0%, ${BRAND.navyDeep} 100%)`
              : `linear-gradient(180deg, ${BRAND.navyDeep} 0%, ${BRAND.navy} 100%)`,
            color: "#E8EEF7",
            borderRight: "1px solid rgba(255,255,255,0.06)",
            overflowX: "hidden",
            transition: "width .25s ease",
          },
        }}
      >
        {/* Logo */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.25, px: 2, py: 2.25 }}>
          <Box sx={{
            width: 38, height: 38, borderRadius: "12px",
            background: `linear-gradient(135deg, ${BRAND.primaryLight}, ${BRAND.primary})`,
            display: "grid", placeItems: "center",
            boxShadow: "0 10px 24px -10px rgba(230,57,45,0.7)",
          }}>
            <ShieldAlert size={20} color="#fff" />
          </Box>
          {!collapsed && (
            <Box sx={{ lineHeight: 1.1, display: "flex", flexDirection: "column" }}>
              <Box sx={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>GRC Risk</Box>
              <Box sx={{ fontSize: 11, color: "rgba(255,255,255,0.55)" }}>& Compliance</Box>
            </Box>
          )}
        </Box>

        {/* Group selector */}
        {!collapsed && (
          <Box sx={{ mx: 1.5, mb: 1.5, p: 1.25, borderRadius: 2,
            border: "1px solid rgba(255,255,255,0.08)",
            background: "rgba(255,255,255,0.03)", display: "flex", alignItems: "center", gap: 1, cursor: "pointer" }}>
            <Box sx={{ width: 30, height: 30, borderRadius: 1.25,
              background: "linear-gradient(135deg,#1E3A8A,#E6392D)", display:"grid", placeItems:"center", fontWeight: 700, fontSize: 12 }}>NA</Box>
            <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
              <Box sx={{ fontSize: 12.5, fontWeight: 600 }}>Non-Financial Risk Mgmt</Box>
              <Box sx={{ fontSize: 10.5, color: "rgba(255,255,255,0.5)" }}>5 apps · 142 members</Box>
            </Box>
            <ChevronDown size={14} opacity={0.6} />
          </Box>
        )}

        <Box sx={{ overflowY: "auto", flex: 1, px: 1, pb: 2 }}>
          {navGroups.map((g) => (
            <Box key={g.label} sx={{ mt: 1.5 }}>
              {!collapsed && (
                <Box sx={{ px: 1.5, py: 0.5, fontSize: 10.5, letterSpacing: ".12em",
                  color: "rgba(255,255,255,0.4)", textTransform: "uppercase", fontWeight: 700 }}>
                  {g.label}
                </Box>
              )}
              {g.items.map(({ id, label, icon: Icon }) => {
                const active = view === id;
                return (
                  <Tooltip key={id} title={collapsed ? label : ""} placement="right">
                    <Box
                      onClick={() => setView(id)}
                      sx={{
                        mx: 0.5, my: 0.25, px: collapsed ? 0 : 1.25, py: 1,
                        borderRadius: 2, cursor: "pointer",
                        display: "flex", alignItems: "center",
                        justifyContent: collapsed ? "center" : "flex-start",
                        gap: 1.25, position: "relative",
                        color: active ? "#fff" : "rgba(255,255,255,0.72)",
                        background: active ? "rgba(230,57,45,0.14)" : "transparent",
                        "&:hover": { background: active ? "rgba(230,57,45,0.18)" : "rgba(255,255,255,0.05)" },
                        transition: "background .15s",
                      }}
                    >
                      {active && (
                        <Box sx={{ position: "absolute", left: 0, top: 8, bottom: 8, width: 3,
                          borderRadius: 4, background: `linear-gradient(180deg,${BRAND.primaryLight},${BRAND.primary})` }} />
                      )}
                      <Icon size={17} />
                      {!collapsed && <Box sx={{ fontSize: 13.5, fontWeight: active ? 600 : 500 }}>{label}</Box>}
                    </Box>
                  </Tooltip>
                );
              })}
            </Box>
          ))}
        </Box>

        <Divider sx={{ borderColor: "rgba(255,255,255,0.08)" }} />
        <Box sx={{ p: 1.25, display: "flex", alignItems: "center", justifyContent: collapsed ? "center" : "space-between" }}>
          {!collapsed && (
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Avatar sx={{ width: 30, height: 30, bgcolor: BRAND.primary, fontSize: 12 }}>EM</Avatar>
              <Box sx={{ lineHeight: 1.1, display: "flex", flexDirection: "column" }}>
                <Box sx={{ fontSize: 12.5, fontWeight: 600 }}>Elena Marlowe</Box>
                <Box sx={{ fontSize: 10.5, color: "rgba(255,255,255,0.5)" }}>Chief Risk Officer</Box>
              </Box>
            </Box>
          )}
          <IconButton size="small" onClick={() => setCollapsed(!collapsed)} sx={{ color: "rgba(255,255,255,0.7)" }}>
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </IconButton>
        </Box>
      </Drawer>

      {/* Main */}
      <Box sx={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <AppBar position="sticky" elevation={0}
          sx={{
            background: dark
              ? "linear-gradient(180deg, rgba(7,14,26,0.85), rgba(7,14,26,0.7))"
              : "rgba(255,255,255,0.78)",
            backdropFilter: "saturate(180%) blur(14px)",
            color: "text.primary",
            borderBottom: 1, borderColor: "divider",
          }}>
          <Toolbar sx={{ gap: 2, minHeight: 64 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1,
              fontSize: 12.5, color: "text.secondary" }}>
              <Sparkles size={14} color={BRAND.primary} />
              <span style={{ fontWeight: 600 }}>Platform</span>
              <span>/</span>
              <span>North America Banking</span>
              <span>/</span>
              <span style={{ color: "var(--mui-palette-text-primary, #0A2540)", fontWeight: 600 }}>
                {viewTitle(view)}
              </span>
            </Box>

            <Box sx={{ flex: 1 }} />

            <Box sx={{
              display: "flex", alignItems: "center", gap: 1,
              px: 1.5, py: 0.75, borderRadius: 2.5,
              bgcolor: "action.hover",
              minWidth: 320, maxWidth: 460,
              border: 1, borderColor: "divider",
            }}>
              <SearchIcon size={16} opacity={0.6} />
              <InputBase placeholder="Search risks, controls, obligations…" sx={{ flex: 1, fontSize: 13.5 }} />
              <Chip
                icon={<Command size={11} />}
                label="K"
                size="small"
                sx={{ height: 20, fontSize: 10.5, "& .MuiChip-icon": { ml: 0.5 } }}
              />
            </Box>

            <FormControlLabel
              control={<Switch size="small" checked={dark} onChange={(e) => setDark(e.target.checked)} />}
              label={dark ? <Moon size={14} /> : <Sun size={14} />}
              sx={{ ml: 0.5, mr: 0, "& .MuiFormControlLabel-label": { display: "flex", alignItems: "center" } }}
            />

            <Tooltip title="Create new domain">
              <IconButton onClick={onCreateGroup}
                sx={{
                  background: `linear-gradient(135deg,${BRAND.primaryLight},${BRAND.primary})`,
                  color: "#fff", "&:hover": { filter: "brightness(1.05)" },
                  boxShadow: "0 8px 22px -10px rgba(230,57,45,0.6)",
                }}>
                <Plus size={18} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Help">
              <IconButton><HelpCircle size={18} /></IconButton>
            </Tooltip>
            <Tooltip title="Notifications">
              <IconButton>
                <Badge color="error" variant="dot"><Bell size={18} /></Badge>
              </IconButton>
            </Tooltip>

            <Box onClick={(e) => setAnchor(e.currentTarget)}
              sx={{ display: "flex", alignItems: "center", gap: 1, cursor: "pointer",
                p: 0.5, pl: 0.5, pr: 1, borderRadius: 2, "&:hover": { bgcolor: "action.hover" } }}>
              <Avatar sx={{ width: 30, height: 30, bgcolor: BRAND.navy, fontSize: 12 }}>EM</Avatar>
              <Box sx={{ lineHeight: 1.1, display: { xs: "none", md: "flex" }, flexDirection: "column" }}>
                <Box sx={{ fontSize: 12, fontWeight: 600 }}>Elena M.</Box>
                <Box sx={{ fontSize: 10.5, color: "text.secondary" }}>CRO</Box>
              </Box>
            </Box>
            <Menu open={!!anchor} anchorEl={anchor} onClose={() => setAnchor(null)}
              transformOrigin={{ horizontal: "right", vertical: "top" }}
              anchorOrigin={{ horizontal: "right", vertical: "bottom" }}>
              <MenuItem><ListItemIcon><User size={16} /></ListItemIcon><ListItemText>Profile</ListItemText></MenuItem>
              <MenuItem><ListItemIcon><Settings2 size={16} /></ListItemIcon><ListItemText>Preferences</ListItemText></MenuItem>
              <Divider />
              <MenuItem><ListItemIcon><LogOut size={16} /></ListItemIcon><ListItemText>Sign out</ListItemText></MenuItem>
            </Menu>
          </Toolbar>
        </AppBar>

        <Box sx={{ flex: 1, p: { xs: 1.5, md: 2.5 } }}>{children}</Box>
      </Box>
    </Box>
  );
}

function viewTitle(view: string) {
  const map: Record<string, string> = {
    home: "App Launcher",
    group: "Domain Overview",
    "risk-inv": "Risk Inventory",
    "risk-meas": "Risk Measures",
    "risk-events": "Risk Events",
    "risk-assess": "Risk Assessments",
    compliance: "Compliance Matrix",
    testing: "Testing & Validation",
    monitoring: "Monitoring & Oversight",
    audit: "Internal Audit",
    capacity: "Capacity Planning",
    config: "Configuration Hub",
    settings: "Settings & RBAC",
  };
  return map[view] ?? view;
}
