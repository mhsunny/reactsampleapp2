export const groups = [
  {
    id: "non-financial-risk",
    name: "Non-Financial Risk Management",
    description: "Manage FRCs, controls, RAUs, MREs, KRIs, risk appetite, and compliance obligations",
    apps: 5,
    members: 142,
    risks: 318,
    score: 92,
    color: "#E6392D",
    cover: "linear-gradient(135deg,#0A2540 0%,#1E3A8A 60%,#E6392D 140%)",
  },
  {
    id: "internal-audit",
    name: "Internal Audit Management",
    description: "Deliver annual planning, fieldwork, issue management, and reporting",
    apps: 1,
    members: 58,
    risks: 214,
    score: 94,
    color: "#06B6D4",
    cover: "linear-gradient(135deg,#0A2540 0%,#155E75 60%,#06B6D4 140%)",
  },
  {
    id: "testing-monitoring",
    name: "Testing and Monitoring",
    description: "Second-line testing lifecycle and QA/QC monitoring oversight routines",
    apps: 2,
    members: 74,
    risks: 312,
    score: 88,
    color: "#8B5CF6",
    cover: "linear-gradient(135deg,#0A2540 0%,#4C1D95 60%,#8B5CF6 140%)",
  },
  {
    id: "common-capabilities",
    name: "Common Business Capabilities",
    description: "Shared services for capacity planning, time reporting, and AI prompt lifecycle",
    apps: 2,
    members: 46,
    risks: 134,
    score: 96,
    color: "#10B981",
    cover: "linear-gradient(135deg,#0A2540 0%,#064E3B 60%,#10B981 140%)",
  },
  {
    id: "configuration",
    name: "Configuration Capabilities",
    description: "Configure API connectors, workflow designer, user access, and platform controls",
    apps: 3,
    members: 32,
    risks: 78,
    score: 99,
    color: "#64748B",
    cover: "linear-gradient(135deg,#0A2540 0%,#1E293B 60%,#475569 140%)",
  },
];

export const modules = [
  { id: "risk-inv", name: "Risk Inventory", icon: "ShieldAlert", desc: "Central catalog of enterprise risks", count: 318 },
  { id: "risk-meas", name: "Risk Measures", icon: "Gauge", desc: "KRIs, scenarios & quantification", count: 84 },
  { id: "risk-events", name: "Risk Events", icon: "Siren", desc: "Incidents, near-misses & losses", count: 26 },
  { id: "risk-assess", name: "Risk Assessments", icon: "ClipboardCheck", desc: "RCSA, templates & campaigns", count: 47 },
  { id: "compliance", name: "Compliance", icon: "Scale", desc: "Obligations, policies & attestations", count: 612 },
  { id: "testing", name: "Testing & Validation", icon: "FlaskConical", desc: "Control testing & evidence", count: 198 },
  { id: "monitoring", name: "Monitoring", icon: "Activity", desc: "Continuous oversight & alerts", count: 12 },
  { id: "audit", name: "Internal Audit", icon: "Search", desc: "Universe, planning & issues", count: 39 },
  { id: "capacity", name: "Capacity Planning", icon: "TrendingUp", desc: "Resource & workload forecasting", count: 8 },
  { id: "config", name: "Configuration Hub", icon: "Settings2", desc: "Platform admin & taxonomy", count: 0 },
];

export const risks = [
  { id: "RSK-1024", title: "Unauthorized cross-border data transfer", owner: "M. Aldridge", category: "Data Privacy", inherent: "High", residual: "Medium", status: "Mitigating", score: 72, updated: "2026-06-04" },
  { id: "RSK-1025", title: "Third-party SaaS concentration risk", owner: "S. Okafor", category: "Vendor", inherent: "Critical", residual: "High", status: "Open", score: 86, updated: "2026-06-06" },
  { id: "RSK-1026", title: "Model drift in credit decisioning", owner: "J. Chen", category: "Model Risk", inherent: "High", residual: "Medium", status: "Monitoring", score: 64, updated: "2026-06-01" },
  { id: "RSK-1027", title: "Ransomware lateral movement", owner: "P. Volkov", category: "Cyber", inherent: "Critical", residual: "High", status: "Mitigating", score: 91, updated: "2026-06-07" },
  { id: "RSK-1028", title: "Sanctions screening false negatives", owner: "L. Becker", category: "Financial Crime", inherent: "High", residual: "Medium", status: "Open", score: 70, updated: "2026-05-30" },
  { id: "RSK-1029", title: "Cloud key rotation gaps", owner: "T. Yamada", category: "Cyber", inherent: "Medium", residual: "Low", status: "Closed", score: 38, updated: "2026-05-22" },
  { id: "RSK-1030", title: "Regulatory reporting timeliness", owner: "A. Rossi", category: "Regulatory", inherent: "High", residual: "Medium", status: "Mitigating", score: 67, updated: "2026-06-03" },
  { id: "RSK-1031", title: "Insider trading surveillance lag", owner: "K. Nguyen", category: "Conduct", inherent: "Medium", residual: "Medium", status: "Open", score: 58, updated: "2026-05-28" },
];

export const trendData = Array.from({ length: 12 }).map((_, i) => ({
  month: ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun"][i],
  inherent: 60 + Math.round(Math.sin(i / 2) * 10) + i,
  residual: 30 + Math.round(Math.cos(i / 2) * 8) + Math.floor(i / 2),
  events: 4 + Math.round(Math.abs(Math.sin(i)) * 7),
}));

export const donutData = [
  { name: "Cyber", value: 247, color: "#E6392D" },
  { name: "Operational", value: 184, color: "#F59E0B" },
  { name: "Compliance", value: 156, color: "#3B82F6" },
  { name: "Financial", value: 98, color: "#10B981" },
  { name: "Strategic", value: 64, color: "#A855F7" },
];

export const activity = [
  { user: "M. Aldridge", action: "approved control test", target: "CTL-4421", time: "2m ago", color: "#16A34A" },
  { user: "S. Okafor", action: "escalated risk", target: "RSK-1025", time: "12m ago", color: "#E6392D" },
  { user: "J. Chen", action: "submitted assessment", target: "RCSA Q2-EMEA", time: "38m ago", color: "#3B82F6" },
  { user: "Compliance Bot", action: "flagged obligation drift", target: "DORA Art. 17", time: "1h ago", color: "#F59E0B" },
  { user: "P. Volkov", action: "closed incident", target: "INC-882", time: "2h ago", color: "#16A34A" },
  { user: "A. Rossi", action: "updated KRI threshold", target: "KRI-CR-09", time: "3h ago", color: "#A855F7" },
];

export const heatmap = [
  [2, 4, 7, 11, 6],
  [3, 8, 14, 9, 4],
  [6, 12, 22, 15, 7],
  [4, 9, 18, 12, 5],
  [1, 3, 6, 4, 2],
];

export const obligations = [
  { framework: "SOX", coverage: 96, controls: 184, gaps: 4, owner: "Finance" },
  { framework: "GDPR", coverage: 92, controls: 142, gaps: 7, owner: "Privacy" },
  { framework: "DORA", coverage: 84, controls: 98, gaps: 12, owner: "Tech Risk" },
  { framework: "Basel III", coverage: 98, controls: 211, gaps: 2, owner: "Capital" },
  { framework: "MiCA", coverage: 71, controls: 56, gaps: 14, owner: "Digital Assets" },
  { framework: "ISO 27001", coverage: 95, controls: 168, gaps: 5, owner: "Security" },
];
