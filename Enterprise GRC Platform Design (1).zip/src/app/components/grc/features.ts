import {
  LayoutDashboard, Database, Workflow, ClipboardCheck, FlaskConical, FolderOpen,
  Flame, Gauge, AlertOctagon, History, Bell, Sparkles, FileBarChart, Plug,
  ListPlus, Upload, Code2, Timer, MessageSquare, Paperclip, Tags, GitBranch,
  CalendarClock, Webhook, Scale, ShieldCheck, Search, Users,
  Shield, ShieldAlert, FileText, FileLock2, Archive, AlertTriangle, Building2,
  BookOpen, BarChart2, Ruler, TrendingUp, Vote, ClipboardList, Library,
} from "lucide-react";

export type Feature = {
  id: string;
  name: string;
  description: string;
  icon: any;
  category: "Core" | "Productivity" | "Risk & Compliance" | "Automation" | "Governance";
  defaultOn?: boolean;
  premium?: boolean;
};

export const FEATURE_LIBRARY: Feature[] = [
  // Core
  { id: "dashboard", name: "Dashboard", description: "Configurable widgets — KPIs, charts, heatmaps", icon: LayoutDashboard, category: "Core", defaultOn: true },
  { id: "records", name: "Records & Inventory", description: "Structured records with custom fields", icon: Database, category: "Core", defaultOn: true },
  { id: "custom-fields", name: "Custom Fields", description: "Text, number, date, select, user, lookup", icon: ListPlus, category: "Core", defaultOn: true },
  { id: "tags", name: "Tags & Taxonomy", description: "Hierarchical labels and categories", icon: Tags, category: "Core", defaultOn: true },
  { id: "search", name: "Advanced Search", description: "Full-text and faceted search", icon: Search, category: "Core", defaultOn: true },

  // Productivity
  { id: "comments", name: "Comments & Mentions", description: "Threaded discussion with @mentions", icon: MessageSquare, category: "Productivity", defaultOn: true },
  { id: "attachments", name: "Attachments", description: "Files, links, evidence uploads", icon: Paperclip, category: "Productivity", defaultOn: true },
  { id: "bulk-import", name: "Bulk Import / Export", description: "CSV, XLSX, JSON round-trip", icon: Upload, category: "Productivity" },
  { id: "members", name: "Members & Roles", description: "App-level membership and RBAC", icon: Users, category: "Productivity", defaultOn: true },
  { id: "reports", name: "Reports & Exports", description: "Scheduled PDF / XLSX deliveries", icon: FileBarChart, category: "Productivity" },

  // Risk & Compliance
  { id: "workflows", name: "Workflows & Approvals", description: "Stages, transitions, approval chains", icon: Workflow, category: "Risk & Compliance", defaultOn: true },
  { id: "assessments", name: "Assessments", description: "RCSA, DPIA and survey templates", icon: ClipboardCheck, category: "Risk & Compliance" },
  { id: "control-testing", name: "Control Testing", description: "Test scripts, sampling, effectiveness", icon: FlaskConical, category: "Risk & Compliance" },
  { id: "evidence", name: "Evidence Library", description: "Linked artifacts with retention", icon: FolderOpen, category: "Risk & Compliance" },
  { id: "heatmap", name: "Risk Heatmap", description: "Likelihood × Impact visualization", icon: Flame, category: "Risk & Compliance" },
  { id: "kri", name: "KRIs & Thresholds", description: "Key risk indicators with breaches", icon: Gauge, category: "Risk & Compliance" },
  { id: "incidents", name: "Incident Tracking", description: "Events, losses and near-misses", icon: AlertOctagon, category: "Risk & Compliance" },
  { id: "compliance-map", name: "Compliance Mapping", description: "Map to SOX, GDPR, DORA, ISO…", icon: Scale, category: "Risk & Compliance" },
  { id: "second-line", name: "Two-factor Approval", description: "Second-line / four-eyes sign-off", icon: ShieldCheck, category: "Risk & Compliance" },
  // Risk Inventory tabs (image-3)
  { id: "raus", name: "RAUs", description: "Risk Assessment Units — manage and review RAU submissions", icon: Shield, category: "Risk & Compliance" },
  { id: "risks", name: "Risks", description: "Risk register entries with scoring and ownership", icon: ShieldAlert, category: "Risk & Compliance" },
  { id: "controls", name: "Controls", description: "Control library with design and operating effectiveness", icon: ShieldCheck, category: "Risk & Compliance" },
  { id: "mcrs", name: "MCRs", description: "Material change requests and impact assessments", icon: FileText, category: "Risk & Compliance" },
  { id: "frcs", name: "FRCs", description: "Functional risk and control definitions", icon: FileLock2, category: "Risk & Compliance" },
  { id: "controls-legacy", name: "Controls (Legacy)", description: "Archived control records migrated from legacy systems", icon: Archive, category: "Risk & Compliance" },
  { id: "mres", name: "MREs", description: "Material risk events — tracking, classification, and resolution", icon: AlertTriangle, category: "Risk & Compliance" },
  { id: "policies", name: "Policies", description: "Policy authoring, versioning, and attestation management", icon: BookOpen, category: "Governance" },
  // Risk Measures tabs (image-4)
  { id: "measurement-workbench", name: "Measurement Workbench", description: "Interactive workbench for building and running risk measures", icon: BarChart2, category: "Risk & Compliance" },
  { id: "measure-definitions", name: "Measure Definitions", description: "Define and manage metric formulas and calculation rules", icon: Ruler, category: "Risk & Compliance" },
  { id: "risk-appetite", name: "Risk Appetite", description: "Set and monitor risk appetite statements and thresholds", icon: TrendingUp, category: "Risk & Compliance" },
  { id: "committee-decisions", name: "Committee Decisions", description: "Record, track, and action risk committee outcomes", icon: Vote, category: "Governance" },
  { id: "risk-register", name: "Risk Register", description: "Enterprise-wide risk register with full lifecycle tracking", icon: ClipboardList, category: "Risk & Compliance" },
  { id: "control-library", name: "Control Library", description: "Centralized repository of reusable control definitions", icon: Library, category: "Risk & Compliance" },

  // Governance (shared)
  { id: "business-units", name: "Business Units", description: "Organisational hierarchy and business unit mappings", icon: Building2, category: "Governance" },

  // Automation
  { id: "notifications", name: "Notifications", description: "Email, Slack, Teams, in-app", icon: Bell, category: "Automation", defaultOn: true },
  { id: "ai-copilot", name: "AI Copilot", description: "Drafting, summaries, anomaly detection", icon: Sparkles, category: "Automation", premium: true },
  { id: "integrations", name: "Integrations", description: "Jira, ServiceNow, Splunk, cloud…", icon: Plug, category: "Automation" },
  { id: "scheduled-jobs", name: "Scheduled Jobs", description: "Cron-style automation rules", icon: CalendarClock, category: "Automation" },
  { id: "webhooks", name: "Webhooks", description: "Outbound event delivery", icon: Webhook, category: "Automation" },
  { id: "api", name: "Public API", description: "Token-authenticated REST API", icon: Code2, category: "Automation" },

  // Governance
  { id: "sla", name: "SLAs & Escalations", description: "Time-bound commitments with escalation", icon: Timer, category: "Governance" },
  { id: "branching", name: "Conditional Logic", description: "Rule-based branching and visibility", icon: GitBranch, category: "Governance" },
  { id: "audit-log", name: "Audit Trail", description: "Immutable change history", icon: History, category: "Governance", defaultOn: true },
];

export const FEATURE_BY_ID = Object.fromEntries(FEATURE_LIBRARY.map(f => [f.id, f]));
export const FEATURE_CATEGORIES: Feature["category"][] =
  ["Core", "Productivity", "Risk & Compliance", "Automation", "Governance"];
