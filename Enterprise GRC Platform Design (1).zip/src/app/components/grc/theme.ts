import { createTheme } from "@mui/material/styles";

export const BRAND = {
  primary: "#E6392D",
  primaryLight: "#F05D40",
  primaryDeep: "#B82A20",
  navy: "#0A2540",
  navyDeep: "#061629",
  slate: "#1A2332",
  ink: "#0F172A",
  ash: "#64748B",
  mist: "#F4F6FA",
  line: "rgba(255,255,255,0.08)",
  glass: "rgba(255,255,255,0.04)",
};

export const grcTheme = (mode: "light" | "dark") =>
  createTheme({
    palette: {
      mode,
      primary: { main: BRAND.primary, light: BRAND.primaryLight, dark: BRAND.primaryDeep, contrastText: "#fff" },
      secondary: { main: BRAND.navy },
      background:
        mode === "dark"
          ? { default: "#070E1A", paper: "#0E1726" }
          : { default: "#F6F8FC", paper: "#FFFFFF" },
      text:
        mode === "dark"
          ? { primary: "#E8EEF7", secondary: "#9AA7BD" }
          : { primary: "#0A2540", secondary: "#5B6B82" },
      divider: mode === "dark" ? "rgba(255,255,255,0.08)" : "rgba(10,37,64,0.08)",
      success: { main: "#16A34A" },
      warning: { main: "#F59E0B" },
      error: { main: "#E6392D" },
      info: { main: "#3B82F6" },
    },
    shape: { borderRadius: 14 },
    typography: {
      fontFamily:
        'Inter, "SF Pro Display", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      h1: { fontWeight: 700, letterSpacing: "-0.02em" },
      h2: { fontWeight: 700, letterSpacing: "-0.02em" },
      h3: { fontWeight: 600, letterSpacing: "-0.01em" },
      h4: { fontWeight: 600 },
      h5: { fontWeight: 600 },
      h6: { fontWeight: 600 },
      button: { textTransform: "none", fontWeight: 600 },
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: { borderRadius: 10, paddingInline: 16, paddingBlock: 8 },
          containedPrimary: {
            boxShadow: "0 8px 22px -10px rgba(230,57,45,0.6)",
            backgroundImage: "linear-gradient(135deg, #F05D40 0%, #E6392D 100%)",
          },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            backgroundImage: "none",
          },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 18,
            border:
              mode === "dark"
                ? "1px solid rgba(255,255,255,0.06)"
                : "1px solid rgba(10,37,64,0.06)",
            boxShadow:
              mode === "dark"
                ? "0 1px 0 rgba(255,255,255,0.02), 0 12px 40px -20px rgba(0,0,0,0.6)"
                : "0 1px 0 rgba(10,37,64,0.02), 0 12px 40px -24px rgba(10,37,64,0.2)",
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: { fontWeight: 600, borderRadius: 8 },
        },
      },
      MuiTableCell: {
        styleOverrides: {
          root: { borderBottomColor: mode === "dark" ? "rgba(255,255,255,0.06)" : "rgba(10,37,64,0.06)" },
          head: { fontWeight: 700, color: mode === "dark" ? "#9AA7BD" : "#5B6B82", textTransform: "uppercase", fontSize: 11, letterSpacing: "0.06em" },
        },
      },
    },
  });
